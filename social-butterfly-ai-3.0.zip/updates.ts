

export type UpdateType = 'feature' | 'fix' | 'improvement';

export interface UpdateLog {
  id: string;
  date: string;
  title: string;
  description: string;
  type: UpdateType;
}

const today = new Date().toLocaleDateString();

export const appUpdates: UpdateLog[] = [
  {
    id: 'feat-vibe-architect-v1',
    date: today,
    title: 'Vibe Architect v1.0',
    description: 'The Builder Brain is live. We have implemented the full "Reasoning Model" for app generation. Vibe Architect now acts as a Senior PM, UX Designer, and Frontend Engineer in one loop. It defines your market logic, aesthetic profile, and requirements before writing a single line of code.',
    type: 'feature'
  },
  {
    id: 'feat-gemini-3-pro-full',
    date: today,
    title: 'Global Intelligence Upgrade: Gemini 3 Pro',
    description: 'We have upgraded the entire platform to run on Gemini 3 Pro Preview. This means smarter Vibe Coding, deeper strategic insights, and multimodal reasoning across the entire Founder\'s Suite.',
    type: 'feature'
  },
  {
    id: 'release-digital-dominion',
    date: today,
    title: 'UI Overhaul: Digital Dominion',
    description: 'A complete visual transformation. We have shifted to a high-end "Quantum Editorial" aesthetic featuring deep cosmic backgrounds, glassmorphism, and our signature Electric Teal & Wing Gold branding across the entire dashboard and landing page.',
    type: 'feature'
  },
  {
    id: 'feat-asset-vault',
    date: today,
    title: 'Brand Asset Vault & CMS',
    description: 'Admins can now upload and manage Hero Videos, Logos, and Brand Assets directly in the Dashboard. This effectively creates a "Brand DNA" system where your assets live securely in the cloud.',
    type: 'feature'
  },
  {
    id: 'feat-cinematic-hero',
    date: today,
    title: 'Cinematic Video Hero',
    description: 'The landing page now supports full-screen video backgrounds with intelligent "Lower Thirds" layout logic to protect character visibility and ensure text readability.',
    type: 'improvement'
  },
  {
    id: 'fix-stability-core',
    date: today,
    title: 'Core Stability & Logout Fixes',
    description: 'Resolved critical state persistence issues on logout and fixed layout shifting in the Hero section. The platform is now faster and more stable.',
    type: 'fix'
  },
  {
    id: 'announcement-founders-era',
    date: today,
    title: 'Welcome to the Founder\'s Era',
    description: 'Social Butterfly-AI is no longer just a chatbot—it is a Launchpad. With the new MVP Builder (Vibe Coding), you can turn text into functional software prototypes in seconds. We have also introduced the "Founder\'s Roadmap" to guide you through domains, hosting, and scaling. Your empire starts today.',
    type: 'feature'
  },
  {
    id: 'feat-site-architect',
    date: today,
    title: 'New Feature: MVP Builder',
    description: 'Describe your dream tool, dashboard, or app, and I\'ll build the functional prototype right before your eyes. Includes a full code inspector and export options for Founders.',
    type: 'feature'
  },
  {
    id: 'info-veo-beta',
    date: today,
    title: 'Video Studio (Veo) in BETA',
    description: 'Video and Animation features are currently in BETA. Due to high demand and strict low-provisioning policies from Google Cloud, video generation limits are currently restricted. We have requested increased quotas and expect higher limits soon. Thank you for your patience as we scale!',
    type: 'improvement'
  },
  {
    id: 'feat-trial-300',
    date: today,
    title: 'New Free Trial System',
    description: 'We have updated our onboarding! New users now receive a one-time grant of 100 credits to fully explore the platform—including chat, images, and strategy tools—before needing a subscription.',
    type: 'feature'
  },
  {
    id: 'fix-admin-plan-visibility',
    date: today,
    title: 'Admin Dashboard & Provisioning',
    description: 'Improved the Admin Dashboard to show billing cycles (Monthly/Annual) and hardened the subscription provisioning logic to prevent credit errors.',
    type: 'improvement'
  },
  {
    id: 'fix-mobile-overlap',
    date: today,
    title: 'Mobile Interface Fix',
    description: 'Fixed a critical issue where the main sidebar overlapped with the Image Studio and other creative tools on mobile devices.',
    type: 'fix'
  },
  {
    id: 'fix-watermark',
    date: today,
    title: 'Watermark Rendering',
    description: 'Resolved an issue where the Butterfly logo watermark was not appearing on generated images.',
    type: 'fix'
  },
  {
    id: 'fix-profile-persistence',
    date: today,
    title: 'Profile Persistence',
    description: 'Fixed an issue where profile photos and business details might not save correctly. Your profile is now rock solid.',
    type: 'fix'
  },
  {
    id: 'feat-api-integration',
    date: today,
    title: 'Full Feature Activation',
    description: 'Great news! Image Generation, Video Generation (Veo), Image Editing, and Document Analysis are now fully connected to the AI engine. You can start creating immediately.',
    type: 'feature'
  },
  {
    id: 'feat-account-mgmt-v2',
    date: today,
    title: 'Account Management & Settings',
    description: 'You now have more control! We added a dedicated Account tab in Settings where you can view your plan details, upgrade your subscription easily, update your password, and manage your account data.',
    type: 'feature'
  }
];
