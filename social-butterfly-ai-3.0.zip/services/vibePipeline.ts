
import { GoogleGenAI } from "@google/genai";
import { MODEL_SMART } from "../components/aiConfig";
import { agentRegistry } from "../agents/registry";

export interface AestheticProfile {
  style: string;
  styleLabel: string;
  styleDesc: string;
  font: string;
  fontLabel: string;
  tone: string;
  toneLabel: string;
  personality: string;
  primaryColor: string;
}

export interface BuildContext {
  userPrompt: string; // The specific request (e.g., "Change the button color")
  chatHistory: { role: string; text: string }[]; // Full conversation context
  aesthetic: AestheticProfile;
  currentCode?: string; // For refinements
  isRefinement: boolean;
}

export interface PipelineResult {
  code: string;
  prdSummary?: string;
  metadata: {
    model: string;
    timestamp: string;
  };
}

/**
 * Vibe Coding Build Pipeline
 * Phase 2 Engine - The Core Build Pipeline
 * 
 * Implements the mandatory sequence:
 * 1. Context Assembly
 * 2. Architect Invocation
 * 3. Vibe Reasoning (Internal)
 * 4. Code Generation
 * 5. Extraction & Sanitization
 */
export class VibePipeline {
  private ai: GoogleGenAI;

  constructor(apiKey: string) {
    this.ai = new GoogleGenAI({ apiKey });
  }

  /**
   * STEP 5 - Code Extraction & Sanitization
   * Robust regex engine to ensure valid HTML output.
   */
  private sanitizeOutput(rawText: string): string {
    let code = rawText;

    // 1. Remove conversational filler (Markdown blocks)
    // Priority: DOCTYPE html -> html tag -> markdown block
    const fullDocMatch = rawText.match(/<!DOCTYPE html>[\s\S]*<\/html>/i);
    if (fullDocMatch) {
      code = fullDocMatch[0];
    } else {
      const htmlMatch = rawText.match(/<html[\s\S]*<\/html>/i);
      if (htmlMatch) {
        code = htmlMatch[0];
      } else {
        // Fallback: extract from markdown fence
        const fenceMatch = rawText.match(/```(html|jsx|tsx)?([\s\S]*?)```/);
        if (fenceMatch && fenceMatch[2]) {
          code = fenceMatch[2].trim();
        }
      }
    }

    // 2. Validate/Patch DOCTYPE
    if (!code.trim().toLowerCase().startsWith('<!doctype html>')) {
      code = `<!DOCTYPE html>\n${code}`;
    }

    // 3. Auto-fix common hallucinations (e.g., "import React" in CDN mode)
    // We enforce Babel Standalone, so standard ESM imports often break it.
    // We attempt to patch standard React imports to const destructuring if they exist in a script tag.
    if (code.includes('import React') && code.includes('type="text/babel"')) {
        // Simple patch: Comment out imports, assume React is global via CDN
        code = code.replace(/import\s+React.*?from\s+['"]react['"];?/g, '// import React from "react";');
        code = code.replace(/import\s+ReactDOM.*?from\s+['"]react-dom\/client['"];?/g, '// import ReactDOM from "react-dom/client";');
        
        // Ensure destructuring exists if not present
        if (!code.includes('const { useState, useEffect } = React')) {
             // Inject after the commented out import or at start of script
             code = code.replace('<script type="text/babel">', '<script type="text/babel">\nconst { useState, useEffect, useRef, useMemo } = React;\n');
        }
    }

    return code;
  }

  /**
   * STEP 1 - Context Assembly & STEP 2 - Architect Invocation
   */
  async execute(context: BuildContext): Promise<PipelineResult> {
    
    // 1. Context Assembly
    const historyText = context.chatHistory.map(m => `${m.role.toUpperCase()}: ${m.text}`).join('\n');
    
    const aestheticBlock = `
    **BRAND AESTHETIC PROFILE:**
    - Style: ${context.aesthetic.styleLabel} (${context.aesthetic.styleDesc})
    - Typography: ${context.aesthetic.fontLabel}
    - Tone: ${context.aesthetic.toneLabel}
    - Personality: ${context.aesthetic.personality || "Professional & Polished"}
    - Primary Color: ${context.aesthetic.primaryColor}
    `;

    const requirementBlock = context.isRefinement 
        ? `
        **TASK: REFINEMENT**
        The user wants to modify the existing app.
        
        **USER REQUEST:**
        "${context.userPrompt}"
        
        **EXISTING CODE:**
        (See attached code context below. You must output the FULL updated code, not just diffs.)
        ` 
        : `
        **TASK: NEW BUILD**
        Create a new Single Page Application (SPA) based on the conversation history.
        `;

    // 2. Architect Invocation Prompt
    // We wrap the specific Vibe Architect System Prompt from the registry
    const prompt = `
    ${agentRegistry.vibeArchitect.systemPrompt}

    ---
    
    **INPUT DATA:**
    
    ${aestheticBlock}

    **CONVERSATION HISTORY:**
    ${historyText}

    ${requirementBlock}

    **TECHNICAL CONSTRAINTS (STRICT):**
    1. Output a **SINGLE HTML FILE** containing CSS (Tailwind CDN), JS (Babel Standalone), and HTML.
    2. Use **React 18** functional components.
    3. Use **Lucide React** (global variable \`lucide\`) for icons. Example: \`<i data-lucide="home"></i>\` and call \`lucide.createIcons()\` in useEffect. OR use standard SVG icons if Lucide is risky.
    4. **NO** local imports. Use CDN links provided in your knowledge base.
    5. **NO** placeholder comments like "// rest of code". Write full, working code.
    6. **IMAGES:** Use \`https://source.unsplash.com/random/800x600/?{keyword}\`.

    **EXECUTE:**
    Generate the code now.
    `;

    try {
        // AI Call
        const response = await this.ai.models.generateContent({
            model: MODEL_SMART,
            contents: [
                { role: 'user', parts: [{ text: prompt }] },
                // If refinement, pass previous code as a separate context part to avoid token overload in main prompt if possible,
                // or just append to text. For simplicity in this v1 pipeline, we append if it exists.
                ...(context.currentCode ? [{ role: 'user', parts: [{ text: `Here is the CURRENT CODE to update:\n\n${context.currentCode}` }] }] : [])
            ],
            config: {
                // Ensure high creativity but strict format
                temperature: 0.7, 
            }
        });

        const rawText = response.text || "";

        // STEP 5: Sanitization
        const cleanCode = this.sanitizeOutput(rawText);

        // Optional: Extract PRD/Summary if the model output included it separately
        // For now, we assume the Vibe Architect prompt directs it to output code primarily.
        
        return {
            code: cleanCode,
            metadata: {
                model: MODEL_SMART,
                timestamp: new Date().toISOString()
            }
        };

    } catch (error) {
        console.error("Vibe Pipeline Error:", error);
        throw error;
    }
  }
}
