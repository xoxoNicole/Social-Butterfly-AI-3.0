
import { MODEL_SMART } from './aiConfig';
import React, { useState, useEffect, useRef } from 'react';
import LoadingSpinner from './LoadingSpinner';
import { UserProfile, saveMVPProject, subscribeToMVPProjects, MVPProject, deleteMVPProject } from '../services/firebase';
import { GoogleGenAI } from '@google/genai';
import { agentRegistry } from '../agents/registry';
import { VibePipeline, BuildContext } from '../services/vibePipeline';


interface MVPBuilderModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onGenerate: (prompt: string, style: string, currentCode?: string, refinementRequest?: string) => Promise<string>;
  isLoading: boolean;
}

// --- Affiliate Links Configuration ---
const AFFILIATE_LINKS = {
    domain: "https://www.ionos.com/domain-names", 
    firebase: "https://console.firebase.google.com",
    github: "https://github.com",
    workspace: "https://referworkspace.app.goo.gl/jXNA", 
    startup: "https://startup.google.com",
    api: "https://aistudio.google.com"
};

// --- PRD: Aesthetic Intelligence Vocabulary ---
const styles = [
    { id: 'modern', label: 'Modern Clean', desc: 'High whitespace, clean typography, trustworthy. Good for SaaS.' },
    { id: 'bold', label: 'Bold & Dark', desc: 'Dark mode, high contrast, neon accents. Good for Web3/Gaming.' },
    { id: 'editorial', label: 'Editorial / Luxury', desc: 'Serif headers, large images, magazine feel. Good for Fashion/Lifestyle.' },
    { id: 'afrofuturism', label: 'Afrofuturism', desc: 'Radiant tech, deep cosmic backgrounds, gold/teal accents, cinematic depth.' },
    { id: 'steampunk', label: 'Steampunk', desc: 'Brass, copper, mechanical details, warmth, retro-future structure.' },
    { id: 'solarpunk', label: 'Solarpunk', desc: 'Organic shapes, bright greens, glass, nature-tech fusion.' },
    { id: 'saas', label: 'Enterprise Tech', desc: 'Bento-grids, glassmorphism, blue/purple gradients. Trustworthy.' },
    { id: 'minimal', label: 'Ultra Minimal', desc: 'Monochrome, text-focused, raw lines. Brutalist hints.' },
    { id: 'soft', label: 'Soft & Friendly', desc: 'Pastels, rounded corners, playful typography. Good for Consumer Apps.' },
    { id: 'cyberpunk', label: 'Cyberpunk / Neon', desc: 'Glitch effects, vibrant neons, dark backgrounds. Good for AI/Future tech.' },
    { id: 'whimsical', label: 'Wes Anderson', desc: 'Symmetrical, pastel palette, quirky typography, distinct framing.' }
];

const fonts = [
    { id: 'sans', label: 'Clean Sans (Inter/Plus Jakarta)', value: 'font-sans' },
    { id: 'serif', label: 'Editorial Serif (Playfair/Merriweather)', value: 'font-serif' },
    { id: 'mono', label: 'Technical Mono (JetBrains/Roboto Mono)', value: 'font-mono' },
];

const emotionalTones = [
    { id: 'trust', label: 'Trust & Authority' },
    { id: 'excitement', label: 'Excitement & Energy' },
    { id: 'calm', label: 'Calm & Wellness' },
    { id: 'luxury', label: 'Exclusive & Luxury' },
    { id: 'friendly', label: 'Friendly & Approachable' },
    { id: 'innovative', label: 'Bold & Innovative' }
];

interface ChatMessage {
    role: 'user' | 'model';
    text: string;
    image?: { base64: string, mimeType: string };
}

interface EngineeringStep {
    id: string;
    title: string;
    description: string;
    status: 'pending' | 'in-progress' | 'completed' | 'error';
    logs: string[];
    link?: string;
    linkText?: string;
}

const blobToBase64 = (blob: Blob): Promise<{ base64: string, mimeType: string }> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            if (typeof reader.result !== 'string') {
                return reject(new Error('File could not be read as a string.'));
            }
            const base64String = reader.result.split(',')[1];
            resolve({ base64: base64String, mimeType: blob.type });
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
};

// --- ENGINEERING COCKPIT (PHASE 3) ---
const EngineeringCockpit = ({ 
    code, 
    userProfile,
    onBack
}: { 
    code: string | null, 
    userProfile: UserProfile,
    onBack: () => void 
}) => {
    const [activeStepId, setActiveStepId] = useState('setup');
    const [steps, setSteps] = useState<EngineeringStep[]>([
        { id: 'setup', title: 'Setup & Verification', description: 'Analyze project structure, dependencies, and framework.', status: 'pending', logs: [] },
        { id: 'firebase', title: 'Firebase Backend', description: 'Link project, config Auth, and secure Firestore rules.', status: 'pending', logs: [] },
        { id: 'domain', title: 'Domain & SSL', description: 'Connect custom domain via IONOS or Firebase.', status: 'pending', logs: [], link: AFFILIATE_LINKS.domain, linkText: 'Get Domain ($1)' },
        { id: 'api', title: 'Gemini API Key', description: 'Securely inject API keys into environment variables.', status: 'pending', logs: [], link: AFFILIATE_LINKS.api, linkText: 'Get API Key' },
        { id: 'git', title: 'Version Control', description: 'Initialize GitHub repo and generate documentation.', status: 'pending', logs: [], link: AFFILIATE_LINKS.github, linkText: 'Connect GitHub' },
        { id: 'deploy', title: 'Production Launch', description: 'Final build, optimization, and global deployment.', status: 'pending', logs: [] },
        { id: 'scale', title: 'Scale & Growth', description: 'Apply to Google for Startups program.', status: 'pending', logs: [], link: AFFILIATE_LINKS.startup, linkText: 'Apply to Program' }
    ]);
    
    // Virtual File System for the Workspace
    const [virtualFiles, setVirtualFiles] = useState<Record<string, string>>({
        'index.html': code || '<!-- No code generated yet -->',
        'package.json': '{\n  "name": "sb-app",\n  "version": "1.0.0",\n  "scripts": {\n    "start": "vite",\n    "build": "vite build"\n  }\n}',
        'firebase.json': '{\n  "hosting": {\n    "public": "dist",\n    "ignore": ["firebase.json", "**/.*", "**/node_modules/**"]\n  }\n}',
        '.env.local': 'VITE_API_KEY=your_key_here'
    });
    const [activeFile, setActiveFile] = useState('index.html');

    // Engineering Agent Chat
    const [agentHistory, setAgentHistory] = useState<ChatMessage[]>([]);
    const [agentInput, setAgentInput] = useState('');
    const [isAgentThinking, setIsAgentThinking] = useState(false);
    const aiRef = useRef<GoogleGenAI | null>(null);
    const chatContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (process.env.API_KEY) {
            aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY });
        }
        // Initial Greeting
        setAgentHistory([{
            role: 'model',
            text: `**Engineering Agent Online.** 🟢\n\nI'm ready to take this prototype to production. We will move through the deployment checklist on the left.\n\nSelect **Setup & Verification** to begin the pre-flight checks.`
        }]);
    }, []);

    useEffect(() => {
        if(chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
    }, [agentHistory]);

    const handleStepClick = (stepId: string) => {
        setActiveStepId(stepId);
        // Contextual Greeting based on step
        const step = steps.find(s => s.id === stepId);
        if (step) {
            const contextMsg = getContextMessageForStep(stepId);
            setAgentHistory(prev => [...prev, { role: 'model', text: contextMsg }]);
        }
    };

    const getContextMessageForStep = (stepId: string) => {
        switch(stepId) {
            case 'setup': return "I'll analyze your `index.html` to determine the framework and dependencies. I can then generate a `package.json` for you. Ready to run diagnostics?";
            case 'firebase': return `To deploy, we need a target. Create a project in the <a href="${AFFILIATE_LINKS.firebase}" target="_blank" class="text-[#4FFFB0] underline">Firebase Console</a>.\n\nOnce created, paste your \`firebaseConfig\` object here, and I'll format it for the app.`;
            case 'domain': return `A custom domain builds trust. You can buy one for $1 at IONOS or use a free \`.web.app\` subdomain.\n\nWhich route are we taking today?`;
            case 'api': return `**Security Alert:** Never commit API keys to code. I'll help you set up a \`.env\` file.\n\nDo you have your Gemini API key ready?`;
            case 'git': return "Let's lock this version in. I can generate a `.gitignore` and a `README.md` for your repository. Shall I proceed?";
            case 'deploy': return "Final approach. All systems green. \n\nRun `npm run build` locally or let me generate the build command for you.";
            case 'scale': return "Your app is live! Now, let's look at growth. You might be eligible for the Google for Startups Cloud Program. Want the details?";
            default: return "Ready.";
        }
    };

    const updateStepStatus = (id: string, status: EngineeringStep['status']) => {
        setSteps(prev => prev.map(s => s.id === id ? { ...s, status } : s));
    };

    const addLog = (stepId: string, message: string) => {
        setSteps(prev => prev.map(s => s.id === stepId ? { ...s, logs: [...s.logs, `> ${message}`] } : s));
    };

    const handleAgentSend = async () => {
        if (!agentInput.trim() || isAgentThinking) return;
        const msg = agentInput;
        setAgentInput('');
        setAgentHistory(prev => [...prev, { role: 'user', text: msg }]);
        setIsAgentThinking(true);

        try {
            if (!aiRef.current) throw new Error("AI not initialized");

            const activeStep = steps.find(s => s.id === activeStepId);
            
            // SIMULATED AGENT ACTIONS (Real implementation would use Function Calling)
            if (activeStepId === 'setup' && (msg.toLowerCase().includes('run') || msg.toLowerCase().includes('yes') || msg.toLowerCase().includes('ok'))) {
                updateStepStatus('setup', 'in-progress');
                setTimeout(() => addLog('setup', 'Analyzing index.html imports...'), 500);
                setTimeout(() => addLog('setup', 'Detected React 18 (CDN)'), 1000);
                setTimeout(() => addLog('setup', 'Detected Tailwind CSS'), 1500);
                setTimeout(() => {
                    addLog('setup', 'Dependency Check: PASS');
                    updateStepStatus('setup', 'completed');
                    setAgentHistory(prev => [...prev, { role: 'model', text: "✅ **Diagnostic Complete.**\n\n- React 18: OK\n- Tailwind: OK\n- Icons: Lucide-React OK\n\nI have verified the project structure. You can proceed to **Firebase Backend**." }]);
                    setIsAgentThinking(false);
                }, 2000);
                return;
            }

            // Default LLM Chat with SPECIFIC SYSTEM PROMPT from Registry
            const systemPrompt = `
${agentRegistry.engineering.systemPrompt}

**CURRENT CONTEXT:**
- User Stage: ${activeStep?.title}
- Goal: ${activeStep?.description}
            `;

            const chat = aiRef.current.chats.create({
                model: MODEL_SMART,
                config: { systemInstruction: systemPrompt },
                history: agentHistory.map(m => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.text }] }))
            });

            const result = await chat.sendMessage({ message: msg });
            setAgentHistory(prev => [...prev, { role: 'model', text: result.text || "I didn't catch that." }]);

        } catch (error) {
            console.error("Agent Error", error);
            setAgentHistory(prev => [...prev, { role: 'model', text: "Connection error. Please try again." }]);
        } finally {
            setIsAgentThinking(false);
        }
    };

    return (
        <div className="flex h-full bg-[#050505] text-white overflow-hidden animate-fadeIn">
            {/* LEFT PANEL: CHECKLIST */}
            <div className="w-1/4 bg-[#09090b] border-r border-white/10 flex flex-col">
                <div className="p-4 border-b border-white/10">
                    <button onClick={onBack} className="flex items-center text-xs text-gray-500 hover:text-white mb-4 transition-colors">
                        <span className="material-icons text-sm mr-1">arrow_back</span> Back to Builder
                    </button>
                    <h3 className="font-bold text-white font-['Outfit'] uppercase tracking-widest text-sm flex items-center">
                        <span className="material-icons text-[#4FFFB0] mr-2 text-sm">engineering</span>
                        Engineering Cockpit
                    </h3>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-1">
                    {steps.map((step, idx) => (
                        <div 
                            key={step.id}
                            onClick={() => handleStepClick(step.id)}
                            className={`p-3 rounded-lg cursor-pointer transition-all border ${activeStepId === step.id ? 'bg-[#4FFFB0]/5 border-[#4FFFB0]/30' : 'bg-transparent border-transparent hover:bg-white/5'}`}
                        >
                            <div className="flex justify-between items-start mb-1">
                                <span className={`text-xs font-bold ${activeStepId === step.id ? 'text-[#4FFFB0]' : 'text-gray-400'}`}>
                                    {idx + 1}. {step.title}
                                </span>
                                {step.status === 'completed' && <span className="material-icons text-green-500 text-xs">check_circle</span>}
                                {step.status === 'in-progress' && <span className="material-icons text-yellow-500 text-xs animate-spin">sync</span>}
                                {step.status === 'error' && <span className="material-icons text-red-500 text-xs">error</span>}
                            </div>
                            <p className="text-[10px] text-gray-500 leading-tight mb-2">{step.description}</p>
                            
                            {step.link && (
                                <a href={step.link} target="_blank" rel="noreferrer" className="text-[10px] text-[#E0B069] hover:underline flex items-center mb-1" onClick={(e) => e.stopPropagation()}>
                                    {step.linkText} <span className="material-icons text-[10px] ml-1">open_in_new</span>
                                </a>
                            )}

                            {/* Logs Preview */}
                            {step.logs.length > 0 && activeStepId === step.id && (
                                <div className="mt-2 bg-black/50 p-2 rounded text-[10px] font-mono text-gray-400 border border-white/5">
                                    {step.logs.slice(-2).map((l, i) => <div key={i}>{l}</div>)}
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            </div>

            {/* CENTER PANEL: WORKSPACE */}
            <div className="flex-1 bg-[#0c0c0e] flex flex-col border-r border-white/10 relative">
                {/* File Tabs */}
                <div className="flex bg-[#09090b] border-b border-white/10 overflow-x-auto">
                    {Object.keys(virtualFiles).map(file => (
                        <button
                            key={file}
                            onClick={() => setActiveFile(file)}
                            className={`px-4 py-2 text-xs font-mono border-r border-white/5 flex items-center ${activeFile === file ? 'bg-[#1e1e1e] text-[#4FFFB0]' : 'text-gray-500 hover:text-white'}`}
                        >
                            {file === 'index.html' && <span className="material-icons text-[10px] mr-1 text-orange-400">html</span>}
                            {file.endsWith('.json') && <span className="material-icons text-[10px] mr-1 text-yellow-400">data_object</span>}
                            {file.startsWith('.') && <span className="material-icons text-[10px] mr-1 text-gray-400">settings</span>}
                            {file}
                        </button>
                    ))}
                </div>
                
                {/* Code Editor Area */}
                <div className="flex-1 relative">
                    <textarea 
                        value={virtualFiles[activeFile]}
                        readOnly
                        className="w-full h-full bg-[#0c0c0e] text-gray-300 font-mono text-xs p-4 resize-none outline-none focus:ring-0"
                    />
                    {/* Action Bar Overlay */}
                    <div className="absolute bottom-4 right-4 flex space-x-2">
                        <button className="px-3 py-1.5 bg-[#4FFFB0] text-black text-xs font-bold rounded-md hover:bg-white transition-colors shadow-lg flex items-center">
                            <span className="material-icons text-xs mr-1">download</span>
                            Download Config
                        </button>
                    </div>
                </div>
            </div>

            {/* RIGHT PANEL: ENGINEERING AGENT */}
            <div className="w-1/3 bg-[#09090b] flex flex-col">
                <div className="p-3 border-b border-white/10 bg-[#121215] flex justify-between items-center">
                    <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">Engineering Agent</span>
                    <div className="flex items-center space-x-1">
                        <div className={`w-2 h-2 rounded-full ${isAgentThinking ? 'bg-yellow-500 animate-pulse' : 'bg-green-500'}`}></div>
                        <span className="text-[10px] text-gray-500">{isAgentThinking ? 'Processing...' : 'Online'}</span>
                    </div>
                </div>
                
                <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
                    {agentHistory.map((msg, i) => (
                        <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[90%] p-3 rounded-xl text-xs leading-relaxed ${msg.role === 'user' ? 'bg-[#4FFFB0]/10 text-[#4FFFB0] border border-[#4FFFB0]/20 rounded-br-none' : 'bg-[#18181b] text-gray-300 border border-white/10 rounded-bl-none'}`}>
                                <div dangerouslySetInnerHTML={{ __html: msg.text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }} />
                            </div>
                        </div>
                    ))}
                    {isAgentThinking && (
                        <div className="flex justify-start">
                            <div className="bg-[#18181b] p-2 rounded-xl rounded-bl-none border border-white/10">
                                <LoadingSpinner />
                            </div>
                        </div>
                    )}
                </div>

                <div className="p-3 border-t border-white/10 bg-[#09090b]">
                    <form onSubmit={(e) => { e.preventDefault(); handleAgentSend(); }} className="relative">
                        <input 
                            type="text" 
                            value={agentInput}
                            onChange={(e) => setAgentInput(e.target.value)}
                            placeholder="Ask Engineering Agent..."
                            className="w-full pl-3 pr-10 py-2.5 bg-[#121215] border border-white/10 rounded-lg text-xs text-white focus:border-[#4FFFB0] focus:ring-1 focus:ring-[#4FFFB0] outline-none font-mono"
                            disabled={isAgentThinking}
                        />
                        <button 
                            type="submit" 
                            disabled={!agentInput.trim() || isAgentThinking}
                            className="absolute right-2 top-2 text-[#4FFFB0] hover:text-white disabled:opacity-50"
                        >
                            <span className="material-icons text-sm">send</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

const MVPBuilderModal: React.FC<MVPBuilderModalProps> = ({ isOpen, onClose, userProfile, onGenerate, isLoading: parentIsLoading }) => {
  // Visual Settings (Brand Aesthetic Profile - PRD 6)
  const [selectedStyle, setSelectedStyle] = useState(styles[0].id);
  const [selectedFont, setSelectedFont] = useState(fonts[0].id);
  const [brandPersonality, setBrandPersonality] = useState(''); 
  const [primaryColorInput, setPrimaryColorInput] = useState('#4FFFB0');
  const [emotionalTone, setEmotionalTone] = useState(emotionalTones[0].id);
  
  // Project Context
  const [currentProjectId, setCurrentProjectId] = useState<string | null>(null);
  const [projects, setProjects] = useState<MVPProject[]>([]);
  const [showProjectList, setShowProjectList] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  
  // Site State
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);
  const [prdContent, setPrdContent] = useState<string | null>(null);
  
  // UI State
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState<'chat' | 'design' | 'gallery' | 'learn' | 'deploy'>('chat');
  const [showCode, setShowCode] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  
  // Chat State
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [attachedImage, setAttachedImage] = useState<{ file: File, preview: string, base64: string, mimeType: string } | null>(null);
  
  const chatEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Voice State
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  // AI Instance
  const aiRef = useRef<GoogleGenAI | null>(null);
  const pipelineRef = useRef<VibePipeline | null>(null);

  // Combine loading states
  const isLoading = parentIsLoading || isGenerating;

  // --- Initialization ---

  useEffect(() => {
      if (process.env.API_KEY) {
          aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY });
          pipelineRef.current = new VibePipeline(process.env.API_KEY);
      }
  }, []);

  // Subscribe to Projects
  useEffect(() => {
      if (isOpen && userProfile.uid) {
          const unsubscribe = subscribeToMVPProjects(userProfile.uid, (data) => {
              setProjects(data);
          });
          return () => unsubscribe();
      }
  }, [isOpen, userProfile.uid]);

  // Initialize Speech Recognition
  useEffect(() => {
      if (typeof window !== 'undefined') {
          const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
          if (SpeechRecognition) {
              const recognition = new SpeechRecognition();
              recognition.continuous = false;
              recognition.interimResults = false;
              recognition.lang = 'en-US';
              
              recognition.onresult = (event: any) => {
                  const transcript = event.results[0][0].transcript;
                  setChatInput(prev => prev ? `${prev} ${transcript}` : transcript);
                  setIsListening(false);
              };
              
              recognition.onerror = (event: any) => {
                  console.error("Speech recognition error", event.error);
                  setIsListening(false);
              };
              
              recognition.onend = () => {
                  setIsListening(false);
              };
              
              recognitionRef.current = recognition;
          }
      }
  }, []);

  // Auto-expand textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 300)}px`; 
    }
  }, [chatInput]);

  // Reset on Open
  useEffect(() => {
      if (isOpen && !currentProjectId) {
          const welcomeMsg = `I am Vibe Architect (v1.0). 🏗️\n\nI combine Product Strategy, UX Design, and Full-Stack Engineering.\n\nTell me your business idea, and I will validate it, architect the solution, and write the production-ready code.`;
          setChatHistory([{ role: 'model', text: welcomeMsg }]);
          setGeneratedCode(null);
          setPrdContent(null);
          setIsSidebarOpen(true);
          setIsGenerating(false);
      }
  }, [isOpen, currentProjectId]);

  useEffect(() => {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory, activeTab]);

  // --- Handlers ---

  const toggleListening = () => {
      if (!recognitionRef.current) {
          alert("Voice input is not supported in this browser.");
          return;
      }
      if (isListening) {
          recognitionRef.current.stop();
      } else {
          recognitionRef.current.start();
          setIsListening(true);
      }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const preview = URL.createObjectURL(file);
          const { base64, mimeType } = await blobToBase64(file);
          setAttachedImage({ file, preview, base64, mimeType });
      }
  };

  const removeAttachedImage = () => {
      if (attachedImage) URL.revokeObjectURL(attachedImage.preview);
      setAttachedImage(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleClearChat = () => {
      if (window.confirm("Clear chat history? This frees up 'memory' for the AI but keeps your current code.")) {
          setChatHistory([{ role: 'model', text: "Memory cleared. I'm ready for the next task." }]);
      }
  };

  const handleSendMessage = async (msgOverride?: string) => {
      const userMsg = msgOverride || chatInput;
      const imageToSend = attachedImage;

      if ((!userMsg.trim() && !imageToSend) || isChatLoading) return;

      setChatInput('');
      removeAttachedImage();
      
      // Optimistically add user message
      const newMsg: ChatMessage = { role: 'user', text: userMsg };
      if (imageToSend) {
          newMsg.image = { base64: imageToSend.base64, mimeType: imageToSend.mimeType };
      }
      setChatHistory(prev => [...prev, newMsg]);
      setIsChatLoading(true);

      try {
          if (!aiRef.current) throw new Error("AI not initialized");

          // SYSTEM PROMPT - Vibe Architect Phase 1 Logic
          const systemInstruction = agentRegistry.vibeArchitect.systemPrompt;

          const history = chatHistory
            .filter(msg => (msg.text && msg.text.trim().length > 0) || msg.image)
            .map(msg => {
                const parts: any[] = [];
                if (msg.image) parts.push({ inlineData: { data: msg.image.base64, mimeType: msg.image.mimeType } });
                if (msg.text) parts.push({ text: msg.text });
                return { role: msg.role === 'user' ? 'user' : 'model', parts };
            });

         const chat = aiRef.current.chats.create({
              model: MODEL_SMART, 
              config: { systemInstruction },
              history
          });

          const partsToSend = [];
          if (imageToSend) partsToSend.push({ inlineData: { data: imageToSend.base64, mimeType: imageToSend.mimeType } });
          if (userMsg) partsToSend.push({ text: userMsg });

          const result = await chat.sendMessage({ message: partsToSend });
          let responseText = result.text || "I'm having trouble processing that request right now.";

          setChatHistory(prev => [...prev, { role: 'model', text: responseText }]);

      } catch (error) {
          console.error("Chat Error:", error);
          let errorMsg = "I'm having trouble connecting. Please try again.";
          if (error instanceof Error) errorMsg += ` (${error.message})`;
          setChatHistory(prev => [...prev, { role: 'model', text: errorMsg }]);
      } finally {
          setIsChatLoading(false);
      }
  };

  const handleRenderApp = async () => {
      if (!pipelineRef.current) return;
      setIsGenerating(true);
      
      // --- 3-STAGE LOADING SEQUENCE ---
      // Defined in PRD Section 5: "Reasoning" -> "Applying Vibe" -> "Generating"
      setLoadingStep(1); // Reasoning
      
      // Simulate Reasoning Time (2s)
      await new Promise(r => setTimeout(r, 2000));
      setLoadingStep(2); // Applying Vibe
      
      // Simulate Vibe Application Time (2s)
      await new Promise(r => setTimeout(r, 2000));
      setLoadingStep(3); // Generating

      try {
        const buildContext: BuildContext = {
            userPrompt: chatHistory[chatHistory.length - 1]?.text || "Build app",
            chatHistory: chatHistory.map(m => ({ role: m.role, text: m.text })),
            aesthetic: {
                style: styles.find(s => s.id === selectedStyle)?.id || 'modern',
                styleLabel: styles.find(s => s.id === selectedStyle)?.label || 'Modern',
                styleDesc: styles.find(s => s.id === selectedStyle)?.desc || '',
                font: fonts.find(f => f.id === selectedFont)?.id || 'sans',
                fontLabel: fonts.find(f => f.id === selectedFont)?.label || 'Sans',
                tone: emotionalTones.find(t => t.id === emotionalTone)?.id || 'trust',
                toneLabel: emotionalTones.find(t => t.id === emotionalTone)?.label || 'Trust',
                personality: brandPersonality,
                primaryColor: primaryColorInput
            },
            currentCode: generatedCode || undefined,
            isRefinement: !!generatedCode
        };

        const result = await pipelineRef.current.execute(buildContext);
        
        setGeneratedCode(result.code);
        
        // Auto-save the project so it persists
        const projectId = currentProjectId || `${Date.now()}`;
        const name = chatHistory.find(m => m.role === 'user')?.text.substring(0, 30) || 'Untitled MVP';
        
        const projectData: MVPProject = {
            id: projectId,
            name,
            style: selectedStyle,
            font: selectedFont,
            chatHistory: chatHistory.map(m => ({ role: m.role, text: m.text })), 
            generatedCode: result.code,
            prdContent: prdContent,
            updatedAt: new Date().toISOString()
        };
        
        if (userProfile.uid) {
            await saveMVPProject(userProfile.uid, projectData);
            setCurrentProjectId(projectId);
            setSaveStatus('saved');
        }

        setShowConfetti(true);
        setTimeout(() => setShowConfetti(false), 5000);

        setChatHistory(prev => [...prev, { 
            role: 'model', 
            text: `**Vibe Architect Report:** 🏗️\n\nI have successfully translated your requirements into a functional prototype.\n\n- **Aesthetic:** Applied ${styles.find(s => s.id === selectedStyle)?.label} logic.\n- **Architecture:** Single Page React App (SPA).\n\nClick **"Preview"** to verify the build. If you need changes (e.g., "Move the button", "Darker mode"), just ask.` 
        }]);
        
        if (window.innerWidth < 768) {
            setIsSidebarOpen(false);
        }

      } catch (error) {
          console.error("Render Error:", error);
          setChatHistory(prev => [...prev, { role: 'model', text: "❌ The Architect encountered a compilation error. Please try again." }]);
      } finally {
          setIsGenerating(false);
          setLoadingStep(0);
      }
  };

  // --- Project Management ---

  const handleSaveProject = async () => {
      if (!userProfile.uid) return;
      setSaveStatus('saving');
      
      const projectId = currentProjectId || `${Date.now()}`;
      const name = chatHistory.find(m => m.role === 'user')?.text.substring(0, 30) || 'Untitled MVP';
      
      const projectData: MVPProject = {
          id: projectId,
          name,
          style: selectedStyle,
          font: selectedFont,
          chatHistory: chatHistory.map(m => ({ role: m.role, text: m.text })), // Exclude bulky images
          generatedCode,
          prdContent,
          updatedAt: new Date().toISOString()
      };
      
      try {
          await saveMVPProject(userProfile.uid, projectData);
          setCurrentProjectId(projectId);
          setSaveStatus('saved');
          setTimeout(() => setSaveStatus('idle'), 2000);
      } catch (e) {
          console.error("Save failed", e);
          setSaveStatus('idle');
          alert("Failed to save project. Check permissions.");
      }
  };

  const handleLoadProject = (project: MVPProject) => {
      setCurrentProjectId(project.id);
      setChatHistory(project.chatHistory);
      setGeneratedCode(project.generatedCode);
      setPrdContent(project.prdContent);
      setSelectedStyle(project.style);
      setSelectedFont(project.font);
      setShowProjectList(false);
  };

  const handleDeleteProject = async (projectId: string, e: React.MouseEvent) => {
      e.stopPropagation();
      if (window.confirm("Delete this project?")) {
          await deleteMVPProject(userProfile.uid, projectId);
          if (currentProjectId === projectId) {
              setGeneratedCode(null);
              setChatHistory([]);
              setCurrentProjectId(null);
          }
      }
  };

  // --- Utility ---

  const handleFullScreenPreview = () => {
      if (!generatedCode) return;
      const newWindow = window.open();
      if (newWindow) {
          newWindow.document.write(generatedCode);
          newWindow.document.close();
      }
  };

  // --- Tabs Content ---

  const renderGallery = () => (
      <div className="flex-1 overflow-y-auto p-6 bg-[#09090b]">
          <h3 className="text-lg font-bold text-white mb-4 font-['Outfit']">Inspiration Gallery 2.0</h3>
          <p className="text-xs text-gray-400 mb-6">Curated premium patterns. Click to remix.</p>
          <div className="grid gap-6">
              {[
                  { 
                      title: "Zen Productivity", 
                      img: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?auto=format&fit=crop&w=400&q=80", 
                      prompt: "Build a 'Zen Pomodoro' timer. Use soft pastel gradients and a glassmorphism card. It needs a large countdown timer (25:00), buttons to start/pause/reset, and a simple task list below it. Add 3 toggle buttons for ambient sounds like 'Rain', 'Forest', 'Cafe'. Font: Sans-serif.",
                      style: "soft"
                  },
                  { 
                      title: "Crypto Dashboard", 
                      img: "https://images.unsplash.com/photo-1639322537228-f710d846310a?auto=format&fit=crop&w=400&q=80", 
                      prompt: "Create a 'Crypto Folio' dashboard in dark mode (Bold & Dark style). It should show a list of assets (BTC, ETH, SOL) with mock prices. When I click an asset, show a simple SVG line chart representing its 24h trend. Include a 'Total Balance' card with a neon green glow.",
                      style: "bold"
                  },
                  { 
                      title: "SaaS Landing Page", 
                      img: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=400&q=80", 
                      prompt: "Build a high-conversion landing page for an AI Analytics tool. Use the 'Enterprise Tech' style (Bento grids, blue gradients). Include a Hero section with a 'Get Started' button, a 'Features' grid with icons, and a 'Pricing' table. Trustworthy vibe.",
                      style: "saas"
                  },
                  { 
                      title: "Fashion Portfolio", 
                      img: "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=400&q=80", 
                      prompt: "Create an 'Editorial' style portfolio for a fashion photographer. Use a cream background and Serif fonts. Display images in a masonry grid. The header should be large and centered. Minimalist navigation.",
                      style: "editorial"
                  }
              ].map((item, idx) => (
                  <div key={idx} className="bg-white/5 rounded-xl shadow-sm border border-white/10 overflow-hidden hover:shadow-lg hover:border-[#4FFFB0]/30 transition-all group">
                      <div className="h-32 overflow-hidden relative">
                          <img src={item.img} alt={item.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                          <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                              <button 
                                  onClick={() => { 
                                      handleSendMessage(item.prompt); 
                                      setSelectedStyle(item.style || 'modern');
                                      setActiveTab('chat'); 
                                  }}
                                  className="px-4 py-2 bg-[#4FFFB0] text-black rounded-full text-xs font-bold transform translate-y-2 group-hover:translate-y-0 transition-transform"
                              >
                                  Remix this Vibe
                              </button>
                          </div>
                      </div>
                      <div className="p-3">
                          <h4 className="font-bold text-gray-200">{item.title}</h4>
                      </div>
                  </div>
              ))}
          </div>
      </div>
  );

  const renderLearn = () => (
      <div className="flex-1 overflow-y-auto p-6 bg-[#09090b] space-y-8">
          <div>
              <h3 className="text-lg font-bold text-white mb-4 flex items-center font-['Outfit']">
                  <span className="material-icons text-[#4FFFB0] mr-2">handyman</span>
                  The AI Tool Shed
              </h3>
              <div className="space-y-3">
                  <details className="group bg-white/5 rounded-lg p-3 border border-white/10 open:bg-white/10 open:shadow-sm">
                      <summary className="font-bold text-gray-200 cursor-pointer flex justify-between items-center">
                          Vibe Architect (The Brain)
                          <span className="material-icons text-gray-400 text-sm group-open:rotate-180 transition-transform">expand_more</span>
                      </summary>
                      <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                          Your AI co-founder. It uses the "5-Step Reasoning Model" to translate your vague ideas into precise technical requirements and code.
                      </p>
                  </details>
                  <details className="group bg-white/5 rounded-lg p-3 border border-white/10 open:bg-white/10 open:shadow-sm">
                      <summary className="font-bold text-gray-200 cursor-pointer flex justify-between items-center">
                          Gemini 3 Pro (The Engine)
                          <span className="material-icons text-gray-400 text-sm group-open:rotate-180 transition-transform">expand_more</span>
                      </summary>
                      <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                          The latest high-IQ model from Google. It handles complex logic, reasoning, and coding tasks with fewer hallucinations.
                      </p>
                  </details>
              </div>
          </div>
      </div>
  );

  if (!isOpen) return null;

  // --- ENGINEERING COCKPIT MODE ---
  if (activeTab === 'deploy') {
      return (
          <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 modal-backdrop" onClick={onClose}>
              <div className="bg-[#09090b] rounded-2xl shadow-2xl w-full max-w-7xl h-[95vh] flex flex-col overflow-hidden relative border border-white/10" onClick={e => e.stopPropagation()}>
                  <EngineeringCockpit 
                      code={generatedCode} 
                      userProfile={userProfile} 
                      onBack={() => setActiveTab('chat')}
                  />
              </div>
          </div>
      );
  }

  return (
    <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 modal-backdrop" onClick={onClose}>
      <div className="bg-[#09090b] rounded-2xl shadow-2xl w-full max-w-7xl h-[95vh] flex flex-col overflow-hidden relative border border-white/10" onClick={e => e.stopPropagation()}>
        
        {/* Confetti Animation Layer */}
        {showConfetti && (
            <div className="absolute inset-0 pointer-events-none z-50 overflow-hidden flex justify-center">
                <div className="confetti-container w-full h-full">
                    {[...Array(50)].map((_, i) => (
                        <div key={i} className="confetti-piece" style={{
                            left: `${Math.random() * 100}%`,
                            animationDelay: `${Math.random() * 2}s`,
                            backgroundColor: ['#4FFFB0', '#E0B069', '#ffffff', '#00E5FF'][Math.floor(Math.random() * 4)]
                        }}></div>
                    ))}
                </div>
                <style>{`
                    .confetti-piece {
                        position: absolute;
                        width: 10px;
                        height: 10px;
                        background: #f00;
                        top: -10px;
                        opacity: 0;
                        animation: fall 4s linear infinite;
                    }
                    @keyframes fall {
                        0% { top: -10px; transform: rotate(0deg); opacity: 1; }
                        100% { top: 100%; transform: rotate(360deg); opacity: 0; }
                    }
                `}</style>
            </div>
        )}

        {/* Header */}
        <div className="bg-[#18181b] p-3 md:p-4 flex justify-between items-center flex-shrink-0 border-b border-white/10">
             <div className="flex items-center space-x-3 text-white">
                <div className="p-2 bg-[#4FFFB0]/10 border border-[#4FFFB0]/30 rounded-lg hidden md:block overflow-hidden">
                    <img 
                        src="https://i.ibb.co/rf0yjBWH/SB-Tinker.png" 
                        alt="Builder" 
                        className="w-8 h-8 object-cover"
                    />
                </div>
                <div>
                    <h2 className="text-base md:text-lg font-bold tracking-wide flex items-center font-['Outfit'] text-white">
                        Vibe Architect
                        <span className="ml-2 text-[10px] bg-[#4FFFB0]/20 text-[#4FFFB0] px-2 py-0.5 rounded-full border border-[#4FFFB0]/40">v1.0</span>
                    </h2>
                </div>
            </div>
            <div className="flex items-center space-x-2 md:space-x-4">
                <button 
                    onClick={handleSaveProject}
                    className={`flex items-center space-x-1 text-xs md:text-sm font-medium px-3 py-1.5 rounded-md transition-colors border ${saveStatus === 'saved' ? 'bg-green-900/30 text-green-400 border-green-800' : 'bg-white/5 text-gray-300 border-white/10 hover:text-white hover:bg-white/10'}`}
                >
                    <span className="material-icons text-sm">{saveStatus === 'saved' ? 'check' : saveStatus === 'saving' ? 'sync' : 'save'}</span>
                    <span className="hidden md:inline">{saveStatus === 'saved' ? 'Saved!' : saveStatus === 'saving' ? 'Saving...' : 'Save'}</span>
                </button>
                
                <button 
                    onClick={() => setShowProjectList(!showProjectList)}
                    className="text-gray-300 hover:text-white flex items-center space-x-1 text-xs md:text-sm font-medium bg-white/5 px-3 py-1.5 rounded-md transition-colors border border-white/10 hover:bg-white/10 relative"
                >
                    <span className="material-icons text-sm">folder_open</span>
                    <span className="hidden md:inline">Projects</span>
                    {showProjectList && (
                        <div className="absolute top-full right-0 mt-2 w-64 bg-[#18181b] rounded-lg shadow-xl border border-white/10 overflow-hidden z-50 text-gray-200 animate-fadeIn">
                            <div className="p-3 border-b border-white/10 font-bold text-xs uppercase text-gray-500">Your Saved Projects</div>
                            <div className="max-h-60 overflow-y-auto custom-scrollbar">
                                {projects.length === 0 ? (
                                    <div className="p-4 text-center text-sm text-gray-500">No saved projects yet.</div>
                                ) : (
                                    projects.map(p => (
                                        <div key={p.id} className="flex items-center justify-between p-3 hover:bg-white/5 cursor-pointer border-b border-white/5 last:border-0" onClick={() => handleLoadProject(p)}>
                                            <div className="truncate text-sm font-medium">{p.name}</div>
                                            <button onClick={(e) => handleDeleteProject(p.id, e)} className="text-gray-500 hover:text-red-400 p-1 rounded">
                                                <span className="material-icons text-sm">delete</span>
                                            </button>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    )}
                </button>

                <div className="h-4 w-px bg-white/10 mx-1 md:mx-2"></div>
                
                <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className={`text-gray-300 hover:text-white flex items-center space-x-1 text-xs md:text-sm font-medium bg-white/5 px-3 py-1.5 rounded-md transition-colors ${!isSidebarOpen && 'text-[#4FFFB0] border border-[#4FFFB0]/50'}`}>
                    <span className="material-icons text-sm">{isSidebarOpen ? 'fullscreen' : 'menu_open'}</span>
                    <span className="hidden md:inline">{isSidebarOpen ? 'Hide Cockpit' : 'Open Cockpit'}</span>
                </button>
                <button onClick={onClose} className="text-gray-400 hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors">
                    <span className="material-icons">close</span>
                </button>
            </div>
        </div>

        <div className="flex flex-1 overflow-hidden relative">
            
            {/* Sidebar (Founder's Cockpit) */}
            <div 
                className={`bg-[#121215] border-r border-white/10 flex flex-col absolute md:relative z-20 h-full shadow-xl md:shadow-none transition-all duration-300 ease-in-out transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0 md:w-0 md:opacity-0'}`}
                style={{ width: isSidebarOpen ? (window.innerWidth < 768 ? '100%' : '400px') : '0px' }}
            >
                {/* Sidebar Tabs */}
                <div className="flex border-b border-white/10 bg-[#09090b]">
                    <button 
                        onClick={() => setActiveTab('chat')}
                        className={`flex-1 py-3 text-xs font-medium border-b-2 transition-colors flex flex-col items-center justify-center ${activeTab === 'chat' ? 'border-[#4FFFB0] text-[#4FFFB0] bg-[#121215]' : 'border-transparent text-gray-500 hover:text-gray-300 hover:bg-white/5'}`}
                    >
                        <span className="material-icons text-lg mb-1">chat</span>
                        Architect
                    </button>
                    <button 
                        onClick={() => setActiveTab('design')}
                        className={`flex-1 py-3 text-xs font-medium border-b-2 transition-colors flex flex-col items-center justify-center ${activeTab === 'design' ? 'border-[#4FFFB0] text-[#4FFFB0] bg-[#121215]' : 'border-transparent text-gray-500 hover:text-gray-300 hover:bg-white/5'}`}
                    >
                        <span className="material-icons text-lg mb-1">tune</span>
                        Design
                    </button>
                    <button 
                        onClick={() => setActiveTab('gallery')}
                        className={`flex-1 py-3 text-xs font-medium border-b-2 transition-colors flex flex-col items-center justify-center ${activeTab === 'gallery' ? 'border-[#4FFFB0] text-[#4FFFB0] bg-[#121215]' : 'border-transparent text-gray-500 hover:text-gray-300 hover:bg-white/5'}`}
                    >
                        <span className="material-icons text-lg mb-1">collections</span>
                        Inspo
                    </button>
                    <button 
                        onClick={() => setActiveTab('learn')}
                        className={`flex-1 py-3 text-xs font-medium border-b-2 transition-colors flex flex-col items-center justify-center ${activeTab === 'learn' ? 'border-[#4FFFB0] text-[#4FFFB0] bg-[#121215]' : 'border-transparent text-gray-500 hover:text-gray-300 hover:bg-white/5'}`}
                    >
                        <span className="material-icons text-lg mb-1">school</span>
                        Learn
                    </button>
                </div>

                {/* CHAT TAB CONTENT */}
                {activeTab === 'chat' && (
                    <div className="flex-1 flex flex-col overflow-hidden">
                        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#09090b] custom-scrollbar">
                            {/* Clear Context Button */}
                            <div className="flex justify-center pb-4">
                                <button 
                                    onClick={handleClearChat}
                                    className="text-[10px] uppercase tracking-wider font-bold text-gray-600 hover:text-red-400 flex items-center transition-colors"
                                    title="Reset chat memory to free up context tokens"
                                >
                                    <span className="material-icons text-[12px] mr-1">delete_sweep</span>
                                    Clear Context
                                </button>
                            </div>

                            {chatHistory.map((msg, i) => (
                                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-[90%] p-3 rounded-xl text-sm shadow-sm ${msg.role === 'user' ? 'bg-[#4FFFB0] text-black rounded-br-none' : 'bg-[#18181b] text-gray-200 border border-white/10 rounded-bl-none'}`}>
                                        {msg.image && (
                                            <img src={`data:${msg.image.mimeType};base64,${msg.image.base64}`} alt="Attached" className="max-w-full rounded-lg mb-2 max-h-40 object-cover" />
                                        )}
                                        <div className="whitespace-pre-wrap font-['Plus_Jakarta_Sans']">{msg.text}</div>
                                    </div>
                                </div>
                            ))}
                            {isChatLoading && (
                                <div className="flex justify-start">
                                    <div className="bg-[#18181b] p-3 rounded-xl border border-white/10 shadow-sm rounded-bl-none">
                                        <LoadingSpinner />
                                    </div>
                                </div>
                            )}
                            <div ref={chatEndRef} />
                        </div>
                        
                        {/* Strategy Strip */}
                        <div className="px-4 py-2 bg-[#121215] border-t border-white/10 flex space-x-2 overflow-x-auto scrollbar-hide">
                            <button onClick={() => handleSendMessage("Analyze the market for this idea")} className="flex-shrink-0 px-3 py-1 bg-[#4FFFB0]/10 text-[#4FFFB0] text-xs rounded-full border border-[#4FFFB0]/30 hover:bg-[#4FFFB0]/20 whitespace-nowrap" title="Get Market Data">Validation</button>
                            <button onClick={() => handleSendMessage("Suggest 3 core features for MVP")} className="flex-shrink-0 px-3 py-1 bg-[#4FFFB0]/10 text-[#4FFFB0] text-xs rounded-full border border-[#4FFFB0]/30 hover:bg-[#4FFFB0]/20 whitespace-nowrap" title="Feature Stack">Features</button>
                            <button onClick={() => handleSendMessage("Suggest a visual style for this brand")} className="flex-shrink-0 px-3 py-1 bg-[#4FFFB0]/10 text-[#4FFFB0] text-xs rounded-full border border-[#4FFFB0]/30 hover:bg-[#4FFFB0]/20 whitespace-nowrap" title="Aesthetic Logic">Style</button>
                        </div>

                        <div className="p-4 bg-[#121215] border-t border-white/10">
                            {attachedImage && (
                                <div className="relative inline-block mb-2">
                                    <img src={attachedImage.preview} alt="Preview" className="h-16 w-16 object-cover rounded-lg border border-white/20" />
                                    <button onClick={removeAttachedImage} className="absolute -top-2 -right-2 bg-gray-800 text-white rounded-full p-0.5 hover:bg-red-500 border border-white/20">
                                        <span className="material-icons text-xs">close</span>
                                    </button>
                                </div>
                            )}
                            <form onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }} className="relative flex items-end space-x-2">
                                <textarea
                                    ref={textareaRef}
                                    value={chatInput}
                                    onChange={(e) => setChatInput(e.target.value)}
                                    placeholder="Describe your idea or request changes..."
                                    className="flex-1 pl-4 pr-20 py-3 bg-[#18181b] border border-white/10 focus:bg-[#09090b] focus:border-[#4FFFB0] rounded-2xl focus:ring-1 focus:ring-[#4FFFB0] outline-none text-sm transition-all text-white placeholder-gray-500 resize-none min-h-[48px] max-h-[300px]"
                                    rows={1}
                                    disabled={isChatLoading}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' && !e.shiftKey) {
                                            // Enter creates new line
                                        }
                                    }}
                                />
                                
                                {/* Attachment Button */}
                                <button 
                                    type="button"
                                    onClick={() => fileInputRef.current?.click()}
                                    className="absolute right-24 bottom-2 p-2 rounded-full text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                                    title="Attach file or image"
                                >
                                    <span className="material-icons">attach_file</span>
                                </button>
                                <input type="file" ref={fileInputRef} className="hidden" onChange={handleImageUpload} accept="image/*,.txt,.md,.json" />

                                {/* Voice Input Button */}
                                <button 
                                    type="button"
                                    onClick={toggleListening}
                                    className={`absolute right-14 bottom-2 p-2 rounded-full transition-colors ${isListening ? 'text-red-500 bg-red-900/20 animate-pulse' : 'text-gray-400 hover:text-white hover:bg-white/10'}`}
                                    title="Voice Input"
                                >
                                    <span className="material-icons">{isListening ? 'mic' : 'mic_none'}</span>
                                </button>

                                <button 
                                    type="submit" 
                                    disabled={(!chatInput.trim() && !attachedImage) || isChatLoading}
                                    className="p-3 bg-[#4FFFB0] text-black rounded-full hover:bg-[#3ddda0] disabled:opacity-50 disabled:bg-gray-700 disabled:text-gray-500 transition-colors mb-1 shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
                                >
                                    <span className="material-icons text-sm block">arrow_upward</span>
                                </button>
                            </form>
                        </div>
                    </div>
                )}

                {/* DESIGN TAB CONTENT - Updated for PRD Section 6 */}
                {activeTab === 'design' && (
                    <div className="flex-1 overflow-y-auto p-6 space-y-8 bg-[#09090b]">
                        <div>
                            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Brand Aesthetic Profile</label>
                            
                            <div className="space-y-6">
                                {/* Visual Style Dropdown */}
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-500 mb-1 uppercase">Aesthetic Style</label>
                                    <select value={selectedStyle} onChange={(e) => setSelectedStyle(e.target.value)} className="w-full p-3 bg-[#18181b] border border-white/10 rounded-lg text-sm text-white focus:ring-[#4FFFB0] focus:border-[#4FFFB0] outline-none">
                                        {styles.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
                                    </select>
                                    <p className="text-[10px] text-gray-500 mt-1 italic">{styles.find(s => s.id === selectedStyle)?.desc}</p>
                                </div>

                                {/* Typography Dropdown */}
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-500 mb-1 uppercase">Typography</label>
                                    <select value={selectedFont} onChange={(e) => setSelectedFont(e.target.value)} className="w-full p-3 bg-[#18181b] border border-white/10 rounded-lg text-sm text-white focus:ring-[#4FFFB0] focus:border-[#4FFFB0] outline-none">
                                        {fonts.map(f => <option key={f.id} value={f.id}>{f.label}</option>)}
                                    </select>
                                </div>

                                {/* Emotional Tone */}
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-500 mb-1 uppercase">Emotional Tone</label>
                                    <select value={emotionalTone} onChange={(e) => setEmotionalTone(e.target.value)} className="w-full p-3 bg-[#18181b] border border-white/10 rounded-lg text-sm text-white focus:ring-[#4FFFB0] focus:border-[#4FFFB0] outline-none">
                                        {emotionalTones.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
                                    </select>
                                </div>

                                {/* Brand Personality Input */}
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-500 mb-1 uppercase">Brand Personality (Adjectives)</label>
                                    <input 
                                        type="text" 
                                        value={brandPersonality}
                                        onChange={(e) => setBrandPersonality(e.target.value)}
                                        placeholder="e.g. Playful, trustworthy, innovative..."
                                        className="w-full p-3 bg-[#18181b] border border-white/10 rounded-lg text-sm text-white focus:ring-[#4FFFB0] focus:border-[#4FFFB0] outline-none placeholder-gray-600"
                                    />
                                </div>

                                {/* Primary Color Input */}
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-500 mb-1 uppercase">Primary Color Preference</label>
                                    <div className="flex items-center space-x-2">
                                        <input 
                                            type="color" 
                                            value={primaryColorInput}
                                            onChange={(e) => setPrimaryColorInput(e.target.value)}
                                            className="h-10 w-10 p-1 bg-[#18181b] border border-white/10 rounded cursor-pointer"
                                        />
                                        <input 
                                            type="text" 
                                            value={primaryColorInput}
                                            onChange={(e) => setPrimaryColorInput(e.target.value)}
                                            placeholder="#4FFFB0"
                                            className="flex-1 p-3 bg-[#18181b] border border-white/10 rounded-lg text-sm text-white focus:ring-[#4FFFB0] focus:border-[#4FFFB0] outline-none placeholder-gray-600 font-mono"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* GALLERY TAB */}
                {activeTab === 'gallery' && renderGallery()}

                {/* LEARN TAB */}
                {activeTab === 'learn' && renderLearn()}

                {/* Render Action Bar */}
                <div className="p-4 border-t border-white/10 bg-[#121215]">
                    <button 
                        onClick={handleRenderApp}
                        disabled={isLoading}
                        className="w-full py-4 bg-[#4FFFB0] text-black font-bold rounded-xl hover:bg-[#3ddda0] shadow-[0_0_20px_rgba(79,255,176,0.2)] hover:shadow-[0_0_30px_rgba(79,255,176,0.4)] transition-all transform hover:-translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center ring-offset-2 ring-offset-[#09090b]"
                    >
                        {isLoading ? (
                            <span className="ml-2 text-sm font-mono flex items-center">
                                <LoadingSpinner />
                                <span className="ml-2">
                                {
                                    loadingStep === 1 ? 'Reasoning UX...' :
                                    loadingStep === 2 ? 'Applying Vibe...' :
                                    loadingStep === 3 ? 'Generating Code...' :
                                    'Initializing...'
                                }
                                </span>
                            </span>
                        ) : (
                            <>
                                <span className="material-icons mr-2 text-lg">{generatedCode ? 'autorenew' : 'auto_awesome'}</span>
                                <span className="text-lg">{generatedCode ? 'Update Build' : 'Build MVP'}</span>
                            </>
                        )}
                    </button>
                </div>
            </div>

            {/* Preview Area */}
            <div className="flex-1 bg-gray-100 relative flex flex-col h-full overflow-hidden">
                {generatedCode ? (
                    <>
                        {/* Toolbar */}
                        <div className="absolute top-4 right-4 z-10 flex space-x-2">
                             <button 
                                onClick={handleFullScreenPreview}
                                className="px-4 py-2 bg-black/80 text-white backdrop-blur-md rounded-full text-xs font-bold shadow-lg hover:bg-black transition-colors flex items-center"
                                title="Open in New Tab"
                            >
                                <span className="material-icons text-sm mr-2">open_in_new</span>
                                Full Screen
                            </button>
                             <button 
                                onClick={() => setShowCode(!showCode)}
                                className="px-4 py-2 bg-black/80 text-white backdrop-blur-md rounded-full text-xs font-bold shadow-lg hover:bg-black transition-colors flex items-center"
                            >
                                <span className="material-icons text-sm mr-2">{showCode ? 'preview' : 'code'}</span>
                                {showCode ? 'Preview' : 'Inspect Code'}
                            </button>
                            <button 
                                onClick={() => setActiveTab('deploy')} 
                                className="px-4 py-2 bg-[#4FFFB0] text-black rounded-full text-xs font-bold shadow-lg hover:bg-[#3ddda0] transition-colors flex items-center group"
                                title="Engineering & Deployment Cockpit"
                            >
                                <span className="material-icons text-sm mr-2">rocket_launch</span>
                                Deploy
                            </button>
                        </div>
                        
                        {/* Content */}
                        <div className="flex-1 relative w-full h-full">
                            {showCode ? (
                                <textarea 
                                    value={generatedCode} 
                                    onChange={(e) => setGeneratedCode(e.target.value)}
                                    className="w-full h-full bg-[#1e1e1e] text-[#4FFFB0] font-mono p-4 text-xs resize-none focus:outline-none"
                                    spellCheck={false}
                                />
                            ) : (
                                <iframe 
                                    srcDoc={generatedCode}
                                    title="App Preview"
                                    className="w-full h-full border-none bg-transparent"
                                    sandbox="allow-scripts allow-same-origin"
                                />
                            )}
                        </div>
                    </>
                ) : (
                    // Loading / Empty State
                    <div className="flex-1 flex flex-col items-center justify-center text-gray-400 p-8 text-center bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')]">
                        {isLoading ? (
                            <div className="flex flex-col items-center animate-fadeIn">
                                <div className="relative w-24 h-24 mb-6">
                                    <div className="absolute inset-0 border-4 border-gray-800 rounded-full opacity-25"></div>
                                    <div className="absolute inset-0 border-4 border-[#4FFFB0] rounded-full border-t-transparent animate-spin"></div>
                                    <div className="absolute inset-0 flex items-center justify-center">
                                        <span className="material-icons text-4xl text-[#4FFFB0] animate-pulse">construction</span>
                                    </div>
                                </div>
                                <h3 className="text-2xl font-bold text-gray-800 font-['Outfit']">Vibe Architect Working...</h3>
                                <div className="mt-4 space-y-2 text-sm font-mono text-gray-500">
                                    <p className={`transition-opacity duration-500 ${loadingStep >= 1 ? 'opacity-100 text-[#4FFFB0]' : 'opacity-30'}`}>1. Reasoning UX...</p>
                                    <p className={`transition-opacity duration-500 ${loadingStep >= 2 ? 'opacity-100 text-[#4FFFB0]' : 'opacity-30'}`}>2. Applying Vibe...</p>
                                    <p className={`transition-opacity duration-500 ${loadingStep >= 3 ? 'opacity-100 text-[#4FFFB0]' : 'opacity-30'}`}>3. Generating Code...</p>
                                </div>
                            </div>
                        ) : (
                            <>
                                <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mb-6">
                                    <span className="material-icons text-5xl text-gray-400">rocket_launch</span>
                                </div>
                                <h3 className="text-xl font-bold text-gray-500 font-['Outfit']">Start Vibe Coding</h3>
                                <p className="max-w-xs mt-2 text-sm mb-6 font-['Plus_Jakarta_Sans']">Describe your dream tool, dashboard, or app, and I'll build the functional prototype.</p>
                                {!isSidebarOpen && (
                                    <button 
                                        onClick={() => setIsSidebarOpen(true)}
                                        className="px-6 py-2 bg-[#4FFFB0] text-black rounded-full text-sm font-bold shadow-md hover:bg-[#3ddda0] transition-colors"
                                    >
                                        Open Cockpit
                                    </button>
                                )}
                            </>
                        )}
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default MVPBuilderModal;
