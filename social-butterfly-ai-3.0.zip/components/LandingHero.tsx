
import React from 'react';

// 1. Define the input prop
interface LandingHeroProps {
  onEnterApp?: () => void;
}

// 2. Accept the prop
export default function LandingHero({ onEnterApp }: LandingHeroProps) {

  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#050505]">
      {/* BACKGROUND VIDEO */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute top-0 left-0 w-full h-full object-cover z-0"
      >
        <source src="https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/hero_tinker_landscape.mp4?alt=media&token=52d561be-6f89-49ec-bf02-642e09a86e68" type="video/mp4" />
      </video>

      {/* GRADIENT SCRIM */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent z-10" />

      {/* CONTENT */}
      <div 
        className="absolute left-0 w-full z-20 px-4 text-center"
        style={{ top: '60%' }} 
      >
        <div className="max-w-6xl mx-auto">
          <span className="font-['Outfit'] font-bold text-[#4FFFB0] tracking-[0.2em] uppercase mb-2 block text-xs md:text-sm">
            From your thought bubble to the cloud
          </span>

          <h1 className="font-['Outfit'] font-extrabold text-3xl md:text-5xl text-white mb-3 leading-tight drop-shadow-2xl">
            Turn Your Idea into a Revenue-Ready Business. <br className="hidden md:block" />
            Get Clarity and Code in One Conversation.
          </h1>

          <p className="font-['Plus_Jakarta_Sans'] text-slate-300 text-sm md:text-base max-w-2xl mx-auto mb-6 font-light opacity-90">
            The world’s first AI Venture Builder. Validate your idea, architect your business, and launch with clarity.
          </p>

          {/* BUTTON: NOW WIRED TO THE POPUP */}
          <button 
            onClick={onEnterApp}
            className="bg-[#4FFFB0] text-black font-['Outfit'] font-bold text-sm md:text-base px-8 py-3 rounded-full hover:scale-105 hover:shadow-[0_0_20px_rgba(79,255,176,0.5)] transition-all duration-300"
          >
            Begin Transformation
          </button>
        </div>
      </div>
    </div>
  );
}