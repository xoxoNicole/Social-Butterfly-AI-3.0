
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import { UserProfile, saveAsset, updateUserProfile, subscribeToChats, saveChatSession, deleteChatSession, subscribeToTasks, saveTasks } from '../services/firebase';
import { CREDIT_COSTS } from '../creditCosts';
import { ChatMessage, ChatSession, Task } from '../types';
import Header from './Header';
import ChatInput from './ChatInput';
import MessageList from './MessageList';
import AppSidebar from './AppSidebar';
import Dashboard, { DashboardAction } from './Dashboard';
import VideoGenerationModal from './VideoGenerationModal';
import MVPBuilderModal from './MVPBuilderModal';
import BuyCreditsModal from './BuyCreditsModal';
import ProfileModal from './ProfileModal';
import AdminDashboard from './AdminDashboard';
import UpdatesModal from './UpdatesModal';
import SupportModal from './SupportModal';
import ExportModal from './ExportModal';
import TaskModal from './TaskModal';
import OnboardingModal from './OnboardingModal';
import { MODEL_SMART } from './aiConfig';
import SanctuaryModal from './SanctuaryModal';
import { generateSystemInstruction } from '../constants';
import ImageGenerationModal from './ImageGenerationModal';
import ImageEditingModal from './ImageEditingModal';
import DocumentAnalysisModal from './DocumentAnalysisModal';
import VideoAnalysisModal from './VideoAnalysisModal';
import GoToMarketPlanner from './GoToMarketPlanner';
import AcademyModal from './AcademyModal';
import { routeThroughOrchestrator, OrchestratorState } from '../agents/coreOrchestrator';
import { agentRegistry } from '../agents/registry';

interface ChatPageProps {
    onGoHome: () => void;
    currentUser: any;
    initialProfile: UserProfile;
    onOpenSupport: () => void;
    onManageSubscription: () => void;
    onLogout: () => void;
}

// --- PCM Decoding for TTS ---
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const ChatPage: React.FC<ChatPageProps> = ({ onGoHome, currentUser, initialProfile, onOpenSupport, onManageSubscription, onLogout }) => {
    const [profile, setProfile] = useState<UserProfile>(initialProfile);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [showSidebar, setShowSidebar] = useState(true); // Default Open on Desktop
    
    // View Management
    const [activeView, setActiveView] = useState('dashboard');

    // Chat Session Management
    const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
    const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
    const [tasks, setTasks] = useState<Task[]>([]);

    // Orchestrator State
    const [orchestratorState, setOrchestratorState] = useState<OrchestratorState>({
        phase: 'PHASE_1_PRD',
        artifacts: {}
    });

    // Modals
    const [showOnboarding, setShowOnboarding] = useState(false);
    const [showVideoModal, setShowVideoModal] = useState(false);
    const [showMVPModal, setShowMVPModal] = useState(false);
    const [showBuyCredits, setShowBuyCredits] = useState(false);
    const [showProfile, setShowProfile] = useState(false);
    const [showAdmin, setShowAdmin] = useState(false);
    const [showUpdates, setShowUpdates] = useState(false);
    const [showExport, setShowExport] = useState(false);
    const [showTasks, setShowTasks] = useState(false);
    const [showImageGen, setShowImageGen] = useState(false);
    const [showImageEdit, setShowImageEdit] = useState(false);
    const [showDocAnalysis, setShowDocAnalysis] = useState(false);
    const [showVideoAnalysis, setShowVideoAnalysis] = useState(false);
    const [showGTM, setShowGTM] = useState(false);
    const [showAcademy, setShowAcademy] = useState(false);
    const [showSanctuary, setShowSanctuary] = useState(false);
    
    // Video Gen State
    const [isVideoGenerating, setIsVideoGenerating] = useState(false);
    const [videoGenerationResult, setVideoGenerationResult] = useState<string | null>(null);
    const [videoGenerationMessage, setVideoGenerationMessage] = useState('');

    const aiRef = useRef<GoogleGenAI | null>(null);
    const audioContextRef = useRef<AudioContext | null>(null);

    useEffect(() => {
        if (process.env.API_KEY) {
            aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY });
        }
        setProfile(initialProfile);
        
        // Trigger Onboarding if new user (Stage 1 and no preferred name stored)
        if (initialProfile.stage === 1 && !initialProfile.preferredName) {
            setShowOnboarding(true);
        }
    }, [initialProfile]);

    useEffect(() => {
        if (currentUser?.uid) {
            const unsubChats = subscribeToChats(currentUser.uid, (chats) => setChatSessions(chats));
            const unsubTasks = subscribeToTasks(currentUser.uid, (t) => setTasks(t));
            return () => { unsubChats(); unsubTasks(); };
        }
    }, [currentUser]);

    // Responsive Sidebar Logic
    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth < 768) setShowSidebar(false);
            else setShowSidebar(true);
        };
        window.addEventListener('resize', handleResize);
        handleResize(); // Init
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const handleOnboardingFinish = async (data: Partial<UserProfile>) => {
        setShowOnboarding(false);
        const updated = { ...profile, ...data };
        setProfile(updated);
        await updateUserProfile(currentUser.uid, data);
        
        // Auto-trigger welcome / stage suggestion
        if (data.ideaSummary) {
            handleSendMessage(`My name is ${data.preferredName}. My idea is: ${data.ideaSummary}. What should I do next?`);
        }
    };

    const handleNavigation = (viewId: string) => {
        setActiveView(viewId);
        
        // Map Sidebar IDs to Actions
        switch(viewId) {
            case 'dashboard': 
                setMessages([]); // Clear chat to show dashboard
                break;
            case 'vibe_coding': setShowMVPModal(true); break;
            case 'creative_studio': setShowImageGen(true); break; // Default to one tool for now
            case 'clarity_hub': setShowSanctuary(true); break;
            case 'academy': setShowAcademy(true); break;
            case 'profile': setShowProfile(true); break;
            case 'admin': setShowAdmin(true); break;
            case 'settings': setShowProfile(true); break; // Reuse profile modal for settings
        }
        
        // On mobile, close sidebar after nav
        if (window.innerWidth < 768) setShowSidebar(false);
    };

    const handleDashboardAction = (action: DashboardAction, featureTitle: string) => {
        if (action.type === 'send_message') {
            handleSendMessage(action.payload);
        } else if (action.type === 'open_modal') {
            switch (action.payload) {
                case 'video_text': setShowVideoModal(true); break;
                case 'site_architect': setShowMVPModal(true); break;
                case 'image_generation': setShowImageGen(true); break;
                case 'image_editing': setShowImageEdit(true); break;
                case 'document_analysis': setShowDocAnalysis(true); break;
                case 'video_analysis': setShowVideoAnalysis(true); break;
                case 'gtm': setShowGTM(true); break;
                case 'academy': setShowAcademy(true); break;
                case 'sanctuary': setShowSanctuary(true); break;
                default: console.warn("Unknown modal:", action.payload);
            }
        }
    };

    // --- Helper Functions (Deduct, Refund, Generate Video, Speak, Send Message) ---
    
    const deductCredits = async (amount: number) => {
        if (profile.credits >= amount) {
            const newCredits = profile.credits - amount;
            setProfile(prev => ({ ...prev, credits: newCredits }));
            await updateUserProfile(currentUser.uid, { credits: newCredits });
            return true;
        }
        return false;
    };

    const refundCredits = async (amount: number) => {
         const newCredits = profile.credits + amount;
         setProfile(prev => ({ ...prev, credits: newCredits }));
         await updateUserProfile(currentUser.uid, { credits: newCredits });
    };

    // --- VIBE ARCHITECT GENERATION (PRD v1.0 Implementation) ---
    const handleVibeCodeGeneration = async (prompt: string, style: string, currentCode?: string, refinementRequest?: string): Promise<string> => {
        if (!aiRef.current) throw new Error("AI not initialized");
        
        // Deduct credits for MVP generation
        const hasCredits = await deductCredits(CREDIT_COSTS.MVP_BUILDER);
        if (!hasCredits) {
            setShowBuyCredits(true);
            throw new Error("Insufficient credits");
        }

        try {
            const finalPrompt = refinementRequest && currentCode 
                ? `
                **TASK:** Refine the existing React code based on user request.
                **USER REQUEST:** ${refinementRequest}
                **EXISTING CODE:**
                ${currentCode}
                
                **CONSTRAINT:** Return the FULLY UPDATED HTML file. Do not return partial snippets.
                `
                : prompt;

            const response = await aiRef.current.models.generateContent({
                model: MODEL_SMART, // Uses Gemini 3 Pro
                contents: [{ parts: [{ text: finalPrompt }] }],
                config: {
                    // Force the model to think as a Senior Engineer
                    systemInstruction: `
                    You are Vibe Architect, an elite full-stack engineer and designer.
                    
                    YOUR GOAL: Generate a production-ready, single-file React application using Babel Standalone and Tailwind CSS.
                    
                    TECHNICAL CONSTRAINTS:
                    1. Output a SINGLE HTML file containing everything (HTML, CSS, JS).
                    2. Use React 18, ReactDOM 18, and Babel via CDN.
                    3. Use Tailwind CSS via CDN.
                    4. Use Lucide-React via ESM (https://unpkg.com/lucide-react@latest/dist/umd/lucide-react.js) or FontAwesome if Lucide is unstable in single-file. Better yet, use Material Icons via Google Fonts for reliability.
                    5. Images: Use specific Unsplash Source URLs with keywords (e.g. source.unsplash.com/random/800x600/?office).
                    6. Mock Data: Create realistic mock data arrays inside the component.
                    7. NO 'import' statements that require a bundler. Use 'const { useState, useEffect } = React;'.
                    8. Layout: Responsive, mobile-first, modern spacing (gap-4, p-6).
                    
                    RESPONSE FORMAT:
                    Only return the HTML code block. No markdown backticks at the start or end if possible, or plain text explanation.
                    `
                }
            });

            const text = response.text || "";
            
            // --- ROBUST CODE EXTRACTION ENGINE ---
            // Fixes "Consistently generates content" issue by removing conversational filler.
            // Finds the outermost HTML structure.
            let code = text;
            
            // Priority 1: Look for full HTML structure with DOCTYPE
            const fullDocMatch = text.match(/<!DOCTYPE html>[\s\S]*<\/html>/i);
            if (fullDocMatch) {
                code = fullDocMatch[0];
            } else {
                // Priority 2: Look for HTML tags
                const htmlMatch = text.match(/<html[\s\S]*<\/html>/i);
                if (htmlMatch) {
                    code = htmlMatch[0];
                } else {
                    // Priority 3: Fallback to markdown cleaning
                    code = code.replace(/```html/g, '').replace(/```/g, '').trim();
                }
            }
            
            // Safety Check: If code doesn't start with DOCTYPE, prepend it for browser compatibility
            if (!code.trim().toLowerCase().startsWith('<!doctype html>')) {
                code = `<!DOCTYPE html>\n${code}`;
            }
            
            return code;

        } catch (error) {
            console.error("Vibe Architect Error:", error);
            await refundCredits(CREDIT_COSTS.MVP_BUILDER); // Refund on failure
            throw error;
        }
    };

    // Re-implement basic text messaging logic
    const handleSendMessage = async (text: string, image?: { base64: string, mimeType: string }, toolId?: string) => {
        if (!aiRef.current) return;
        setIsLoading(true);
        setActiveView('chat'); // Force view to chat when message sent

        // Voice mode clean up
        let displayText = text;
        const isVoiceMode = text.includes('[VOICE_MODE]');
        if (isVoiceMode) {
            displayText = text.replace('[VOICE_MODE]', '').trim();
            if (displayText.includes('User said: "')) {
                 const parts = displayText.split('User said: "');
                 if (parts.length > 1) displayText = parts[1].replace('"', '').trim();
            }
        }
        
        // Optimistic UI Update
        const userMsg: ChatMessage = { role: 'user', parts: [{ text: displayText }] };
        if (image) {
            userMsg.parts.push({ inlineData: { mimeType: image.mimeType, data: image.base64 } });
        }
        
        const newMessages = [...messages, userMsg];
        setMessages(newMessages);

        try {
            const cost = CREDIT_COSTS.CHAT_MESSAGE + (image ? CREDIT_COSTS.CHAT_IMAGE_ATTACHMENT : 0);
            if (profile.credits < cost) {
                setShowBuyCredits(true);
                setIsLoading(false);
                return;
            }
            await deductCredits(cost);

            // --- CORE ORCHESTRATOR ROUTING ---
            // Before responding, we ask the Orchestrator who should handle this.
            // Only applicable if no specific tool (like Image Gen) was explicitly selected by UI.
            let activeSystemInstruction = generateSystemInstruction(profile); // Default: Best Friend / PRD Agent
            let modelName = MODEL_SMART;

            if (toolId === 'image') {
                modelName = 'gemini-2.5-flash-image';
            } else if (!toolId || toolId === 'auto') {
                // Route through Orchestrator
                if (process.env.API_KEY) {
                    const decision = await routeThroughOrchestrator({
                        userMessage: displayText,
                        state: orchestratorState,
                        apiKey: process.env.API_KEY
                    });

                    // Update local orchestrator state
                    setOrchestratorState(decision.updatedState);

                    // Select System Prompt based on Agent ID
                    if (decision.nextAgent === 'vibeArchitect') {
                        activeSystemInstruction = agentRegistry.vibeArchitect.systemPrompt;
                    } else if (decision.nextAgent === 'engineering') {
                        activeSystemInstruction = agentRegistry.engineering.systemPrompt;
                    } 
                    // If PRD_AGENT or fallback, we keep the default "Best Friend" instruction which acts as the Strategist/PRD agent.
                    
                    // console.log("Orchestrator Decision:", decision.nextAgent); // Debug log
                }
            }

            const historyContents = messages.map(m => ({
                role: m.role,
                parts: m.parts.map(p => {
                    if (p.inlineData) return { inlineData: p.inlineData };
                    return { text: p.text };
                })
            }));

            const newContent = { 
                role: 'user', 
                parts: [
                    ...(image ? [{ inlineData: { mimeType: image.mimeType, data: image.base64 } }] : []),
                    { text: text } 
                ]
            };

            const response = await aiRef.current.models.generateContent({
                model: modelName,
                contents: [...historyContents, newContent], 
                config: { systemInstruction: activeSystemInstruction }
            });

            const modelText = response.text || 
                              response.candidates?.[0]?.content?.parts?.[0]?.text || 
                              "I'm having trouble processing that request right now.";

            if (modelText) {
                const modelMsg: ChatMessage = { role: 'model', parts: [{ text: modelText }], groundingMetadata: response.candidates?.[0]?.groundingMetadata };
                setMessages([...newMessages, modelMsg]);
            }
        } catch (error) {
            console.error("Chat Error", error);
            await refundCredits(CREDIT_COSTS.CHAT_MESSAGE);
        } finally {
            setIsLoading(false);
        }
    };

    // --- RENDER ---

    return (
        <div className="flex h-screen bg-[#050505] overflow-hidden text-white font-sans">
            
            {/* NEW SIDEBAR */}
            <AppSidebar 
                isOpen={showSidebar} 
                activeView={activeView}
                onNavigate={handleNavigation}
                onLogout={onLogout}
            />

            {/* Main Content Area */}
            <div className={`flex-1 flex flex-col relative w-full h-full overflow-hidden transition-all duration-300 ${showSidebar ? 'md:ml-64' : ''}`}>
                
                {/* Background Ambience */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[300px] bg-purple-500/10 blur-[120px] rounded-full pointer-events-none z-0" />
                
                <Header 
                    onGoHome={() => { setMessages([]); setActiveView('dashboard'); }} 
                    profile={profile} 
                    isChatPage={true} 
                    onOpenSupport={onOpenSupport}
                    onToggleSidebar={() => setShowSidebar(!showSidebar)}
                    onLogout={onLogout}
                    showDashboard={messages.length === 0}
                    onOpenProfile={() => setShowProfile(true)}
                    onOpenAdmin={profile.role === 'admin' ? () => setShowAdmin(true) : undefined}
                    onOpenUpdates={() => setShowUpdates(true)}
                    onOpenExport={() => setShowExport(true)}
                    onToggleTasks={() => setShowTasks(true)}
                    hasUnreadUpdates={false} 
                />
                
                <div className="flex-1 overflow-y-auto pt-16 pb-20 custom-scrollbar relative z-10">
                    {messages.length === 0 ? (
                        <Dashboard onAction={handleDashboardAction} profile={profile} />
                    ) : (
                        <MessageList 
                            messages={messages} 
                            isLoading={isLoading} 
                            userProfilePhoto={profile.photo} 
                        />
                    )}
                </div>

                <div className="absolute bottom-0 w-full z-20">
                    <ChatInput 
                        onSendMessage={handleSendMessage} 
                        isLoading={isLoading} 
                        isListening={false}
                        onToggleVoice={() => setShowSanctuary(true)} 
                        voiceState='idle'
                        liveTranscription={{user:'', model:''}}
                    />
                </div>
            </div>
            
            {/* Modals */}
            {showOnboarding && <OnboardingModal onFinish={handleOnboardingFinish} initialName={currentUser.displayName} />}
            
            <VideoGenerationModal isOpen={showVideoModal} onClose={() => setShowVideoModal(false)} onGenerate={async (p, r, i, v) => console.log(p)} isLoading={isVideoGenerating} loadingMessage={videoGenerationMessage} generatedVideo={videoGenerationResult} initialMode='text' />
            <MVPBuilderModal 
                isOpen={showMVPModal} 
                onClose={() => setShowMVPModal(false)} 
                userProfile={profile} 
                onGenerate={handleVibeCodeGeneration} 
                isLoading={false} 
            />
            <BuyCreditsModal isOpen={showBuyCredits} onClose={() => setShowBuyCredits(false)} />
            <ProfileModal isOpen={showProfile} onClose={() => setShowProfile(false)} currentProfile={profile} onSave={async (data) => { setProfile(prev => ({ ...prev, ...data })); await updateUserProfile(currentUser.uid, data); setShowProfile(false); }} onBuyCredits={() => { setShowProfile(false); setShowBuyCredits(true); }} onLogout={onLogout} onManageSubscription={onManageSubscription} />
            <AdminDashboard isOpen={showAdmin} onClose={() => setShowAdmin(false)} currentUserProfile={profile} />
            <UpdatesModal isOpen={showUpdates} onClose={() => setShowUpdates(false)} />
            <ExportModal isOpen={showExport} onClose={() => setShowExport(false)} chatSession={{ id: 'temp', title: 'Current Chat', messages }} tasks={tasks} />
            <TaskModal isOpen={showTasks} onClose={() => setShowTasks(false)} tasks={tasks} onAddTask={async () => {}} onToggleTask={async () => {}} onDeleteTask={async () => {}} />
            
            <SanctuaryModal 
                isOpen={showSanctuary} 
                onClose={() => setShowSanctuary(false)} 
                userProfile={profile} 
                messages={messages}
                isChatLoading={isLoading}
                onSendMessage={(prompt) => handleSendMessage(prompt)} 
            />
            
            <ImageGenerationModal isOpen={showImageGen} onClose={() => setShowImageGen(false)} onGenerate={async () => {}} isLoading={false} generatedImage={null} />
            <ImageEditingModal isOpen={showImageEdit} onClose={() => setShowImageEdit(false)} onGenerate={() => {}} isLoading={false} generatedImage={null} />
            <DocumentAnalysisModal isOpen={showDocAnalysis} onClose={() => setShowDocAnalysis(false)} onAnalyze={() => {}} isLoading={false} />
            <VideoAnalysisModal isOpen={showVideoAnalysis} onClose={() => setShowVideoAnalysis(false)} onAnalyze={() => {}} isLoading={false} />
            <GoToMarketPlanner isOpen={showGTM} onClose={() => setShowGTM(false)} onGenerate={(data) => { handleSendMessage(`Generate a GTM plan for: ${JSON.stringify(data)}`); setShowGTM(false); }} />
            <AcademyModal isOpen={showAcademy} onClose={() => setShowAcademy(false)} userProfile={profile} onAnalyzePitch={async () => ({ score:0, feedback:'', strengths:[], weaknesses:[], refinedPitch:'' })} />
        </div>
    );
};

export default ChatPage;
