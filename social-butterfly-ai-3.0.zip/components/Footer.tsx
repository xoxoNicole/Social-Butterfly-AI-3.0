
import React from 'react';

const Footer: React.FC = () => {
    const BrandText = () => (
        <div>
            <h3 className="text-lg font-bold text-white font-['Outfit']">Social Butterfly AI</h3>
            <p className="text-sm text-gray-400 mt-4 leading-relaxed font-['Plus_Jakarta_Sans']">
                Social Butterfly AI is the world's first Founder Incubator & No-Code Builder. While tools like Bolt and Cursor focus on writing code faster for developers, Social Butterfly focuses on building businesses faster for founders. We bridge the gap between "Strategy" and "Software," using AI to validate ideas, design systems, and deploy full-stack apps in a single conversation. We don't just generate code; we generate clarity.
            </p>
        </div>
    );
    
    return (
        <footer className="bg-[#050505] border-t border-white/10 text-white font-sans">
            <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
                    <div className="col-span-1 md:col-span-2">
                        <BrandText />
                    </div>
                    
                    <div>
                        <h4 className="text-sm font-bold text-gray-200 uppercase tracking-wider mb-4 font-['Outfit']">Platform</h4>
                        <ul className="space-y-2 text-sm text-gray-400 font-['Plus_Jakarta_Sans']">
                            <li><a href="#features" className="hover:text-[#4FFFB0] transition-colors">Features</a></li>
                            <li><a href="#pricing" className="hover:text-[#4FFFB0] transition-colors">Pricing</a></li>
                            <li><a href="#testimonials" className="hover:text-[#4FFFB0] transition-colors">Success Stories</a></li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="text-sm font-bold text-gray-200 uppercase tracking-wider mb-4 font-['Outfit']">Tech Stack (Built On)</h4>
                        <ul className="space-y-2 text-sm text-gray-500 font-['JetBrains_Mono']">
                            <li>React.js & Node.js</li>
                            <li>TypeScript</li>
                            <li>Tailwind CSS</li>
                            <li>Firebase / Google Cloud</li>
                            <li>Vercel / Netlify</li>
                            <li>Full-stack Engineering</li>
                            <li>Frontend UI/UX</li>
                            <li>Backend Database Schema</li>
                            <li>API Integration</li>
                        </ul>
                    </div>
                </div>

                <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center">
                    <p className="text-sm text-gray-600 font-['Plus_Jakarta_Sans']">
                        &copy; {new Date().getFullYear()} Social Butterfly AI. All rights reserved.
                    </p>
                    <div className="flex space-x-6 mt-4 md:mt-0 font-['Plus_Jakarta_Sans']">
                        <a href="#" className="text-sm text-gray-600 hover:text-gray-400">Terms</a>
                        <a href="#" className="text-sm text-gray-600 hover:text-gray-400">Privacy</a>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
