
import React, { useState } from 'react';
import LoadingSpinner from './LoadingSpinner';

interface DocumentAnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAnalyze: (file: File, prompt: string) => void;
  isLoading: boolean;
}

const DocumentAnalysisModal: React.FC<DocumentAnalysisModalProps> = ({ isOpen, onClose, onAnalyze, isLoading }) => {
  const [prompt, setPrompt] = useState('Summarize this document and provide the top 5 key takeaways.');
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
        if (selectedFile.size > 10 * 1024 * 1024) { // 10MB limit
            setError('File is too large. Please select a file under 10MB.');
            setFile(null);
        } else {
            setFile(selectedFile);
            setError(null);
        }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (file && prompt.trim()) {
      onAnalyze(file, prompt);
    } else {
        setError('Please select a file and enter a prompt.');
    }
  };
  
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    const droppedFile = e.dataTransfer.files?.[0];
    if (droppedFile) {
      setFile(droppedFile);
      setError(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center z-50 p-4 modal-backdrop" onClick={onClose}>
      <div className="bg-[#18181b] border border-white/10 rounded-2xl shadow-2xl w-full max-w-2xl p-6 modal-content flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold text-white font-['Outfit']">Analyze Document</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white" aria-label="Close modal">
            <span className="material-icons">close</span>
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto pr-2">
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-400 mb-1">Upload Document</label>
                    <div 
                        onDragOver={handleDragOver}
                        onDrop={handleDrop}
                        className="w-full h-40 border-2 border-dashed border-white/20 rounded-lg flex flex-col items-center justify-center text-center p-4 bg-white/5 hover:bg-white/10 transition-colors"
                    >
                        {file ? (
                            <div>
                                <span className="material-icons text-4xl text-green-500">check_circle</span>
                                <p className="mt-2 font-semibold text-white">{file.name}</p>
                                <p className="text-xs text-gray-400">{(file.size / 1024).toFixed(2)} KB</p>
                            </div>
                        ) : (
                            <div>
                                <span className="material-icons text-5xl text-gray-500">upload_file</span>
                                <p className="mt-2 text-gray-300">Drag & drop a file here or</p>
                                <label htmlFor="doc-upload" className="mt-2 cursor-pointer text-sm font-medium text-[#4FFFB0] hover:underline">
                                    <span>click to upload</span>
                                    <input id="doc-upload" type="file" className="hidden" accept=".pdf,.txt,.md" onChange={handleFileChange} />
                                </label>
                                <p className="text-xs text-gray-500 mt-1">PDF, TXT, MD up to 10MB</p>
                            </div>
                        )}
                    </div>
                </div>

                <div>
                  <label htmlFor="doc-prompt" className="block text-sm font-medium text-gray-400 mb-1">Prompt</label>
                  <textarea
                    id="doc-prompt"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="w-full p-3 bg-[#09090b] border border-white/10 rounded-md min-h-[100px] text-white placeholder-gray-600 focus:ring-1 focus:ring-[#4FFFB0] focus:border-[#4FFFB0] outline-none"
                    rows={4}
                    required
                  />
                </div>

                {error && <p className="text-sm text-red-500">{error}</p>}

              <div className="mt-6 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-2 text-black font-bold bg-[#4FFFB0] rounded-md hover:bg-[#3ddda0] disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center shadow-[0_0_15px_rgba(79,255,176,0.3)] hover:shadow-[0_0_20px_rgba(79,255,176,0.5)]"
                  disabled={!file || !prompt.trim() || isLoading}
                >
                  {isLoading ? <LoadingSpinner/> : 'Analyze Document'}
                </button>
              </div>
            </form>
        </div>
      </div>
    </div>
  );
};

export default DocumentAnalysisModal;
