
import React, { useState, useEffect, useRef } from 'react';
import { UserProfile } from '../services/firebase';
import { GoogleGenAI } from '@google/genai';
import { MODEL_SMART } from './aiConfig';
import { ChatMessage } from '../types';

interface SanctuaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  messages?: ChatMessage[];
  isChatLoading?: boolean;
  onSendMessage: (prompt: string) => void;
}

const QUICK_STARTS = [
    { icon: "psychology", title: "Imposter Syndrome", prompt: "I'm feeling like a fraud today. Help me objectively analyze my track record." },
    { icon: "handshake", title: "Difficult Client", prompt: "I have a client who is pushing boundaries. Roleplay the conversation with me." },
    { icon: "rocket_launch", title: "Launch Anxiety", prompt: "I'm about to launch and I'm freezing up. Help me create a pre-flight checklist." },
    { icon: "trending_up", title: "Scale Strategy", prompt: "I have some capital to deploy. Analyze my best options for scaling right now." },
    { icon: "celebration", title: "Big Win!", prompt: "I just closed a huge deal! Celebrate with me and help me figure out the next step." },
    { icon: "balance", title: "Burnout Check", prompt: "I'm feeling exhausted but can't stop. Help me structure a recovery plan." }
];

type Mode = 'home' | 'analysis' | 'chat';

interface AnalysisResult {
    insight: string;
    impact: 'HIGH' | 'MODERATE' | 'LOW';
    strategies: string[];
}

// --- AUDIO UTILS (PCM Decoder) ---
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const SanctuaryModal: React.FC<SanctuaryModalProps> = ({ isOpen, onClose, userProfile, messages, isChatLoading, onSendMessage }) => {
  const [mode, setMode] = useState<Mode>('home');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  
  // Track last message index to auto-speak new responses
  const [lastProcessedMessageIndex, setLastProcessedMessageIndex] = useState<number>(-1);
  
  const [analysisInput, setAnalysisInput] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<AnalysisResult[] | null>(null);

  const aiRef = useRef<GoogleGenAI | null>(null);
  const recognitionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const activeSourceRef = useRef<AudioBufferSourceNode | null>(null);

  useEffect(() => {
      if (process.env.API_KEY) {
          aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY });
      }

      if (typeof window !== 'undefined') {
          // Initialize Speech Recognition
          const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
          if (SpeechRecognition) {
              const recognition = new SpeechRecognition();
              recognition.continuous = false;
              recognition.interimResults = false;
              recognition.lang = 'en-US';
              
              recognition.onresult = (event: any) => {
                  const transcript = event.results[0][0].transcript;
                  handleVoiceInput(transcript);
              };
              
              recognition.onend = () => setIsListening(false);
              recognitionRef.current = recognition;
          }
      }
      
      return () => {
          if (activeSourceRef.current) {
              activeSourceRef.current.stop();
          }
          if (audioContextRef.current) {
              audioContextRef.current.close();
          }
      };
  }, []);

  // Sync with message history to speak new AI messages automatically
  useEffect(() => {
      if (!messages || !isOpen) return;
      
      const lastIndex = messages.length - 1;
      if (lastIndex > lastProcessedMessageIndex) {
          const lastMsg = messages[lastIndex];
          
          // If it's a model message and we haven't processed it yet
          if (lastMsg.role === 'model') {
              const text = lastMsg.parts[0]?.text;
              if (text) {
                  speakResponse(text);
              }
          }
          setLastProcessedMessageIndex(lastIndex);
      }
  }, [messages, isOpen]);

  // Reset index when modal opens fresh
  useEffect(() => {
      if (isOpen && messages) {
          setLastProcessedMessageIndex(messages.length - 1);
      } else {
          // Stop speaking when closed
          if (activeSourceRef.current) {
              try { activeSourceRef.current.stop(); } catch(e) {}
          }
          setIsSpeaking(false);
      }
  }, [isOpen]);

  const toggleListening = () => {
      if (isListening) {
          recognitionRef.current?.stop();
          setIsListening(false);
      } else {
          // Stop any current speech
          if (activeSourceRef.current) {
              try { activeSourceRef.current.stop(); } catch(e) {}
          }
          setIsSpeaking(false);
          
          recognitionRef.current?.start();
          setIsListening(true);
      }
  };

  const cleanTextForSpeech = (text: string) => {
      // Basic cleanup, but Neural TTS handles punctuation better than browser TTS
      return text
          .replace(/[*#`]/g, '') // Remove harsh markdown symbols
          .replace(/\[(.*?)\]\(.*?\)/g, '$1') // Clean links
          .replace(/https?:\/\/\S+/g, 'link') // URLs
          .trim();
  };

  const speakResponse = async (text: string) => {
      if (!aiRef.current) return;
      
      // Stop any existing audio
      if (activeSourceRef.current) {
          try { activeSourceRef.current.stop(); } catch (e) {}
      }

      setIsSpeaking(true);
      const cleanText = cleanTextForSpeech(text);

      try {
          const response = await aiRef.current.models.generateContent({
              model: "gemini-2.5-flash-preview-tts",
              contents: [{ parts: [{ text: cleanText }] }],
              config: {
                  responseModalities: ['AUDIO'],
                  speechConfig: {
                      voiceConfig: {
                          prebuiltVoiceConfig: { voiceName: 'Zephyr' }, // Warm, feminine voice
                      },
                  },
              },
          });

          const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
          
          if (base64Audio) {
              // Lazy load AudioContext (browser requirement to be triggered by user interaction usually, but works in async flow if context resumed)
              if (!audioContextRef.current) {
                  audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
              }
              if (audioContextRef.current.state === 'suspended') {
                  await audioContextRef.current.resume();
              }

              const audioCtx = audioContextRef.current;
              const audioBuffer = await decodeAudioData(
                  decode(base64Audio),
                  audioCtx,
                  24000,
                  1
              );

              const source = audioCtx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(audioCtx.destination);
              source.onended = () => setIsSpeaking(false);
              
              activeSourceRef.current = source;
              source.start(0);
          } else {
              setIsSpeaking(false);
          }

      } catch (error) {
          console.error("TTS Generation failed", error);
          setIsSpeaking(false);
      }
  };

  const handleVoiceInput = (transcript: string) => {
      onSendMessage(transcript);
  };

  const handleAnalyzeBlock = async () => {
      if (!analysisInput.trim() || !aiRef.current) return;
      setIsAnalyzing(true);

      const systemPrompt = `
      **ROLE:** Elite Business Strategist.
      **TASK:** Analyze the user's situation and identify 3 distinct blocks/patterns.
      **FORMAT:** Return ONLY a valid JSON array.
      `;

      try {
          const result = await aiRef.current.models.generateContent({ 
              model: MODEL_SMART, // Uses Gemini 3 Pro for Intelligence
              contents: analysisInput,
              config: { systemInstruction: systemPrompt }
          });
          
          let responseText = result.text || "";
          const cleanJson = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
          const parsedData = JSON.parse(cleanJson);
          setAnalysisResults(parsedData);

      } catch (error) {
          console.error("Analysis failed", error);
          alert("I couldn't process that analysis right now.");
      } finally {
          setIsAnalyzing(false);
      }
  };

  const renderOrb = () => {
      // Determine Orb State
      const isProcessing = isChatLoading && !isSpeaking;
      
      return (
      <div className="relative flex flex-col items-center justify-center h-full space-y-8 animate-fadeIn">
          <div className="relative group cursor-pointer" onClick={toggleListening}>
              {/* Orb Core */}
              <div className={`absolute inset-0 rounded-full blur-3xl opacity-40 transition-all duration-1000 
                  ${isListening ? 'bg-red-500 scale-125' : 
                    isSpeaking ? 'bg-[#4FFFB0] scale-150 opacity-60' : 
                    isProcessing ? 'bg-purple-500 scale-125 animate-pulse' : 
                    'bg-[#4FFFB0] scale-100'}`}>
              </div>
              
              <div className={`relative w-40 h-40 rounded-full flex items-center justify-center border-2 backdrop-blur-md transition-all duration-500 
                  ${isListening ? 'border-red-500 bg-red-500/10' : 
                    isProcessing ? 'border-purple-500 bg-purple-500/10 animate-spin-slow' :
                    'border-[#4FFFB0] bg-[#4FFFB0]/10 shadow-[0_0_50px_rgba(79,255,176,0.3)]'}`}>
                  
                  {isProcessing ? (
                      <span className="material-icons text-6xl text-purple-400 animate-pulse">psychology</span>
                  ) : (
                      <span className={`material-icons text-6xl transition-colors ${isListening ? 'text-red-400' : 'text-[#4FFFB0]'}`}>
                          {isListening ? 'mic' : isSpeaking ? 'graphic_eq' : 'auto_awesome'}
                      </span>
                  )}
              </div>
              
              {/* Ambient Rings */}
              {!isListening && !isSpeaking && !isProcessing && (
                  <>
                    <div className="absolute inset-0 rounded-full border border-[#4FFFB0]/30 animate-ping-slow"></div>
                    <div className="absolute inset-0 rounded-full border border-[#4FFFB0]/20 animate-ping-slower delay-150"></div>
                  </>
              )}
              
              {/* Speaking Ripples */}
              {isSpeaking && (
                  <>
                    <div className="absolute inset-0 rounded-full border-2 border-[#4FFFB0]/40 animate-ping"></div>
                    <div className="absolute inset-0 rounded-full border-2 border-[#4FFFB0]/20 animate-ping delay-75"></div>
                  </>
              )}
          </div>

          <div className="text-center space-y-4 max-w-lg">
              {isSpeaking && messages && messages.length > 0 ? (
                  // Subtitles when speaking
                  <div className="bg-black/40 backdrop-blur-sm p-4 rounded-xl border border-white/5 animate-fadeIn">
                      <p className="text-gray-200 text-lg leading-relaxed font-medium italic">
                          "{messages[messages.length - 1].parts[0].text?.slice(0, 150)}..."
                      </p>
                  </div>
              ) : (
                  // Default Prompt
                  <div className="space-y-2">
                      <h2 className="text-3xl font-bold text-white font-['Outfit']">
                          {isListening ? 'Listening...' : isProcessing ? 'Thinking...' : `Hello, ${userProfile.name.split(' ')[0]}.`}
                      </h2>
                      <p className="text-gray-400">
                          {isListening ? 'Go ahead, I am listening.' : isProcessing ? 'Formulating response...' : "I'm here. What's on your mind?"}
                      </p>
                  </div>
              )}
          </div>

          {/* Controls */}
          <div className="flex space-x-4">
              <button 
                  onClick={toggleListening}
                  className={`px-8 py-3 rounded-full font-bold transition-all transform hover:scale-105 flex items-center ${isListening ? 'bg-red-500/20 text-red-400 border border-red-500' : 'bg-[#4FFFB0] text-black hover:bg-white'}`}
              >
                  <span className="material-icons mr-2">{isListening ? 'mic_off' : 'mic'}</span>
                  {isListening ? 'Stop Listening' : 'Speak'}
              </button>
              
              <button 
                  onClick={onClose}
                  className="px-6 py-3 rounded-full font-bold border border-white/20 text-white hover:bg-white/10 transition-all flex items-center"
              >
                  <span className="material-icons mr-2 text-sm">chat</span>
                  Open Chat View
              </button>
          </div>
      </div>
      );
  };

  const renderAnalysis = () => (
      <div className="h-full flex flex-col md:flex-row gap-6 animate-fadeIn">
          <div className="flex-1 flex flex-col bg-white/5 rounded-2xl p-6 border border-white/10">
              <h3 className="text-xl font-bold text-white mb-2">Strategy & Block Analysis</h3>
              <p className="text-sm text-gray-400 mb-4">Tell me about a specific challenge, decision, or friction point.</p>
              
              <textarea 
                  value={analysisInput}
                  onChange={(e) => setAnalysisInput(e.target.value)}
                  placeholder="E.g., I want to scale my agency but I'm afraid to hire..."
                  className="flex-1 bg-[#09090b] border border-white/10 rounded-xl p-4 text-gray-200 resize-none focus:border-[#4FFFB0] focus:ring-1 focus:ring-[#4FFFB0] outline-none mb-4"
              />
              
              <button 
                  onClick={handleAnalyzeBlock}
                  disabled={isAnalyzing || !analysisInput.trim()}
                  className="w-full py-4 bg-[#4FFFB0] text-black font-bold rounded-xl hover:bg-[#3ddda0] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                  {isAnalyzing ? (
                      <span className="material-icons animate-spin mr-2">refresh</span>
                  ) : (
                      <span className="material-icons mr-2">analytics</span>
                  )}
                  {isAnalyzing ? 'Analyzing Patterns...' : 'Analyze Blocks'}
              </button>
          </div>

          <div className="flex-1 bg-white/5 rounded-2xl p-6 border border-white/10 overflow-y-auto custom-scrollbar relative">
              {!analysisResults ? (
                  <div className="h-full flex flex-col items-center justify-center text-gray-500 opacity-50">
                      <span className="material-icons text-6xl mb-4">grid_view</span>
                      <p>Results will appear here</p>
                  </div>
              ) : (
                  <div className="space-y-4">
                      {analysisResults.map((result, idx) => (
                          <div key={idx} className="bg-[#09090b] rounded-xl p-5 border-l-4 border-[#4FFFB0]">
                              <div className="flex justify-between items-start mb-2">
                                  <h4 className="font-bold text-white text-lg">{result.insight}</h4>
                                  <span className={`text-[10px] font-bold px-2 py-1 rounded uppercase ${
                                      result.impact === 'HIGH' ? 'bg-red-500/20 text-red-400' : 
                                      result.impact === 'MODERATE' ? 'bg-amber-500/20 text-amber-400' : 
                                      'bg-blue-500/20 text-blue-400'
                                  }`}>
                                      {result.impact} Impact
                                  </span>
                              </div>
                              <div className="space-y-2">
                                  {result.strategies.map((strat, sIdx) => (
                                      <div key={sIdx} className="flex items-start text-sm text-gray-300 bg-white/5 p-2 rounded">
                                          <span className="material-icons text-xs text-[#4FFFB0] mt-0.5 mr-2">check_circle</span>
                                          {strat}
                                      </div>
                                  ))}
                              </div>
                          </div>
                      ))}
                  </div>
              )}
          </div>
      </div>
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/95 backdrop-blur-xl flex items-center justify-center z-[100] p-4 animate-fadeIn" onClick={onClose}>
      <div className="w-full max-w-6xl h-[90vh] bg-[#09090b] rounded-3xl overflow-hidden flex flex-col border border-white/10 shadow-2xl relative" onClick={e => e.stopPropagation()}>
        
        <div className="h-16 border-b border-white/10 flex items-center justify-between px-6 bg-[#121215]">
            <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#4FFFB0] to-blue-500 flex items-center justify-center">
                    <span className="material-icons text-black text-sm">spa</span>
                </div>
                <span className="font-bold text-white font-['Outfit'] tracking-wide">THE SANCTUARY</span>
            </div>
            
            <div className="flex space-x-1 bg-white/5 p-1 rounded-full">
                <button onClick={() => setMode('home')} className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${mode === 'home' ? 'bg-[#4FFFB0] text-black shadow-lg' : 'text-gray-400 hover:text-white'}`}>
                    Live Session
                </button>
                <button onClick={() => setMode('analysis')} className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${mode === 'analysis' ? 'bg-[#4FFFB0] text-black shadow-lg' : 'text-gray-400 hover:text-white'}`}>
                    Strategy Analysis
                </button>
            </div>

            <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-red-500/20 hover:text-red-400 transition-colors">
                <span className="material-icons text-sm">close</span>
            </button>
        </div>

        <div className="flex-1 overflow-hidden relative">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20 pointer-events-none"></div>
            
            <div className="relative z-10 h-full p-6">
                {mode === 'home' && (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
                        <div className="hidden lg:flex flex-col space-y-3 overflow-y-auto custom-scrollbar pr-2">
                            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Jump In</h3>
                            {QUICK_STARTS.map((starter, i) => (
                                <button 
                                    key={i}
                                    onClick={() => { onSendMessage(starter.prompt); }}
                                    className="p-4 bg-white/5 hover:bg-white/10 border border-white/5 hover:border-[#4FFFB0]/30 rounded-xl text-left group transition-all"
                                >
                                    <div className="flex items-center space-x-3 mb-1">
                                        <span className="material-icons text-[#4FFFB0] opacity-70 group-hover:opacity-100">{starter.icon}</span>
                                        <span className="font-bold text-gray-200 group-hover:text-white text-sm">{starter.title}</span>
                                    </div>
                                    <p className="text-xs text-gray-500 line-clamp-2">{starter.prompt}</p>
                                </button>
                            ))}
                        </div>

                        <div className="lg:col-span-2 bg-gradient-to-b from-[#121215] to-[#050505] rounded-2xl border border-white/10 overflow-hidden relative">
                            {renderOrb()}
                        </div>
                    </div>
                )}

                {mode === 'analysis' && renderAnalysis()}
            </div>
        </div>

      </div>
    </div>
  );
};

export default SanctuaryModal;
