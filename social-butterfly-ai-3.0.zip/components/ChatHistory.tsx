


import React, { useState, useMemo, useEffect } from 'react';
import { ChatSession } from '../types';

interface ChatHistoryProps {
  sessions: ChatSession[];
  activeSessionId: string | null;
  onNewChat: () => void;
  onSelectSession: (id: string) => void;
  onDeleteSession: (id: string) => void;
  isOpenOnMobile: boolean;
}

const ChatHistory: React.FC<ChatHistoryProps> = ({ sessions, activeSessionId, onNewChat, onSelectSession, onDeleteSession, isOpenOnMobile }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});

  const groupedSessions = useMemo(() => {
      const groups: Record<string, ChatSession[]> = {};
      
      const filtered = sessions.filter(s => {
          if (!searchTerm) return true;
          const term = searchTerm.toLowerCase();
          const matchesTitle = s.title.toLowerCase().includes(term);
          const matchesContent = s.messages.some(m => m.parts.some(p => p.text?.toLowerCase().includes(term)));
          return matchesTitle || matchesContent;
      });

      filtered.forEach(session => {
          const cat = session.category || 'General';
          if (!groups[cat]) {
              groups[cat] = [];
          }
          groups[cat].push(session);
      });
      
      return groups;
  }, [sessions, searchTerm]);

  useEffect(() => {
      if (searchTerm) {
          const allExpanded: Record<string, boolean> = {};
          Object.keys(groupedSessions).forEach(k => allExpanded[k] = true);
          setExpandedCategories(allExpanded);
      }
  }, [searchTerm, groupedSessions]);

  const toggleCategory = (category: string) => {
      setExpandedCategories(prev => ({
          ...prev,
          [category]: !prev[category]
      }));
  };

  const sortedCategories = Object.keys(groupedSessions).sort((a, b) => {
      if (a === 'General') return -1;
      if (b === 'General') return 1;
      return a.localeCompare(b);
  });

  return (
    <div className={`absolute md:relative z-[60] h-full w-64 bg-[#0A0A0A] text-white flex flex-col flex-shrink-0 transition-transform duration-300 ease-in-out ${isOpenOnMobile ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 border-r border-white/5 shadow-2xl`}>
      
      {/* Header & New Chat */}
      <div className="p-4 border-b border-white/5 space-y-4">
        <button
          onClick={onNewChat}
          className="w-full flex items-center justify-center p-3 rounded-lg bg-[#4FFFB0] text-black hover:bg-[#4FFFB0]/90 transition-all text-sm font-bold shadow-[0_0_15px_rgba(79,255,176,0.2)] hover:shadow-[0_0_20px_rgba(79,255,176,0.4)] transform hover:-translate-y-0.5"
        >
          <span className="material-icons mr-2" style={{ fontSize: '20px' }}>add</span>
          New Chat
        </button>

        {/* Search Bar */}
        <div className="relative group">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500 group-focus-within:text-[#4FFFB0] transition-colors">
                <span className="material-icons text-sm">search</span>
            </span>
            <input 
                type="text" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search chats..."
                className="w-full pl-9 pr-3 py-2 bg-[#18181b] border border-white/10 rounded-lg text-xs text-gray-300 focus:ring-1 focus:ring-[#4FFFB0] focus:border-[#4FFFB0] outline-none placeholder-gray-600 transition-all"
            />
        </div>
      </div>

      {/* Grouped List */}
      <nav className="flex-1 overflow-y-auto p-2 space-y-2 custom-scrollbar">
        {sortedCategories.length === 0 ? (
             <div className="text-center py-12 text-gray-600 text-xs">
                 <span className="material-icons text-3xl mb-2 opacity-20">chat_bubble_outline</span>
                 <p>{searchTerm ? 'No chats found' : 'Start a new conversation'}</p>
             </div>
        ) : (
            sortedCategories.map(category => (
                <div key={category} className="mb-1">
                    <button 
                        onClick={() => toggleCategory(category)}
                        className="w-full flex items-center justify-between px-3 py-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest hover:text-[#4FFFB0] transition-colors rounded hover:bg-white/5"
                    >
                        <span className="flex items-center truncate max-w-[180px]">
                            {category === 'General' && <span className="material-icons text-[14px] mr-2">chat_bubble_outline</span>}
                            {category === 'The Sanctuary' && <span className="material-icons text-[14px] mr-2">favorite</span>}
                            {category === 'Butterfly Academy' && <span className="material-icons text-[14px] mr-2">school</span>}
                            {category !== 'General' && category !== 'The Sanctuary' && category !== 'Butterfly Academy' && <span className="material-icons text-[14px] mr-2">folder</span>}
                            {category}
                        </span>
                        <span className={`material-icons text-sm transition-transform duration-200 ${expandedCategories[category] ? 'rotate-180' : ''}`}>expand_more</span>
                    </button>
                    
                    {expandedCategories[category] && (
                        <div className="mt-1 space-y-0.5 animate-fadeIn pl-2 border-l border-white/5 ml-2">
                            {groupedSessions[category].map(session => (
                                <div key={session.id} className="group relative">
                                    <button
                                        onClick={() => onSelectSession(session.id)}
                                        className={`w-full text-left px-3 py-2 rounded-md truncate text-sm transition-all ${
                                            session.id === activeSessionId 
                                            ? 'bg-[#4FFFB0]/10 text-[#4FFFB0] border-l-2 border-[#4FFFB0]' 
                                            : 'border-l-2 border-transparent text-gray-400 hover:bg-white/5 hover:text-white'
                                        }`}
                                    >
                                        {session.title || 'New Chat'}
                                    </button>
                                    <button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            if (window.confirm('Are you sure you want to delete this chat?')) {
                                            onDeleteSession(session.id);
                                            }
                                        }}
                                        className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-full text-gray-600 hover:text-red-400 hover:bg-white/10 opacity-0 group-hover:opacity-100 transition-all"
                                        aria-label="Delete chat"
                                    >
                                        <span className="material-icons" style={{ fontSize: '14px' }}>delete</span>
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            ))
        )}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-white/5 bg-[#050505]">
        <div className="flex items-center space-x-3 text-gray-400">
            <div className="w-8 h-8 rounded bg-[#4FFFB0] flex items-center justify-center shadow-[0_0_10px_rgba(79,255,176,0.3)]">
                 <span className="material-icons text-black text-sm">auto_awesome</span>
            </div>
            <div>
                <h3 className="text-xs font-bold text-white font-['Outfit']">Social Butterfly</h3>
                <p className="text-[10px] text-gray-500 font-mono">v3.2.0 Digital Dominion</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ChatHistory;
