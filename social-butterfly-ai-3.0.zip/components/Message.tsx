
import React, { useState } from 'react';
import { ChatMessage, MessagePart } from '../types';
import { ButterflyIcon } from './Header';

interface MessageProps {
  message: ChatMessage;
  userProfilePhoto?: string;
  onExport?: (content: string) => void;
}

const BotIcon = () => (
    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#18181b] flex items-center justify-center border border-white/10 shadow-sm">
        <ButterflyIcon className="h-6 w-6 text-[#4FFFB0]" />
    </div>
);

const UserIcon: React.FC<{ photo?: string }> = ({ photo }) => {
    if (photo) {
        return <img src={photo} alt="User" className="flex-shrink-0 w-10 h-10 rounded-full object-cover border-2 border-[#4FFFB0]/50" />;
    }
    return (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-[#4FFFB0] font-bold border border-white/10">
            <span>U</span>
        </div>
    );
};


const Message: React.FC<MessageProps> = ({ message, userProfilePhoto, onExport }) => {
  const [copied, setCopied] = useState(false);
  const isModel = message.role === 'model';

  const createMarkup = (text: string) => {
    if (typeof window !== 'undefined' && (window as any).marked) {
      return { __html: (window as any).marked.parse(text) };
    }
    return { __html: text.replace(/\n/g, '<br>') };
  };
  
  const textContent = message.parts.filter(p => p.text).map(p => p.text).join('\n\n');

  const handleCopy = () => {
    if (!textContent) return;
    navigator.clipboard.writeText(textContent).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(err => {
      console.error('Failed to copy text: ', err);
    });
  };
  
  // Grounding (Citations) handling
  const groundingChunks = message.groundingMetadata?.groundingChunks || [];
  const hasGrounding = groundingChunks.length > 0;

  if (isModel && message.parts.length === 0) {
    return null; // Don't render empty model messages (placeholders for streaming)
  }
  
  const renderPart = (part: MessagePart, index: number) => {
    if (part.inlineData?.mimeType.startsWith('image/')) {
        return (
            <div key={index} className="p-2">
                <img 
                    src={`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`} 
                    alt="User content" 
                    className="rounded-lg max-w-xs lg:max-w-sm border border-white/10"
                />
            </div>
        );
    }
    if (part.text) {
        return (
            <div
                key={index}
                className={`prose prose-sm max-w-2xl ${isModel ? 'text-gray-300 prose-headings:text-white prose-strong:text-white prose-code:text-[#4FFFB0] prose-code:bg-white/5 prose-code:px-1 prose-code:rounded' : 'text-black font-medium'}`}
                dangerouslySetInnerHTML={createMarkup(part.text)}
            />
        );
    }
    return null;
  };

  return (
    <div className={`flex items-start gap-4 ${isModel ? 'justify-start' : 'justify-end'}`}>
      {isModel && <BotIcon />}
      <div className="relative group">
        <div
            className={`px-5 py-4 rounded-2xl shadow-sm space-y-2 flex flex-col ${
            isModel 
                ? 'bg-[#18181b] border border-white/10 text-gray-200 rounded-tl-none' 
                : 'bg-[#4FFFB0] text-black rounded-tr-none shadow-[0_0_15px_rgba(79,255,176,0.1)]'
            }`}
        >
          {message.parts.map(renderPart)}
          
          {/* Sources Display (Grounding) */}
          {isModel && hasGrounding && (
              <div className="pt-3 mt-2 border-t border-white/10">
                  <p className="text-[10px] font-bold text-gray-500 mb-1 flex items-center uppercase tracking-wider">
                    <span className="material-icons text-[10px] mr-1">public</span>
                    Sources
                  </p>
                  <div className="flex flex-wrap gap-2">
                      {groundingChunks.map((chunk: any, i: number) => {
                          if (chunk.web?.uri) {
                              return (
                                  <a 
                                    key={i} 
                                    href={chunk.web.uri} 
                                    target="_blank" 
                                    rel="noopener noreferrer" 
                                    className="text-[10px] bg-white/5 hover:bg-white/10 text-[#4FFFB0] px-2 py-1 rounded flex items-center truncate max-w-[200px] border border-white/10 transition-colors"
                                  >
                                      <span className="material-icons text-[10px] mr-1">link</span>
                                      {chunk.web.title || 'Source Link'}
                                  </a>
                              )
                          }
                          return null;
                      })}
                  </div>
              </div>
          )}
        </div>
        
        {isModel && textContent && (
            <div className="absolute -bottom-8 left-0 opacity-0 group-hover:opacity-100 transition-all duration-200 flex space-x-2 z-10">
                {/* Copy Button */}
                <button 
                    onClick={handleCopy} 
                    className="p-1.5 rounded-full bg-[#27272a] text-gray-400 hover:text-white hover:bg-[#3f3f46] border border-white/10 shadow-sm focus:outline-none transition-colors"
                    aria-label={copied ? "Copied" : "Copy text"}
                    title="Copy to clipboard"
                >
                    <span className="material-icons" style={{ fontSize: '14px' }}>
                        {copied ? 'check' : 'content_copy'}
                    </span>
                </button>
                
                {/* Export Button */}
                {onExport && (
                    <button 
                        onClick={() => onExport(textContent)} 
                        className="p-1.5 rounded-full bg-[#27272a] text-gray-400 hover:text-[#4FFFB0] hover:bg-[#3f3f46] border border-white/10 shadow-sm focus:outline-none transition-colors"
                        aria-label="Export to Drive"
                        title="Export to Google Drive"
                    >
                        <span className="material-icons" style={{ fontSize: '14px' }}>save_alt</span>
                    </button>
                )}
            </div>
        )}
      </div>
      {!isModel && <UserIcon photo={userProfilePhoto} />}
    </div>
  );
};

export default Message;
