
import React from 'react';

const milestones = [
    { text: "Top 200 GPTs of 2024", icon: "emoji_events" },
    { text: "100,000+ Conversations in Year One", icon: "forum" },
    { text: "Featured in “Best GPTs of 2024” Lists", icon: "verified" },
    { text: "Expanded From GPT → Platform → AI Venture Builder", icon: "rocket_launch" },
    { text: "More than 200 AI Classes Taught, 2025", icon: "school" },
    { text: "Helped Thousands of Entrepreneurs Launch Offers & Digital Products", icon: "storefront" },
    { text: "Trusted By Professionals Worldwide for Strategy & AI Implementation", icon: "public" },
];

const LandingMilestones: React.FC = () => {
    return (
        <div className="w-full bg-[#09090b] border-b border-white/5 py-12 relative z-20 overflow-hidden">
            {/* Header */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-10 text-center">
                <h2 className="text-xs font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#4FFFB0] to-[#E0B069] uppercase tracking-[0.3em] font-['Outfit'] animate-pulse">
                    Our Metamorphosis
                </h2>
            </div>

            {/* Marquee Container */}
            <div className="relative w-full">
                {/* Fade Edges for seamless look */}
                <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-[#09090b] to-transparent z-10 pointer-events-none"></div>
                <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-[#09090b] to-transparent z-10 pointer-events-none"></div>

                {/* Scrolling Track */}
                <div className="flex space-x-16 animate-scroll whitespace-nowrap pl-4">
                    {/* Render triple set for smooth infinite loop on wide screens */}
                    {[...milestones, ...milestones, ...milestones].map((m, i) => (
                        <div key={i} className="flex items-center space-x-4 group cursor-default select-none">
                            <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center border border-white/10 group-hover:border-[#4FFFB0]/50 group-hover:bg-[#4FFFB0]/10 transition-all duration-300">
                                <span className="material-icons text-gray-500 group-hover:text-[#4FFFB0] text-xl transition-colors duration-300">{m.icon}</span>
                            </div>
                            <span className="text-gray-400 font-['Plus_Jakarta_Sans'] font-medium text-sm md:text-base group-hover:text-white transition-colors duration-300 tracking-wide">
                                {m.text}
                            </span>
                        </div>
                    ))}
                </div>
            </div>

            {/* Inline Styles for Animation */}
            <style>{`
                @keyframes scroll {
                    0% { transform: translateX(0); }
                    100% { transform: translateX(-33.33%); }
                }
                .animate-scroll {
                    animation: scroll 40s linear infinite;
                }
                .animate-scroll:hover {
                    animation-play-state: paused;
                }
            `}</style>
        </div>
    );
};

export default LandingMilestones;
