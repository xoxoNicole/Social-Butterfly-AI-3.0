
import React, { useState, useEffect, useRef } from 'react';
import LoadingSpinner from './LoadingSpinner';
import { MediaAsset, subscribeToAssets, deleteAsset, auth } from '../services/firebase';

type Mode = 'text' | 'image' | 'continue';

interface VideoGenerationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (prompt: string, aspectRatio: '16:9' | '9:16', sourceImage?: { base64: string, mimeType: string }, sourceVideoUrl?: string) => Promise<void>;
  isLoading: boolean;
  loadingMessage: string;
  generatedVideo: string | null;
  initialMode: 'text' | 'image';
  initialPrompt?: string;
  initialImage?: { base64: string, mimeType: string };
}

const blobToBase64 = (blob: Blob): Promise<{ base64: string, mimeType: string }> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64String = (reader.result as string).split(',')[1];
            resolve({ base64: base64String, mimeType: blob.type });
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
};

// --- SCENE BUILDER DATA ---
const SHOTS = ['Wide Shot', 'Medium Shot', 'Close-up', 'Extreme Close-up', 'Low Angle', 'High Angle', 'Overhead View', 'Point of View'];
const MOVES = ['Static', 'Pan Left', 'Pan Right', 'Tilt Up', 'Tilt Down', 'Zoom In', 'Zoom Out', 'Tracking Shot', 'Handheld'];
const LIGHTING = ['Cinematic Lighting', 'Natural Light', 'Golden Hour', 'Blue Hour', 'Neon Noir', 'Studio Lighting', 'Hard Light', 'Soft Light'];

const VideoGenerationModal: React.FC<VideoGenerationModalProps> = ({ isOpen, onClose, onGenerate, isLoading, loadingMessage, generatedVideo, initialMode, initialPrompt, initialImage }) => {
  const [activeMode, setActiveMode] = useState<Mode>(initialMode);
  const [prompt, setPrompt] = useState('');
  
  // Configuration State
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [resolution, setResolution] = useState('720p'); // Default for Veo Beta
  
  // Scene Builder State
  const [showSceneBuilder, setShowSceneBuilder] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const [selectedShot, setSelectedShot] = useState('');
  const [selectedMove, setSelectedMove] = useState('');
  const [selectedLighting, setSelectedLighting] = useState('');

  const [sourceImage, setSourceImage] = useState<{ file: File, url: string, data: { base64: string, mimeType: string } } | null>(null);
  
  // History & Selection
  const [assets, setAssets] = useState<MediaAsset[]>([]);
  const [selectedAsset, setSelectedAsset] = useState<MediaAsset | null>(null);

  const [isKeyNeeded, setIsKeyNeeded] = useState(false);
  const [apiKeyError, setApiKeyError] = useState(false);
  const [generalError, setGeneralError] = useState<string | null>(null);
  
  // Retry State
  const [retryCount, setRetryCount] = useState(0);
  const [retryTimer, setRetryTimer] = useState(0);

  const scenePanelRef = useRef<HTMLDivElement>(null);
  const configPanelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!auth.currentUser) return;
    const unsubscribe = subscribeToAssets(auth.currentUser.uid, (allAssets) => {
        const videos = allAssets.filter(a => a.type === 'video');
        setAssets(videos);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (isOpen) {
        setActiveMode(initialMode);
        setPrompt(initialPrompt || '');
        setApiKeyError(false);
        setGeneralError(null);
        setRetryCount(0);
        setRetryTimer(0);
        checkApiKey();
        
        if (initialImage) {
             const mockUrl = `data:${initialImage.mimeType};base64,${initialImage.base64}`;
             setSourceImage({
                 file: { name: 'Uploaded Image' } as File,
                 url: mockUrl,
                 data: initialImage
             });
             setActiveMode('image');
        } else {
            setSourceImage(null);
        }
    }
  }, [isOpen, initialMode, initialPrompt, initialImage]);

  // Click outside listener to close panels
  useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
          if (scenePanelRef.current && !scenePanelRef.current.contains(event.target as Node)) {
              setShowSceneBuilder(false);
          }
          if (configPanelRef.current && !configPanelRef.current.contains(event.target as Node)) {
              setShowConfig(false);
          }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
      if (generatedVideo) {
           setSelectedAsset({
              id: 'temp',
              userId: auth.currentUser?.uid || '',
              type: 'video',
              url: generatedVideo,
              prompt: prompt,
              createdAt: new Date().toISOString()
          });
          setRetryCount(0);
          setRetryTimer(0);
      }
  }, [generatedVideo]);

  const checkApiKey = async () => {
    if ((window as any).aistudio && typeof (window as any).aistudio.hasSelectedApiKey === 'function') {
        const hasKey = await (window as any).aistudio.hasSelectedApiKey();
        setIsKeyNeeded(!hasKey);
    }
  };

  const handleSelectKey = async () => {
    if ((window as any).aistudio && typeof (window as any).aistudio.openSelectKey === 'function') {
      await (window as any).aistudio.openSelectKey();
      setIsKeyNeeded(false);
      setApiKeyError(false);
      setGeneralError(null);
    }
  };

  const handleSelectAsset = (asset: MediaAsset) => {
      setSelectedAsset(asset);
      // When selecting a video, we enter "Continue Scene" mode implicitly if active mode wasn't set explicitly to something else recently
      if (asset.type === 'video') {
          setActiveMode('continue');
          setPrompt(''); // Clear prompt so user can describe what happens NEXT
      }
  };

  const handleDeleteAsset = async (e: React.MouseEvent, id: string) => {
      e.stopPropagation();
      if(window.confirm("Delete this video?")) {
          if (auth.currentUser) await deleteAsset(auth.currentUser.uid, id);
          if (selectedAsset?.id === id) {
              setSelectedAsset(null);
              setActiveMode('text');
          }
      }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      const data = await blobToBase64(file);
      setSourceImage({ file, url, data });
      setActiveMode('image');
    }
  };

  const appendToPrompt = (text: string) => {
      setPrompt(prev => {
          const cleanPrev = prev.trim();
          if (cleanPrev.length === 0) return text;
          if (cleanPrev.endsWith(',')) return `${cleanPrev} ${text}`;
          return `${cleanPrev}, ${text}`;
      });
  };

  const executeGenerate = async (attempt: number) => {
    setGeneralError(null);
    setApiKeyError(false);
    
    try {
        // If continue mode, we pass the video URL
        const videoSource = activeMode === 'continue' && selectedAsset ? selectedAsset.url : undefined;
        
        await onGenerate(prompt, aspectRatio, sourceImage?.data, videoSource);
    } catch (error: any) {
        console.error(`Video Generation Attempt ${attempt} Failed:`, error);
        let msg = error.message || error.toString();

        const jsonMatch = msg.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
            try {
                const parsed = JSON.parse(jsonMatch[0]);
                if (parsed.error && parsed.error.message) {
                    msg = parsed.error.message;
                }
            } catch (e) {}
        }

        const isQuotaError = msg.includes("RESOURCE_EXHAUSTED") || msg.includes("429") || msg.toLowerCase().includes("quota");
        
        if (isQuotaError) {
            setGeneralError("Daily video generation limit reached. Please try again tomorrow.");
            return;
        }

        if (msg.toLowerCase().includes("api key") || msg.toLowerCase().includes("entity was not found") || msg.includes("404")) {
            setApiKeyError(true);
            setIsKeyNeeded(true);
            return;
        }

        if (attempt < 3) {
             const waitTime = (attempt + 1) * 5;
             setRetryTimer(waitTime);
             setRetryCount(attempt + 1);
             
             const interval = setInterval(() => {
                 setRetryTimer((prev) => {
                     if (prev <= 1) {
                         clearInterval(interval);
                         return 0;
                     }
                     return prev - 1;
                 });
             }, 1000);

             setTimeout(() => {
                 executeGenerate(attempt + 1);
             }, waitTime * 1000);
             return; 
         }
         
        setGeneralError(msg);
        setRetryCount(0);
        setRetryTimer(0);
    }
  };

  const handleSubmit = async () => {
    if (activeMode === 'image' && !sourceImage) {
        setGeneralError("Please upload an image to animate.");
        return;
    }
    if (activeMode === 'continue' && !selectedAsset) {
        setGeneralError("Please select a video to continue.");
        return;
    }
    setRetryCount(0);
    executeGenerate(0);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] flex flex-col md:flex-row bg-[#0f0f12] text-white font-sans animate-fadeIn">
        
        {/* SIDEBAR: ASSET LIBRARY */}
        <div className="w-full md:w-72 flex-shrink-0 bg-[#18181b] border-b md:border-b-0 md:border-r border-[#27272a] flex flex-col h-1/3 md:h-full">
            <div className="p-4 border-b border-[#27272a] flex items-center space-x-3">
                <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                    <span className="material-icons">arrow_back</span>
                </button>
                <span className="font-bold text-sm tracking-wide text-gray-200">PROJECT MEDIA</span>
            </div>
            
            <div className="flex-1 overflow-y-auto p-3 space-y-3 custom-scrollbar">
                {assets.length === 0 ? (
                    <div className="text-center py-10 opacity-40">
                        <span className="material-icons text-4xl mb-2">videocam_off</span>
                        <p className="text-xs">No clips yet.</p>
                    </div>
                ) : (
                    assets.map(asset => (
                        <div 
                            key={asset.id} 
                            onClick={() => handleSelectAsset(asset)}
                            className={`relative group cursor-pointer rounded-lg overflow-hidden border transition-all ${selectedAsset?.id === asset.id ? 'border-[#4FFFB0] ring-1 ring-[#4FFFB0]' : 'border-[#3f3f46] hover:border-gray-400'}`}
                        >
                            <video src={asset.url} className="w-full h-20 object-cover pointer-events-none" />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-2">
                                <p className="text-[10px] text-gray-300 truncate w-full">{asset.prompt}</p>
                            </div>
                            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={(e) => handleDeleteAsset(e, asset.id)} className="bg-black/60 p-1 rounded hover:bg-red-900/80 text-white">
                                    <span className="material-icons text-[12px]">delete</span>
                                </button>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>

        {/* MAIN STUDIO AREA */}
        <div className="flex-1 flex flex-col relative bg-[#09090b] h-2/3 md:h-full">
            
            {/* TOP BAR */}
            <div className="h-14 border-b border-[#27272a] flex items-center justify-between px-6 bg-[#18181b] relative z-50">
                <div className="flex items-center space-x-4">
                    <span className="text-[#4FFFB0] material-icons">movie_filter</span>
                    <h2 className="font-bold text-sm tracking-widest text-gray-200 uppercase font-['Outfit']">Veo Studio <span className="ml-2 px-1.5 py-0.5 rounded bg-[#4FFFB0]/10 text-[#4FFFB0] text-[9px] border border-[#4FFFB0]/30">BETA</span></h2>
                </div>
                
                {/* Mode Indicator */}
                <div className="hidden md:flex bg-black/50 rounded-lg p-1 border border-[#27272a]">
                    <button 
                        onClick={() => { setActiveMode('text'); setSelectedAsset(null); }}
                        className={`px-4 py-1 rounded text-xs font-medium transition-all ${activeMode === 'text' ? 'bg-[#27272a] text-white shadow-sm' : 'text-gray-500 hover:text-gray-300'}`}
                    >
                        Text to Video
                    </button>
                    <button 
                        onClick={() => { setActiveMode('image'); setSelectedAsset(null); }}
                        className={`px-4 py-1 rounded text-xs font-medium transition-all ${activeMode === 'image' ? 'bg-[#27272a] text-white shadow-sm' : 'text-gray-500 hover:text-gray-300'}`}
                    >
                        Image to Video
                    </button>
                    <button 
                        onClick={() => { setActiveMode('continue'); setPrompt(''); }}
                        className={`px-4 py-1 rounded text-xs font-medium transition-all flex items-center ${activeMode === 'continue' ? 'bg-[#27272a] text-[#4FFFB0] shadow-sm border border-[#4FFFB0]/30' : 'text-gray-500 hover:text-gray-300'}`}
                    >
                        <span className="material-icons text-[12px] mr-1">fast_forward</span>
                        Continue Scene
                    </button>
                </div>

                <div className="flex items-center space-x-3">
                    {retryCount > 0 && (
                        <span className="text-xs text-amber-500 animate-pulse font-mono">Retrying in {retryTimer}s...</span>
                    )}
                    <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors cursor-pointer p-2 hover:bg-[#27272a] rounded-full">
                        <span className="material-icons">close</span>
                    </button>
                </div>
            </div>

            {/* PREVIEW / CANVAS */}
            <div className="flex-1 flex items-center justify-center p-4 md:p-8 bg-[#09090b] relative overflow-hidden">
                <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#27272a_1px,transparent_1px)] [background-size:16px_16px]"></div>
                
                {isLoading ? (
                    <div className="flex flex-col items-center z-10">
                        <LoadingSpinner />
                        <p className="mt-4 text-[#4FFFB0] font-mono text-sm tracking-widest uppercase animate-pulse">{loadingMessage}</p>
                    </div>
                ) : generalError ? (
                    <div className="bg-red-900/20 border border-red-900/50 p-6 rounded-xl text-center max-w-md z-10 backdrop-blur-md">
                        <span className="material-icons text-3xl text-red-500 mb-2">warning</span>
                        <p className="text-red-200 text-sm mb-4">{generalError}</p>
                        <button onClick={() => setGeneralError(null)} className="px-4 py-2 bg-red-900/50 hover:bg-red-800 text-white rounded text-xs border border-red-700 transition-colors">Dismiss</button>
                    </div>
                ) : selectedAsset ? (
                    <div className="relative group max-h-full max-w-full shadow-2xl z-10">
                        <video 
                            src={selectedAsset.url} 
                            controls 
                            autoPlay 
                            loop 
                            className="max-h-[70vh] rounded border border-[#27272a] bg-black" 
                        />
                        {activeMode === 'continue' && (
                            <div className="absolute top-4 left-4 bg-[#4FFFB0]/90 text-black text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider backdrop-blur-md shadow-lg flex items-center">
                                <span className="material-icons text-[12px] mr-1">history_edu</span>
                                Previous Context
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="text-center opacity-20 z-10 select-none">
                        <span className="material-icons text-8xl">movie</span>
                        <p className="mt-4 font-mono text-sm uppercase tracking-widest">Preview Window</p>
                    </div>
                )}
            </div>

            {/* BOTTOM CONTROLS (The "Desk") */}
            <div className="h-auto bg-[#18181b] border-t border-[#27272a] p-4 flex flex-col gap-4 relative z-20">
                
                {/* TOOLBAR */}
                <div className="flex items-center space-x-2">
                    {/* Scene Builder Toggle */}
                    <div className="relative">
                        <button 
                            onClick={() => { setShowSceneBuilder(!showSceneBuilder); setShowConfig(false); }}
                            className={`p-2 rounded hover:bg-[#27272a] transition-colors ${showSceneBuilder ? 'text-[#4FFFB0] bg-[#27272a]' : 'text-gray-400'}`}
                            title="Scene Builder"
                        >
                            <span className="material-icons">movie_filter</span>
                        </button>
                        
                        {/* SCENE BUILDER POPUP */}
                        {showSceneBuilder && (
                            <div ref={scenePanelRef} className="absolute bottom-12 left-0 w-64 bg-[#18181b] border border-[#3f3f46] rounded-lg shadow-2xl p-4 animate-slideInUp z-50">
                                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Scene Composition</h4>
                                
                                <div className="space-y-3">
                                    <div>
                                        <label className="text-[10px] text-gray-400 block mb-1">CAMERA SHOT</label>
                                        <select 
                                            value={selectedShot}
                                            onChange={(e) => { setSelectedShot(e.target.value); appendToPrompt(e.target.value); }}
                                            className="w-full bg-[#27272a] border border-[#3f3f46] rounded text-xs text-white p-2 outline-none focus:border-[#4FFFB0]"
                                        >
                                            <option value="">Select Shot...</option>
                                            {SHOTS.map(s => <option key={s} value={s}>{s}</option>)}
                                        </select>
                                    </div>
                                    <div>
                                        <label className="text-[10px] text-gray-400 block mb-1">CAMERA MOVEMENT</label>
                                        <select 
                                            value={selectedMove}
                                            onChange={(e) => { setSelectedMove(e.target.value); appendToPrompt(e.target.value); }}
                                            className="w-full bg-[#27272a] border border-[#3f3f46] rounded text-xs text-white p-2 outline-none focus:border-[#4FFFB0]"
                                        >
                                            <option value="">Select Move...</option>
                                            {MOVES.map(m => <option key={m} value={m}>{m}</option>)}
                                        </select>
                                    </div>
                                    <div>
                                        <label className="text-[10px] text-gray-400 block mb-1">LIGHTING & STYLE</label>
                                        <select 
                                            value={selectedLighting}
                                            onChange={(e) => { setSelectedLighting(e.target.value); appendToPrompt(e.target.value); }}
                                            className="w-full bg-[#27272a] border border-[#3f3f46] rounded text-xs text-white p-2 outline-none focus:border-[#4FFFB0]"
                                        >
                                            <option value="">Select Lighting...</option>
                                            {LIGHTING.map(l => <option key={l} value={l}>{l}</option>)}
                                        </select>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Config Toggle */}
                    <div className="relative">
                        <button 
                            onClick={() => { setShowConfig(!showConfig); setShowSceneBuilder(false); }}
                            className={`p-2 rounded hover:bg-[#27272a] transition-colors ${showConfig ? 'text-[#4FFFB0] bg-[#27272a]' : 'text-gray-400'}`}
                            title="Configuration"
                        >
                            <span className="material-icons">tune</span>
                        </button>

                        {/* CONFIG POPUP */}
                        {showConfig && (
                            <div ref={configPanelRef} className="absolute bottom-12 left-0 w-56 bg-[#18181b] border border-[#3f3f46] rounded-lg shadow-2xl p-4 animate-slideInUp z-50">
                                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Technical Specs</h4>
                                <div className="space-y-3">
                                    <div>
                                        <label className="text-[10px] text-gray-400 block mb-1">ASPECT RATIO</label>
                                        <div className="grid grid-cols-2 gap-2">
                                            <button 
                                                onClick={() => setAspectRatio('16:9')}
                                                className={`px-2 py-1.5 text-xs rounded border ${aspectRatio === '16:9' ? 'bg-[#4FFFB0]/10 border-[#4FFFB0] text-[#4FFFB0]' : 'border-[#3f3f46] text-gray-400 hover:bg-[#27272a]'}`}
                                            >
                                                16:9 Wide
                                            </button>
                                            <button 
                                                onClick={() => setAspectRatio('9:16')}
                                                className={`px-2 py-1.5 text-xs rounded border ${aspectRatio === '9:16' ? 'bg-[#4FFFB0]/10 border-[#4FFFB0] text-[#4FFFB0]' : 'border-[#3f3f46] text-gray-400 hover:bg-[#27272a]'}`}
                                            >
                                                9:16 Reel
                                            </button>
                                        </div>
                                    </div>
                                    <div>
                                        <label className="text-[10px] text-gray-400 block mb-1">RESOLUTION</label>
                                        <select 
                                            value={resolution}
                                            onChange={(e) => setResolution(e.target.value)}
                                            className="w-full bg-[#27272a] border border-[#3f3f46] rounded text-xs text-white p-2 outline-none focus:border-[#4FFFB0]"
                                        >
                                            <option value="720p">720p (HD)</option>
                                            <option value="1080p">1080p (FHD)</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>

                    {activeMode === 'image' && (
                        <label className="flex items-center space-x-2 bg-[#27272a] px-3 py-1.5 rounded-full cursor-pointer hover:bg-[#3f3f46] transition-colors border border-[#3f3f46] text-xs text-gray-300">
                            <span className="material-icons text-sm">add_photo_alternate</span>
                            <span className="truncate max-w-[100px]">{sourceImage ? 'Change Image' : 'Upload Source'}</span>
                            <input type="file" className="hidden" accept="image/png, image/jpeg" onChange={handleImageUpload} />
                        </label>
                    )}
                </div>

                {/* PROMPT AREA */}
                <div className="flex gap-4">
                    <div className="flex-1 relative">
                        <textarea
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder={
                                activeMode === 'continue' 
                                ? "Describe what happens NEXT in the scene..." 
                                : activeMode === 'image' 
                                ? "Describe how this image should move..." 
                                : "Describe your scene (e.g. A cyberpunk city in rain, neon lights)..."
                            }
                            className="w-full bg-[#09090b] border border-[#27272a] rounded-lg p-3 text-sm text-gray-200 placeholder-gray-600 focus:ring-1 focus:ring-[#4FFFB0] focus:border-[#4FFFB0] resize-none h-20 leading-relaxed font-mono"
                        />
                        {/* Prompt Length Indicator */}
                        <div className="absolute bottom-2 right-2 text-[10px] text-gray-600 font-mono">
                            {prompt.length} chars
                        </div>
                    </div>

                    {/* ACTION BUTTON */}
                    <div className="flex flex-col justify-end">
                        {isKeyNeeded || apiKeyError ? (
                            <button
                                onClick={handleSelectKey}
                                className="h-full px-6 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg shadow-lg flex flex-col items-center justify-center animate-pulse min-w-[100px]"
                            >
                                <span className="material-icons mb-1">vpn_key</span>
                                <span className="text-xs">API Key</span>
                            </button>
                        ) : (
                            <button 
                                onClick={handleSubmit}
                                disabled={isLoading || (!prompt.trim() && activeMode !== 'image') || (activeMode === 'image' && !sourceImage)}
                                className={`h-full px-6 font-bold rounded-lg shadow-lg flex flex-col items-center justify-center min-w-[120px] transition-all ${
                                    isLoading 
                                    ? 'bg-[#27272a] text-gray-500 cursor-wait border border-[#3f3f46]' 
                                    : activeMode === 'continue'
                                    ? 'bg-gradient-to-br from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white'
                                    : 'bg-[#4FFFB0] hover:bg-[#3ddda0] text-black'
                                }`}
                            >
                                {isLoading ? (
                                    <>
                                        <LoadingSpinner />
                                    </>
                                ) : (
                                    <>
                                        <span className="material-icons mb-1">{activeMode === 'continue' ? 'fast_forward' : 'movie_creation'}</span>
                                        <span className="text-xs uppercase tracking-wider">{activeMode === 'continue' ? 'Continue' : 'Generate'}</span>
                                    </>
                                )}
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default VideoGenerationModal;
