
import React, { useState } from 'react';
import { individualPlans, teamPlans, Plan } from '../plans';

interface LandingPricingProps {
  onEnterApp: () => void;
}

const CheckIcon = ({ dark }: { dark?: boolean }) => (
  <svg className={`h-5 w-5 ${dark ? 'text-[#4FFFB0]' : 'text-[#4FFFB0]'}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
  </svg>
);

const PricingCard: React.FC<{
  plan: Plan;
  billingCycle: 'monthly' | 'annual';
  isTeamPlan?: boolean;
  onSubscribe: () => void;
}> = ({ plan, billingCycle, isTeamPlan = false, onSubscribe }) => {
  const [seats, setSeats] = useState(isTeamPlan ? (plan.id === 'team' ? 2 : 10) : 1);
  const price = plan.pricing[billingCycle];
  const totalMonthlyPrice = price * seats;
  const isPremium = plan.isFeatured || plan.id === 'business';

  const features = typeof plan.features === 'function' ? plan.features(billingCycle) : plan.features;

  return (
    <div className={`relative p-8 flex flex-col transition-all duration-300 ${
        isPremium 
        ? 'bg-[#0f0518] text-white shadow-2xl scale-105 border border-[#4FFFB0]/30 rounded-2xl z-10' 
        : 'bg-white text-gray-900 border border-gray-200 rounded-xl hover:border-[#4FFFB0]/50'
    }`}>
      {plan.isFeatured && (
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-[#4FFFB0] text-black text-xs font-bold px-4 py-1 rounded-full uppercase tracking-wider shadow-lg shadow-[#4FFFB0]/20">
            Best Value
        </div>
      )}
      
      <h3 className={`text-2xl font-serif font-bold ${isPremium ? 'text-white' : 'text-gray-900'}`}>{plan.name}</h3>
      <p className={`mt-2 text-sm h-10 ${isPremium ? 'text-gray-400' : 'text-gray-500'}`}>{plan.description}</p>
      
      <div className="mt-6 flex items-baseline">
        <span className="text-5xl font-sans font-bold tracking-tight">${totalMonthlyPrice}</span>
        <span className={`ml-2 text-base font-medium ${isPremium ? 'text-gray-400' : 'text-gray-500'}`}>/mo</span>
      </div>
      
      <p className={`mt-4 text-sm font-bold uppercase tracking-wide ${isPremium ? 'text-[#4FFFB0]' : 'text-[#4FFFB0]'}`}>
        {plan.credits.toLocaleString()} Credits
      </p>

      {isTeamPlan && (
        <div className="mt-4 p-3 rounded bg-white/5 border border-white/10">
          <label className={`block text-xs font-bold uppercase mb-2 ${isPremium ? 'text-gray-400' : 'text-gray-500'}`}>Seats</label>
          <input 
            type="number" 
            value={seats} 
            onChange={(e) => setSeats(Math.max(1, parseInt(e.target.value) || 1))}
            className={`w-full bg-transparent border-b p-1 ${isPremium ? 'border-gray-700 text-white' : 'border-gray-300 text-black'}`}
          />
        </div>
      )}

      <ul className="mt-8 space-y-4 flex-grow">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start">
            <div className="flex-shrink-0 pt-1"><CheckIcon dark={isPremium} /></div>
            <p className={`ml-3 text-sm leading-relaxed ${isPremium ? 'text-gray-300' : 'text-gray-600'}`} dangerouslySetInnerHTML={{ __html: feature }} />
          </li>
        ))}
      </ul>

      <button 
        onClick={onSubscribe} 
        className={`mt-8 w-full py-4 px-6 rounded-lg text-center font-bold tracking-wide transition-all ${
            isPremium 
            ? 'bg-[#4FFFB0] text-black hover:bg-white hover:scale-105 shadow-[0_0_15px_rgba(79,255,176,0.3)]' 
            : 'bg-black text-white hover:bg-[#4FFFB0] hover:text-black'
        }`}
      >
        Choose {plan.name}
      </button>
    </div>
  );
};

const LandingPricing: React.FC<LandingPricingProps> = ({ onEnterApp }) => {
  const [planType, setPlanType] = useState<'individual' | 'team'>('individual');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');
  
  const plansToShow = planType === 'individual' ? individualPlans : teamPlans;

  return (
    <section id="pricing" className="py-24 bg-gray-50 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-medium text-gray-900 mb-4">
            Invest in Your Growth
          </h2>
          <p className="text-lg text-gray-600">
            Simple, transparent pricing for entrepreneurs ready to scale.
          </p>
        </div>

        {/* Controls */}
        <div className="flex justify-center mb-12">
            <div className="bg-white p-1.5 rounded-full shadow-sm border border-gray-200 flex items-center space-x-1">
                <button onClick={() => setPlanType('individual')} className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${planType === 'individual' ? 'bg-black text-white shadow-md' : 'text-gray-500 hover:text-gray-900'}`}>Individual</button>
                <button onClick={() => setPlanType('team')} className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${planType === 'team' ? 'bg-black text-white shadow-md' : 'text-gray-500 hover:text-gray-900'}`}>Team</button>
            </div>
            <div className="mx-4 h-10 w-px bg-gray-300"></div>
            <div className="bg-white p-1.5 rounded-full shadow-sm border border-gray-200 flex items-center space-x-1">
                <button onClick={() => setBillingCycle('monthly')} className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${billingCycle === 'monthly' ? 'bg-gray-100 text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}>Monthly</button>
                <button onClick={() => setBillingCycle('annual')} className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${billingCycle === 'annual' ? 'bg-[#4FFFB0]/10 text-[#009966]' : 'text-gray-500 hover:text-gray-900'}`}>Annual <span className="ml-1 text-[10px] bg-[#4FFFB0] text-black px-1.5 py-0.5 rounded-full">-20%</span></button>
            </div>
        </div>

        <div className={`grid gap-8 items-start ${planType === 'individual' ? 'lg:grid-cols-3' : 'lg:grid-cols-2 max-w-4xl mx-auto'}`}>
          {plansToShow.map(plan => (
            <PricingCard 
              key={plan.id}
              plan={plan}
              billingCycle={billingCycle}
              isTeamPlan={planType === 'team'}
              onSubscribe={onEnterApp}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default LandingPricing;
