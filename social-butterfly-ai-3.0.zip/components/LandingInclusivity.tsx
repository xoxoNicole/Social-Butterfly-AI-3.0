
import React from 'react';

const LandingInclusivity: React.FC = () => {
    return (
        <section id="for-everyone" className="py-20 bg-gray-50 scroll-mt-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="lg:grid lg:grid-cols-2 lg:gap-16 lg:items-center">
                    <div>
                        <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
                            For Every Visionary And Every Dream.
                        </h2>
                        <p className="mt-4 text-lg text-gray-600">
                            What are you building? We will help you take your ideas out of your thought bubble and get them into the cloud as a real, deployed technical enterprise ready to receive clients and customers.
                        </p>
                        <div className="mt-8 p-6 bg-[#4FFFB0]/10 rounded-lg border-l-4 border-[#4FFFB0]">
                            <h3 className="text-lg font-semibold text-gray-900">
                                The Sky is Not the Limit.
                            </h3>
                        </div>
                    </div>
                    
                    {/* VIDEO REPLACEMENT */}
                    <div className="mt-10 lg:mt-0 rounded-2xl shadow-2xl overflow-hidden border border-gray-200 bg-white">
                        <video 
                            autoPlay
                            loop
                            muted
                            playsInline
                            className="w-full h-auto object-cover"
                        >
                            <source src="https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/SB_Let'sGo.mp4?alt=media&token=fff801fc-10d7-4c90-b6ba-e3b067fada12" type="video/mp4" />
                        </video>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default LandingInclusivity;
