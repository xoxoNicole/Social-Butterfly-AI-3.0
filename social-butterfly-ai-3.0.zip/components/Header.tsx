
import React, { useState, useRef, useEffect } from 'react';

export const ButterflyIcon = ({ className = "h-8 w-8 text-[#4FFFB0]" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 12c0-2.667 2-4 4-4s4 1.333 4 4c0 2.667-2 4-4 4s-4-1.333-4-4z" />
        <path d="M12 12c0-2.667-2-4-4-4S4 9.333 4 12c0 2.667 2 4 4 4s4-1.333 4-4z" />
        <path d="M16 12a4 4 0 01-4 4" />
        <path d="M8 12a4 4 0 004 4" />
        <path d="M12 2v2" />
        <path d="M12 20v2" />
        <path d="M20 12h2" />
        <path d="M2 12h2" />
    </svg>
);

interface HeaderProps {
    onEnterApp?: () => void;
    onLogin?: () => void;
    onGoHome?: () => void;
    onToggleTasks?: () => void;
    onOpenProfile?: () => void;
    onToggleSidebar?: () => void;
    onOpenExport?: () => void;
    onOpenUpdates?: () => void;
    onOpenAdmin?: () => void;
    onOpenSupport?: () => void;
    onLogout?: () => void;
    isChatPage?: boolean;
    showDashboard?: boolean;
    hasUnreadUpdates?: boolean;
    ticketCount?: number;
    profile?: { name: string; business: string; photo: string, credits?: number, role?: string, plan?: { id: string } };
}

const Header: React.FC<HeaderProps> = ({ onEnterApp, onLogin, onGoHome, onToggleTasks, onOpenProfile, onToggleSidebar, onOpenExport, onOpenUpdates, onOpenAdmin, onOpenSupport, onLogout, isChatPage, showDashboard, hasUnreadUpdates, ticketCount, profile }) => {
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [isChatMobileMenuOpen, setIsChatMobileMenuOpen] = useState(false);
    const [scrolled, setScrolled] = useState(false);
    const mobileMenuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (mobileMenuRef.current && !mobileMenuRef.current.contains(event.target as Node)) {
                setIsChatMobileMenuOpen(false);
            }
        };
        const handleScroll = () => {
            setScrolled(window.scrollY > 20);
        };

        document.addEventListener('mousedown', handleClickOutside);
        window.addEventListener('scroll', handleScroll);
        
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    const Brand = ({ lightMode }: { lightMode?: boolean }) => (
        <div className="flex items-center space-x-2 cursor-pointer" onClick={onGoHome ?? (() => window.location.reload())}>
            <ButterflyIcon className={`h-8 w-8 ${lightMode ? 'text-white' : 'text-[#4FFFB0]'}`} />
            <div>
                <h1 className={`text-xl font-bold font-['Outfit'] tracking-tight ${lightMode ? 'text-white' : 'text-white'}`}>Social Butterfly AI</h1>
            </div>
        </div>
    );

    const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
        e.preventDefault();
        setIsMobileMenuOpen(false);
        const element = document.getElementById(targetId);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    };

    const isFree = profile?.plan?.id === 'free';
    const isLowCredits = (profile?.credits ?? 0) < 50;

    // Landing page logic: Transparent at top, Black Glass on scroll
    // Chat page logic: Always Black Glass
    const isTransparent = !isChatPage && !scrolled;
    
    return (
        <header 
            className={`fixed w-full top-0 z-50 transition-all duration-300 border-b ${
                isTransparent 
                ? 'bg-transparent border-transparent py-4' 
                : 'bg-[#050505]/80 backdrop-blur-xl border-white/5 shadow-sm py-2'
            }`}
        >
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-12">
                     {isChatPage ? (
                        <div className="flex items-center space-x-2 overflow-hidden">
                             <button onClick={onToggleSidebar} className="p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white flex-shrink-0" aria-label="Toggle chat history">
                                <span className="material-icons">menu</span>
                            </button>
                            
                            {!showDashboard && (
                                <button onClick={onGoHome} className="p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white flex-shrink-0" aria-label="Back to Dashboard">
                                    <span className="material-icons">arrow_back</span>
                                </button>
                            )}

                            <div className="flex-shrink-0">
                                <Brand lightMode={false} />
                            </div>
                        </div>
                    ) : (
                        // Landing Page Brand
                         <div className="flex items-center justify-between w-full md:w-auto">
                             <Brand lightMode={isTransparent} />
                             <button 
                                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                                className={`md:hidden p-2 rounded-full ${isTransparent ? 'text-white hover:bg-white/10' : 'text-gray-400 hover:text-white hover:bg-white/10'}`}
                             >
                                <span className="material-icons">{isMobileMenuOpen ? 'close' : 'menu'}</span>
                             </button>
                         </div>
                    )}

                    {/* Desktop Nav (Landing Page) */}
                    {!isChatPage && (
                        <nav className="hidden md:flex items-center space-x-8">
                            <div className="flex space-x-8">
                                <a href="#features" onClick={(e) => handleScrollTo(e, 'features')} className={`text-sm font-medium transition-colors font-['Plus_Jakarta_Sans'] ${isTransparent ? 'text-white/80 hover:text-white' : 'text-gray-400 hover:text-[#4FFFB0]'}`}>Features</a>
                                <a href="#pricing" onClick={(e) => handleScrollTo(e, 'pricing')} className={`text-sm font-medium transition-colors font-['Plus_Jakarta_Sans'] ${isTransparent ? 'text-white/80 hover:text-white' : 'text-gray-400 hover:text-[#4FFFB0]'}`}>Pricing</a>
                            </div>
                            <div className="flex items-center space-x-4">
                                {onLogin && (
                                    <button
                                        onClick={onLogin}
                                        className={`px-4 py-2 text-sm font-medium transition-colors font-['Outfit'] uppercase tracking-wide ${isTransparent ? 'text-white hover:text-[#4FFFB0]' : 'text-white hover:text-[#4FFFB0]'}`}
                                    >
                                        Log In
                                    </button>
                                )}
                                <button
                                    onClick={onEnterApp}
                                    className={`px-6 py-2.5 text-sm font-bold rounded-full transition-all shadow-lg hover:shadow-[0_0_20px_rgba(79,255,176,0.4)] transform hover:-translate-y-0.5 font-['Outfit'] tracking-wide ${isTransparent ? 'bg-white text-black hover:bg-[#4FFFB0]' : 'bg-[#4FFFB0] text-black hover:bg-white'}`}
                                >
                                    Begin Transformation
                                </button>
                            </div>
                        </nav>
                    )}

                    {/* Chat Page Actions (Authenticated) */}
                    {isChatPage && (
                        <div className="flex items-center space-x-1 sm:space-x-2 flex-shrink-0 relative">
                             {/* Credits Display */}
                             <div className={`hidden sm:flex items-center space-x-2 rounded-full p-1 pr-3 mr-2 border ${isLowCredits ? 'bg-red-900/20 border-red-800' : 'bg-[#18181b] border-white/10'}`}>
                                <span className={`material-icons text-sm pl-1 ${isLowCredits ? 'text-red-500' : 'text-[#E0B069]'}`}>monetization_on</span>
                                <div className="flex flex-col leading-none justify-center">
                                    <span className={`font-semibold text-sm font-mono ${isLowCredits ? 'text-red-400 font-bold animate-pulse' : 'text-white'}`}>
                                        {profile?.credits?.toLocaleString() ?? 0}
                                    </span>
                                    {isFree && <span className="text-[9px] text-gray-500 uppercase font-bold tracking-wider -mt-0.5">Trial</span>}
                                </div>
                             </div>

                             {/* Desktop Only Buttons */}
                             <div className="hidden sm:flex items-center space-x-1">
                                 {onOpenAdmin && (
                                    <button onClick={onOpenAdmin} className="p-2 rounded-full hover:bg-white/10 text-[#4FFFB0] relative" title="Admin">
                                        <span className="material-icons">admin_panel_settings</span>
                                        {ticketCount !== undefined && ticketCount > 0 && <span className="absolute top-1 right-1 block h-2.5 w-2.5 rounded-full ring-2 ring-[#050505] bg-red-500"></span>}
                                    </button>
                                 )}
                                 {onOpenUpdates && (
                                    <button onClick={onOpenUpdates} className="p-2 rounded-full hover:bg-white/10 relative group" title="Updates">
                                        <span className="material-icons text-gray-400 group-hover:text-white">notifications_none</span>
                                        {hasUnreadUpdates && <span className="absolute top-2 right-2 h-2 w-2 bg-[#4FFFB0] rounded-full ring-2 ring-[#050505] animate-pulse"></span>}
                                    </button>
                                 )}
                                 {onOpenSupport && (
                                    <button onClick={onOpenSupport} className="p-2 rounded-full hover:bg-white/10" title="Support">
                                        <span className="material-icons text-gray-400 hover:text-white">support_agent</span>
                                    </button>
                                 )}
                                 {onOpenExport && (
                                    <button onClick={onOpenExport} className="p-2 rounded-full hover:bg-white/10" title="Export">
                                        <span className="material-icons text-gray-400 hover:text-white">ios_share</span>
                                    </button>
                                 )}
                                 <button onClick={onToggleTasks} className="p-2 rounded-full hover:bg-white/10" title="Tasks">
                                    <span className="material-icons text-gray-400 hover:text-white">checklist</span>
                                </button>
                             </div>

                             {/* Mobile More Button */}
                             <div className="sm:hidden flex items-center">
                                {onOpenExport && <button onClick={onOpenExport} className="p-2 rounded-full hover:bg-white/10"><span className="material-icons text-gray-400">ios_share</span></button>}
                                <button onClick={() => setIsChatMobileMenuOpen(!isChatMobileMenuOpen)} className="p-2 rounded-full hover:bg-white/10 relative">
                                    <span className="material-icons text-gray-400">more_vert</span>
                                    {hasUnreadUpdates && <span className="absolute top-2 right-2 h-2 w-2 bg-[#4FFFB0] rounded-full ring-2 ring-black animate-pulse"></span>}
                                </button>
                             </div>
                             
                             <button onClick={onOpenProfile} className="rounded-full hover:ring-2 hover:ring-[#4FFFB0]/50 ml-1 flex-shrink-0 border border-white/10">
                                {profile?.photo ? <img src={profile.photo} alt="Profile" className="h-9 w-9 rounded-full object-cover" /> : <div className="h-9 w-9 rounded-full bg-white/10 flex items-center justify-center"><span className="material-icons text-gray-400">person_outline</span></div>}
                            </button>

                            {onLogout && (
                                <button onClick={() => { if(window.confirm('Log out?')) onLogout(); }} className="hidden sm:flex p-2 rounded-full bg-red-900/20 text-red-500 hover:bg-red-900/40 ml-2 border border-red-900/30">
                                    <span className="material-icons">power_settings_new</span>
                                </button>
                            )}

                            {/* Mobile Chat Menu */}
                            {isChatMobileMenuOpen && (
                                <div ref={mobileMenuRef} className="absolute top-14 right-0 w-56 bg-[#18181b] shadow-2xl rounded-xl border border-white/10 p-2 flex flex-col space-y-1 z-50 animate-[fadeIn_0.1s_ease-out]">
                                    <div className={`flex items-center justify-between px-3 py-2 rounded-lg mb-1 ${isLowCredits ? 'bg-red-900/20' : 'bg-white/5'}`}>
                                        <div className="flex flex-col">
                                            <div className="flex items-center text-gray-400">
                                                <span className={`material-icons mr-2 text-sm ${isLowCredits ? 'text-red-500' : 'text-[#E0B069]'}`}>monetization_on</span>
                                                <span className="text-sm font-medium">Credits</span>
                                            </div>
                                        </div>
                                        <span className={`font-bold font-mono ${isLowCredits ? 'text-red-500' : 'text-white'}`}>{profile?.credits?.toLocaleString() ?? 0}</span>
                                    </div>
                                    <div className="h-px bg-white/5 my-1"></div>
                                    {onOpenUpdates && <button onClick={() => { onOpenUpdates(); setIsChatMobileMenuOpen(false); }} className="w-full text-left px-3 py-2 text-sm text-gray-300 hover:bg-white/10 hover:text-white rounded-lg flex justify-between"><span>Updates</span>{hasUnreadUpdates && <span className="h-2 w-2 bg-[#4FFFB0] rounded-full"></span>}</button>}
                                    {onOpenSupport && <button onClick={() => { onOpenSupport(); setIsChatMobileMenuOpen(false); }} className="w-full text-left px-3 py-2 text-sm text-gray-300 hover:bg-white/10 hover:text-white rounded-lg">Support</button>}
                                    {onToggleTasks && <button onClick={() => { onToggleTasks(); setIsChatMobileMenuOpen(false); }} className="w-full text-left px-3 py-2 text-sm text-gray-300 hover:bg-white/10 hover:text-white rounded-lg">My Tasks</button>}
                                    {onOpenAdmin && <button onClick={() => { onOpenAdmin(); setIsChatMobileMenuOpen(false); }} className="w-full text-left px-3 py-2 text-sm text-[#4FFFB0] hover:bg-[#4FFFB0]/10 rounded-lg font-medium">Admin Dashboard</button>}
                                    {onLogout && <button onClick={() => { onLogout(); setIsChatMobileMenuOpen(false); }} className="w-full text-left px-3 py-2 text-sm text-red-500 hover:bg-red-900/20 rounded-lg border-t border-white/5 mt-1">Log Out</button>}
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>

            {/* Mobile Menu Dropdown (Landing Page Only) */}
            {!isChatPage && isMobileMenuOpen && (
                <div className="md:hidden bg-[#050505] border-t border-white/10 absolute w-full left-0 shadow-2xl py-6 px-6 flex flex-col space-y-6 animate-[fadeIn_0.2s_ease-out] z-50">
                    <a href="#features" onClick={(e) => handleScrollTo(e, 'features')} className="text-gray-300 hover:text-[#4FFFB0] font-medium text-lg py-2 border-b border-white/5">Features</a>
                    <a href="#pricing" onClick={(e) => handleScrollTo(e, 'pricing')} className="text-gray-300 hover:text-[#4FFFB0] font-medium text-lg py-2 border-b border-white/5">Pricing</a>
                    <div className="flex flex-col space-y-4 pt-2">
                        {onLogin && (
                            <button
                                onClick={() => { onLogin(); setIsMobileMenuOpen(false); }}
                                className="w-full px-4 py-3 text-center font-bold text-white border border-white/20 rounded-lg hover:bg-white/10 transition-colors font-['Outfit'] uppercase tracking-wide"
                            >
                                Log In
                            </button>
                        )}
                        <button
                            onClick={() => { onEnterApp?.(); setIsMobileMenuOpen(false); }}
                            className="w-full px-4 py-3 text-center font-bold text-black bg-[#4FFFB0] rounded-lg hover:bg-[#3ddda0] transition-colors font-['Outfit'] uppercase tracking-wide shadow-lg"
                        >
                            Get Started
                        </button>
                    </div>
                </div>
            )}
        </header>
    );
};

export default Header;
