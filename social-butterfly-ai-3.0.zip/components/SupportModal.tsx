
import React, { useState } from 'react';
import { submitSupportTicket } from '../services/firebase';

interface SupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  userEmail: string;
}

const SupportModal: React.FC<SupportModalProps> = ({ isOpen, onClose, userId, userEmail }) => {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await submitSupportTicket({
        userId,
        userEmail,
        subject,
        message
      });
      setSuccess(true);
      setTimeout(() => {
        onClose();
        setSuccess(false);
        setSubject('');
        setMessage('');
      }, 2000);
    } catch (error) {
      console.error("Error submitting ticket", error);
      alert("Failed to send message. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center z-50 p-4 modal-backdrop" onClick={onClose}>
      <div className="bg-[#18181b] border border-white/10 rounded-2xl shadow-2xl w-full max-w-lg p-6 modal-content" onClick={e => e.stopPropagation()}>
        
        {success ? (
            <div className="text-center py-10">
                <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-900/20 border border-green-800">
                    <span className="material-icons text-3xl text-green-500">check</span>
                </div>
                <h3 className="mt-4 text-xl font-bold text-white">Message Sent!</h3>
                <p className="mt-2 text-gray-400">We've received your request and will get back to you shortly at <strong>{userEmail}</strong>.</p>
            </div>
        ) : (
            <>
                <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-white flex items-center font-['Outfit']">
                    <span className="material-icons text-[#4FFFB0] mr-2">support_agent</span>
                    Contact Support
                </h2>
                <button onClick={onClose} className="text-gray-500 hover:text-white">
                    <span className="material-icons">close</span>
                </button>
                </div>

                <p className="text-sm text-gray-400 mb-6">
                    Having trouble? Send us a message directly. We're here to help you build your business without technical roadblocks.
                </p>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-400 mb-1">Subject</label>
                        <select 
                            value={subject} 
                            onChange={(e) => setSubject(e.target.value)}
                            className="w-full p-2 bg-[#09090b] border border-white/10 rounded-md text-white focus:ring-1 focus:ring-[#4FFFB0] outline-none"
                            required
                        >
                            <option value="" disabled>Select a topic...</option>
                            <option value="Billing & Subscription">Billing & Subscription</option>
                            <option value="Technical Issue">Technical Issue</option>
                            <option value="Feature Request">Feature Request</option>
                            <option value="Feedback">General Feedback</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-400 mb-1">Message</label>
                        <textarea
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            placeholder="Describe your issue or question..."
                            className="w-full p-3 bg-[#09090b] border border-white/10 rounded-md h-32 resize-none focus:ring-1 focus:ring-[#4FFFB0] outline-none text-white placeholder-gray-600"
                            required
                        />
                    </div>

                    <div className="pt-2 flex justify-end space-x-3">
                        <button
                            type="button"
                            onClick={onClose}
                            className="px-4 py-2 text-gray-400 bg-white/5 rounded-md hover:bg-white/10 transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            disabled={isSubmitting}
                            className="px-6 py-2 text-black font-bold bg-[#4FFFB0] rounded-md hover:bg-[#3ddda0] transition-colors disabled:opacity-50 disabled:bg-gray-700 disabled:text-gray-500 flex items-center"
                        >
                            {isSubmitting ? 'Sending...' : 'Send Message'}
                        </button>
                    </div>
                </form>
            </>
        )}
      </div>
    </div>
  );
};

export default SupportModal;
