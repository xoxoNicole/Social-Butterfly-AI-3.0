
// src/aiConfig.ts

// --- THE BRAIN (Complex Logic, Coding, Strategy) ---
// Currently using Gemini 3 Pro Preview (Released Nov 2025)
export const MODEL_SMART = 'gemini-3-pro-preview';

// --- THE SPEEDSTER (Summaries, Titles, Simple Classifications) ---
// Flash is faster and cheaper.
export const MODEL_FAST = 'gemini-2.5-flash'; 

// --- THE ARTIST (Image Generation) ---
export const MODEL_IMAGE = 'gemini-2.5-flash-image';

// --- THE DIRECTOR (Video Generation) ---
export const MODEL_VIDEO = 'veo-3.1-fast-generate-preview';

