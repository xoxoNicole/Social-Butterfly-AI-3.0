
import React from 'react';

const galleryItems = [
    {
        title: "Fur Family",
        category: "Community Platform",
        image: "https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/Gallery%20Sample.FurFamily.png?alt=media&token=340a84d2-49b2-4dda-81c8-841e2301051f",
        description: "A pet adoption and community hub connecting families with furry friends."
    },
    {
        title: "Digital Runway",
        category: "E-Commerce Experience",
        image: "https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/GallerySample.DigitalRunway.png?alt=media&token=588bc09e-1717-488f-bbaf-c3d66abee95d",
        description: "High-end fashion marketplace with virtual try-on features."
    },
    {
        title: "Elite Roster",
        category: "SaaS Dashboard",
        image: "https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/GallerySample.EliteRoster.png?alt=media&token=71dff727-2282-49c9-a500-451c46c867dc",
        description: "Team management and analytics platform for professional organizations."
    },
    {
        title: "TheraMind",
        category: "Wellness App",
        image: "https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/GallerySample.TheraMind.png?alt=media&token=e80a0879-241f-4b01-8968-eb48c9036b52",
        description: "Mental health tracking and meditation resource hub."
    },
    {
        title: "TheraMind Analytics",
        category: "Admin Dashboard",
        image: "https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/GallerySample.TheraMind_2.png?alt=media&token=21b75360-cb8d-4551-81f7-a3b353c8af99",
        description: "Clinician view for tracking patient progress and engagement."
    },
    {
        title: "Hydro Flow",
        category: "Enterprise SaaS",
        image: "https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/GallerySample.HydroFlow.png?alt=media&token=82898dad-8446-4e23-b0c6-ca899204948d",
        description: "Real-time resource monitoring and analytics dashboard for utility infrastructure."
    },
    {
        title: "AI Academy",
        category: "EdTech Platform",
        image: "https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/GallerySample.AIAcademy.png?alt=media&token=bc49e4b8-d83b-4221-8352-fded9c59471a",
        description: "Comprehensive learning management system for AI education and certification."
    },
    {
        title: "Agent X",
        category: "Autonomous Agent Hub",
        image: "https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/GallerySample.AgentX.png?alt=media&token=41933db5-26d2-4dda-b9ff-68558784bbdb",
        description: "Centralized command center for deploying and managing autonomous AI agents."
    },
    {
        title: "DocuFlow AI",
        category: "Intelligent Document Automation",
        image: "https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/GallerySample.DocuFlow%20AI.png?alt=media&token=64db0d9f-8348-48f5-acee-2368be6f0ae7",
        description: "Automated document analysis and workflow orchestration platform for legal and finance sectors."
    },
    {
        title: "Reclaim The Streets",
        category: "Social Impact Hub",
        image: "https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/GallerySample.ReclaimTheStreets.png?alt=media&token=eaf19887-8590-49a2-8b10-e96e8ee47859",
        description: "Community organizing platform connecting activists with local events and resources."
    },
    {
        title: "Luxe Agent",
        category: "Real Estate CRM",
        image: "https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/GallerySample.LuxeAgent.png?alt=media&token=50f3de16-9fb3-40ca-9d53-c3aa489b0fa9",
        description: "High-end real estate portfolio manager and client relationship tool for luxury brokers."
    },
    {
        title: "Urban Decay",
        category: "Retail Analytics",
        image: "https://firebasestorage.googleapis.com/v0/b/social-butterfly-ai.firebasestorage.app/o/Gallery%20Sample.UrbanDecayDashboard.png?alt=media&token=5bb22a5a-68f2-4711-bf53-fd04b5da0c3a",
        description: "Sales performance and inventory management dashboard for high-street fashion."
    }
];

const LandingGallery: React.FC = () => {
    return (
        <section className="py-24 bg-[#09090b] text-white relative overflow-hidden font-sans border-t border-white/5">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                
                <div className="text-center mb-16">
                    <h2 className="text-sm font-bold text-[#4FFFB0] uppercase tracking-widest mb-3 font-['Outfit']">Limitless Creation</h2>
                    <h3 className="text-4xl md:text-5xl font-extrabold font-['Outfit'] text-white mb-6">
                        You Are the Architect. <br/>
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#4FFFB0] to-[#E0B069]">What Will You Build?</span>
                    </h3>
                    <p className="text-xl text-gray-400 font-normal leading-relaxed max-w-2xl mx-auto font-['Plus_Jakarta_Sans']">
                        From niche communities to enterprise dashboards, Social Butterfly AI helps you build it all. Here are just a few examples generated in our AI Powered Venture Incubator.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {galleryItems.map((item, index) => (
                        <div key={index} className="group relative rounded-2xl overflow-hidden border border-white/10 hover:border-[#4FFFB0]/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(79,255,176,0.15)] bg-[#121215] flex flex-col">
                            
                            {/* Image Container - Fixed 16:9 Aspect Ratio with Contain */}
                            <div className="aspect-video w-full bg-[#050505] relative overflow-hidden border-b border-white/5">
                                <img 
                                    src={item.image} 
                                    alt={item.title} 
                                    className="w-full h-full object-contain p-1 transition-transform duration-700 group-hover:scale-[1.02]"
                                />
                            </div>

                            {/* Content */}
                            <div className="p-6 flex-1 flex flex-col">
                                <div className="mb-3">
                                    <div className="inline-block px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-[#09090b] bg-[#4FFFB0] rounded-full shadow-lg">
                                        {item.category}
                                    </div>
                                </div>
                                <h4 className="text-xl font-bold text-white mb-2 font-['Outfit'] group-hover:text-[#4FFFB0] transition-colors">{item.title}</h4>
                                <p className="text-sm text-gray-400 font-['Plus_Jakarta_Sans'] leading-relaxed">
                                    {item.description}
                                </p>
                            </div>
                        </div>
                    ))}
                </div>

            </div>
        </section>
    );
};

export default LandingGallery;
