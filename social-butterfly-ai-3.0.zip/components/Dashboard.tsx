
import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';

export type DashboardAction = 
    | { type: 'send_message', payload: string }
    | { type: 'open_modal', payload: string }
    | { type: 'navigate', payload: string };

interface DashboardProps {
    onAction: (action: DashboardAction, featureTitle: string) => void;
    profile: UserProfile;
}

const STAGES = [
    { id: 1, label: 'Thought Bubble' },
    { id: 2, label: 'Market Logic' },
    { id: 3, label: 'Blueprint' },
    { id: 4, label: 'Build' },
    { id: 5, label: 'Launch Cloud' }
];

const GROUNDING_PHRASES = [
    "Let’s move your venture forward today.",
    "You’re right on time.",
    "Here’s the next step.",
    "I’ll help you focus on what matters next.",
    "One step at a time.",
    "Steady progress is the goal."
];

interface NextActionDef {
    title: string;
    prompt?: string;
    payload?: string;
    type?: string;
}

const NEXT_ACTIONS: Record<number, NextActionDef> = {
    1: { title: "Clarify your idea summary", prompt: "Help me clarify and summarize my initial business idea." },
    2: { title: "Review your Market Logic results", prompt: "Run a market validation check to see if this idea has legs." },
    3: { title: "Approve your Blueprint structure", prompt: "Let's outline the business architecture and revenue model." },
    4: { title: "Generate your first page in Vibe Architect", payload: "site_architect", type: "open_modal" },
    5: { title: "Deploy your build to Launch Cloud", prompt: "How do I deploy my MVP to a live URL?" }
};

const Dashboard: React.FC<DashboardProps> = ({ onAction, profile }) => {
    const [groundingLine, setGroundingLine] = useState('');
    const [showNudge, setShowNudge] = useState(false);
    const [showCompletionCue, setShowCompletionCue] = useState(false);
    
    // Simulate "Stuck Detection" - random chance on load for demo purposes
    // In production, compare Date.now() with profile.lastActivity
    useEffect(() => {
        setGroundingLine(GROUNDING_PHRASES[Math.floor(Math.random() * GROUNDING_PHRASES.length)]);
        
        // Mock Nudge: 30% chance to show if in early stages
        if (profile.stage < 4 && Math.random() > 0.7) {
            setShowNudge(true);
        }
    }, [profile.stage]);

    const currentStage = profile.stage || 1;
    const nextAction = NEXT_ACTIONS[currentStage as keyof typeof NEXT_ACTIONS] || NEXT_ACTIONS[1];

    const getGreeting = () => {
        if (profile.preferredName) return `Good to see you, ${profile.preferredName}.`;
        return "Welcome back, founder.";
    };

    const handleNextAction = () => {
        if (nextAction.type === 'open_modal') {
            onAction({ type: 'open_modal', payload: nextAction.payload || '' }, 'Next Action');
        } else {
            onAction({ type: 'send_message', payload: nextAction.prompt || '' }, 'Next Action');
        }
        setShowNudge(false); // Dismiss nudge if acted
    };

    const renderProgressHeader = () => (
        <div className="mb-8 w-full overflow-x-auto pb-2">
            <div className="flex items-center justify-between min-w-[600px] px-2">
                {STAGES.map((stage, index) => {
                    const isCompleted = stage.id < currentStage;
                    const isCurrent = stage.id === currentStage;
                    return (
                        <div key={stage.id} className="flex-1 flex flex-col items-center relative group">
                            {/* Connector Line */}
                            {index !== 0 && (
                                <div className={`absolute top-3 right-[50%] w-full h-[2px] -z-10 ${isCompleted || isCurrent ? 'bg-green-500/50' : 'bg-gray-800'}`} />
                            )}
                            
                            {/* Node */}
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center mb-2 border-2 transition-all duration-700
                                ${isCompleted ? 'bg-green-500 border-green-500' : 
                                  isCurrent ? 'bg-[#09090b] border-[#E0B069] shadow-[0_0_15px_rgba(224,176,105,0.4)]' : 
                                  'bg-[#09090b] border-gray-700'}`}>
                                {isCompleted && <span className="material-icons text-[10px] text-black font-bold">check</span>}
                                {isCurrent && <div className="w-2 h-2 rounded-full bg-[#E0B069] animate-pulse" />}
                            </div>
                            
                            {/* Label */}
                            <span className={`text-xs font-bold uppercase tracking-wider text-center ${
                                isCurrent ? 'text-[#E0B069]' : 
                                isCompleted ? 'text-green-500' : 
                                'text-gray-600'
                            }`}>
                                {stage.label}
                            </span>
                        </div>
                    );
                })}
            </div>
            
            {/* Stage Completion Cue (Micro-Moment) */}
            {showCompletionCue && (
                <div className="mt-4 mx-auto max-w-md bg-green-900/20 border border-green-500/30 text-green-400 text-xs font-bold px-4 py-2 rounded-full text-center animate-[fadeIn_0.5s_ease-out] flex items-center justify-center space-x-2">
                    <span className="material-icons text-sm">check_circle</span>
                    <span>Stage {currentStage - 1} Complete — You’re Making Real Progress.</span>
                    <button onClick={() => setShowCompletionCue(false)} className="ml-2 hover:text-white"><span className="material-icons text-xs">close</span></button>
                </div>
            )}
        </div>
    );

    return (
        <div className="w-full max-w-6xl mx-auto px-6 py-8 animate-[fadeIn_0.5s_ease-out] font-['Plus_Jakarta_Sans']">
            
            {/* Header Section */}
            <div className="mb-10">
                <h1 className="text-3xl font-bold font-['Outfit'] text-white mb-2">{getGreeting()}</h1>
                <p className="text-gray-400 font-medium text-lg">{groundingLine}</p>
            </div>

            {/* 1. Progress Header */}
            {renderProgressHeader()}

            {/* 2. Stuck Detection Nudge (Conditional) */}
            {showNudge && (
                <div className="mb-4 bg-[#18181b] border-l-2 border-[#E0B069] p-3 flex items-center justify-between rounded-r-lg animate-[slideInUp_0.3s_ease-out]">
                    <div className="flex items-center space-x-3">
                        <span className="material-icons text-[#E0B069] text-sm">lightbulb</span>
                        <p className="text-sm text-gray-300">You haven’t visited Stage {currentStage} for a bit. Want to validate one item today?</p>
                    </div>
                    <button onClick={() => setShowNudge(false)} className="text-gray-500 hover:text-white">
                        <span className="material-icons text-sm">close</span>
                    </button>
                </div>
            )}

            {/* 3. Next Best Action Widget */}
            <div className="w-full bg-[#18181b] border border-white/10 rounded-2xl p-6 mb-8 flex flex-col md:flex-row items-center justify-between shadow-lg relative overflow-hidden group">
                {/* Subtle Ambient Glow */}
                <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-l from-[#4FFFB0]/5 to-transparent opacity-50 pointer-events-none" />
                
                <div className="flex items-center space-x-4 relative z-10 w-full md:w-auto mb-4 md:mb-0">
                    <div className="w-12 h-12 rounded-xl bg-[#4FFFB0]/10 flex items-center justify-center border border-[#4FFFB0]/20 text-[#4FFFB0]">
                        <span className="material-icons">flag</span>
                    </div>
                    <div>
                        <h2 className="text-sm font-bold text-[#4FFFB0] uppercase tracking-widest mb-1">Next Best Action</h2>
                        <p className="text-white font-['Outfit'] text-lg md:text-xl font-semibold">{nextAction.title}</p>
                    </div>
                </div>
                
                <button 
                    onClick={handleNextAction}
                    className="relative z-10 px-8 py-3 bg-[#4FFFB0] text-black font-bold rounded-full hover:bg-white transition-all shadow-[0_0_20px_rgba(79,255,176,0.2)] transform hover:-translate-y-0.5 whitespace-nowrap w-full md:w-auto"
                >
                    Do This Next
                </button>
            </div>

            {/* 4. AI Co-Founder Panel (Moved Down) */}
            <div className="w-full bg-[#121215] border border-white/10 rounded-2xl p-5 mb-12 flex items-center justify-between hover:border-[#E0B069]/30 transition-colors cursor-pointer group"
                 onClick={() => onAction({ type: 'open_modal', payload: 'sanctuary' }, 'AI Co-Founder')}>
                <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 rounded-full bg-[#E0B069]/10 flex items-center justify-center border border-[#E0B069]/20 group-hover:bg-[#E0B069] group-hover:text-black text-[#E0B069] transition-all">
                        <span className="material-icons text-lg">graphic_eq</span>
                    </div>
                    <div>
                        <h3 className="text-base font-bold text-white font-['Outfit']">AI Co-Founder</h3>
                        <p className="text-xs text-gray-400">Think through decisions or get direction.</p>
                    </div>
                </div>
                <div className="flex items-center text-[#E0B069] text-xs font-bold uppercase tracking-wide group-hover:translate-x-1 transition-transform">
                    Start Voice Session <span className="material-icons ml-1 text-sm">mic</span>
                </div>
            </div>

            {/* SUITES GRID */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* 5. Strategy Suite */}
                <div className="space-y-4">
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest px-2">Strategy Suite</h3>
                    <div className="grid grid-cols-1 gap-3">
                        <SuiteCard title="Market Validation" desc="Check demand, competitors, and feasibility." icon="crisis_alert" onClick={() => onAction({ type: 'send_message', payload: "Run a Market Validation check on my idea." }, 'Market Validation')} />
                        <SuiteCard title="Audience Discovery" desc="Define who you’re building for." icon="groups" onClick={() => onAction({ type: 'send_message', payload: "Help me define my Target Audience." }, 'Audience Discovery')} />
                        <SuiteCard title="Product Suite Strategy" desc="Plan your offer and product lineup." icon="inventory_2" onClick={() => onAction({ type: 'send_message', payload: "Let's strategize my Product Suite." }, 'Product Strategy')} />
                        <SuiteCard title="Go-To-Market Plan" desc="Create a clear, actionable launch approach." icon="campaign" onClick={() => onAction({ type: 'open_modal', payload: 'gtm' }, 'GTM Plan')} />
                        <SuiteCard title="Customer Journey Mapping" desc="Clarify how users move from awareness to purchase." icon="map" onClick={() => onAction({ type: 'send_message', payload: "Help me map the Customer Journey." }, 'Journey Map')} />
                        <SuiteCard title="Content Pillars" desc="Build a content strategy aligned with your brand." icon="view_column" onClick={() => onAction({ type: 'send_message', payload: "Help me define Content Pillars." }, 'Content Pillars')} />
                        <SuiteCard title="Document Analysis" desc="Upload documents for instant insight." icon="description" onClick={() => onAction({ type: 'open_modal', payload: 'document_analysis' }, 'Doc Analysis')} />
                    </div>
                </div>

                {/* 6. Build & Creative Suites */}
                <div className="space-y-8">
                    
                    {/* Build Suite */}
                    <div className="space-y-4">
                        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest px-2">Build Suite</h3>
                        
                        {/* Primary Vibe Architect Card */}
                        <div onClick={() => onAction({ type: 'open_modal', payload: 'site_architect' }, 'Vibe Architect')}
                             className="bg-[#4FFFB0]/10 border border-[#4FFFB0]/20 rounded-2xl p-5 cursor-pointer hover:bg-[#4FFFB0]/20 transition-all group relative overflow-hidden">
                            <div className="flex items-center space-x-3 mb-2">
                                <span className="material-icons text-[#4FFFB0] text-2xl">architecture</span>
                                <h4 className="text-lg font-bold text-white font-['Outfit']">Vibe Architect</h4>
                            </div>
                            <p className="text-xs text-gray-300">Create your product using natural language. Full-stack generation.</p>
                            <div className="mt-3 flex items-center text-[#4FFFB0] text-[10px] font-bold uppercase tracking-wider">
                                Open Builder <span className="material-icons ml-1 text-xs group-hover:translate-x-1 transition-transform">arrow_forward</span>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                            <MiniCard title="Landing Page" icon="web" onClick={() => onAction({ type: 'open_modal', payload: 'site_architect' }, 'Landing Page')} />
                            <MiniCard title="Dashboard" icon="dashboard" onClick={() => onAction({ type: 'open_modal', payload: 'site_architect' }, 'Dashboard')} />
                            <MiniCard title="App Gen" icon="smartphone" onClick={() => onAction({ type: 'open_modal', payload: 'site_architect' }, 'App Gen')} />
                            <MiniCard title="Deployment" icon="rocket" onClick={() => onAction({ type: 'send_message', payload: "How do I deploy my code?" }, 'Deployment')} />
                        </div>
                    </div>

                    {/* Creative Suite */}
                    <div className="space-y-4">
                        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest px-2">Creative Suite</h3>
                        <div className="grid grid-cols-2 gap-3">
                            <MiniCard title="Image Gen" icon="image" onClick={() => onAction({ type: 'open_modal', payload: 'image_generation' }, 'Image Gen')} />
                            <MiniCard title="Video Creation" icon="movie" onClick={() => onAction({ type: 'open_modal', payload: 'video_text' }, 'Video Creation')} />
                            <MiniCard title="Animate Image" icon="animation" onClick={() => onAction({ type: 'open_modal', payload: 'video_text' }, 'Animate Image')} />
                            <MiniCard title="Extract Reels" icon="content_cut" onClick={() => onAction({ type: 'open_modal', payload: 'video_analysis' }, 'Extract Reels')} />
                            <MiniCard title="Edit Image" icon="edit" onClick={() => onAction({ type: 'open_modal', payload: 'image_editing' }, 'Edit Image')} />
                        </div>
                    </div>
                </div>

                {/* 7. Clarity Hub & 8. Brains Suite (Bottom Full Width) */}
                <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 border-t border-white/5">
                    <div>
                        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest px-2 mb-3">The Clarity Hub</h3>
                        <div className="space-y-2">
                            <SuiteCard title="Clear Your Mind" desc="Reset, focus, and improve decision-making." icon="spa" onClick={() => onAction({ type: 'open_modal', payload: 'sanctuary' }, 'Clarity')} />
                            <SuiteCard title="Your Wins" desc="Save and revisit your progress." icon="emoji_events" onClick={() => onAction({ type: 'send_message', payload: "Let's review my recent wins." }, 'Wins')} />
                            <SuiteCard title="Conversation Practice" desc="Rehearse important conversations." icon="record_voice_over" onClick={() => onAction({ type: 'open_modal', payload: 'sanctuary' }, 'Practice')} />
                        </div>
                    </div>

                    <div>
                        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest px-2 mb-3">Brains Suite</h3>
                        <div className="grid grid-cols-2 gap-2">
                            <BrainCard title="Think Like a VC" onClick={() => onAction({ type: 'send_message', payload: "Analyze this decision like a Venture Capitalist." }, 'VC Brain')} />
                            <BrainCard title="Think Like a CEO" onClick={() => onAction({ type: 'send_message', payload: "Give me the CEO perspective on this." }, 'CEO Brain')} />
                            <BrainCard title="Like a Strategist" onClick={() => onAction({ type: 'send_message', payload: "What is the strategic move here?" }, 'Strategist Brain')} />
                            <BrainCard title="Like an Engineer" onClick={() => onAction({ type: 'send_message', payload: "Break this down into logical systems." }, 'Engineer Brain')} />
                            <BrainCard title="Like a Philosopher" onClick={() => onAction({ type: 'send_message', payload: "Shift into big-picture thinking." }, 'Philosopher Brain')} />
                            <BrainCard title="Like an Attorney" onClick={() => onAction({ type: 'send_message', payload: "View challenges through a risk-management frame." }, 'Attorney Brain')} />
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
};

// --- Sub-components ---

const SuiteCard = ({ title, desc, icon, onClick }: { title: string, desc: string, icon: string, onClick: () => void }) => (
    <div onClick={onClick} className="bg-[#18181b] border border-white/5 hover:border-white/20 rounded-xl p-3 cursor-pointer transition-all flex items-start space-x-3 hover:bg-white/5 group">
        <div className="p-2 bg-white/5 rounded-lg text-gray-400 group-hover:text-white transition-colors">
            <span className="material-icons text-sm">{icon}</span>
        </div>
        <div>
            <h4 className="font-bold text-white text-sm">{title}</h4>
            <p className="text-xs text-gray-500 mt-0.5">{desc}</p>
        </div>
    </div>
);

const MiniCard = ({ title, icon, onClick }: { title: string, icon: string, onClick: () => void }) => (
    <div onClick={onClick} className="bg-[#18181b] border border-white/5 hover:border-white/20 rounded-xl p-3 cursor-pointer transition-all flex flex-col items-center text-center hover:bg-white/5 space-y-1.5 group">
        <span className="material-icons text-gray-400 group-hover:text-white text-lg">{icon}</span>
        <span className="font-bold text-gray-300 text-xs">{title}</span>
    </div>
);

const BrainCard = ({ title, onClick }: { title: string, onClick: () => void }) => (
    <div onClick={onClick} className="border border-[#E0B069]/20 hover:bg-[#E0B069]/5 rounded-lg p-2.5 cursor-pointer transition-all text-center hover:border-[#E0B069]/40">
        <span className="text-[#E0B069] font-bold text-[10px] uppercase tracking-wide">{title}</span>
    </div>
);

export default Dashboard;
