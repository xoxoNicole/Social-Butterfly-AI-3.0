
import React from 'react';
import Header from './Header';
import LandingHero from './LandingHero';
import LandingMilestones from './LandingMilestones';
import LandingFeatures from './LandingFeatures';
import LandingGallery from './LandingGallery';
import LandingComparison from './LandingComparison';
import LandingInclusivity from './LandingInclusivity';
import LandingTestimonials from './LandingTestimonials';
import LandingPricing from './LandingPricing';
import Footer from './Footer';

interface LandingPageProps {
  onEnterApp: () => void;
  onLogin: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onEnterApp, onLogin }) => {
  return (
    <div className="bg-[#030014] text-white min-h-screen flex flex-col">
      <Header onEnterApp={onEnterApp} onLogin={onLogin} />
      
      {/* Full Screen Hero - NOW CONNECTED */}
      <LandingHero onEnterApp={onEnterApp} />

      <main className="flex-1">
        <div className="relative z-20 bg-[#09090b] text-white overflow-hidden border-t border-white/5">
            <LandingMilestones />
            <LandingFeatures />
            <LandingGallery />
            <LandingComparison />
            <LandingInclusivity />
            <LandingTestimonials />
            <LandingPricing onEnterApp={onEnterApp} />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default LandingPage;
