
import React, { useState } from 'react';

interface OnboardingQuestionnaireProps {
  isOpen: boolean;
  onComplete: (answers: Record<string, string>) => void;
}

const questions = [
  {
    key: 'audience',
    title: "Who is your ideal customer?",
    placeholder: "e.g., Faith-led female coaches in their first 1-2 years of business who feel overwhelmed by marketing.",
    icon: 'group'
  },
  {
    key: 'problem',
    title: "What's the single biggest problem you solve for them?",
    placeholder: "e.g., They struggle to create a clear, effective marketing strategy that feels authentic to their calling.",
    icon: 'crisis_alert'
  },
  {
    key: 'transformation',
    title: "What is the transformation you promise?",
    placeholder: "e.g., From feeling lost and inconsistent to launching and scaling a profitable business with confidence and spiritual integrity.",
    icon: 'auto_awesome'
  },
  {
    key: 'motivation',
    title: "What is your personal motivation for this venture?",
    placeholder: "e.g., I feel called to help other women build businesses that honor God and create financial freedom.",
    icon: 'favorite_border'
  },
  {
    key: 'fear',
    title: "What is your biggest fear or uncertainty right now?",
    placeholder: "e.g., I'm afraid no one will buy my offer, or that I'm not 'expert' enough to succeed.",
    icon: 'psychology'
  }
];

const OnboardingQuestionnaire: React.FC<OnboardingQuestionnaireProps> = ({ isOpen, onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});

  const handleAnswerChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setAnswers(prev => ({ ...prev, [name]: value }));
  };

  const handleNext = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete(answers);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleIdkClick = () => {
    const key = questions[currentStep].key;
    setAnswers(prev => ({
      ...prev,
      [key]: "I'm not sure about this yet. I would like your help to figure it out."
    }));
  };

  if (!isOpen) return null;

  const currentQuestion = questions[currentStep];
  const progressPercentage = ((currentStep + 1) / questions.length) * 100;

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center z-50 p-4 modal-backdrop">
      <div className="bg-[#18181b] rounded-2xl shadow-2xl border border-white/10 w-full max-w-2xl p-6 md:p-8 modal-content flex flex-col text-center max-h-[90vh] overflow-y-auto">
        <div className="w-full bg-white/10 rounded-full h-2 mb-6 flex-shrink-0">
            <div className="bg-[#4FFFB0] h-2 rounded-full" style={{ width: `${progressPercentage}%`, transition: 'width 0.5s ease-in-out' }}></div>
        </div>

        <div className="flex items-center justify-center h-12 w-12 md:h-16 md:w-16 rounded-full bg-[#4FFFB0]/10 text-[#4FFFB0] border border-[#4FFFB0]/30 mx-auto flex-shrink-0">
            <span className="material-icons text-3xl md:text-4xl">{currentQuestion.icon}</span>
        </div>
        
        <h2 className="mt-4 md:mt-6 text-xl md:text-2xl font-bold text-white font-['Outfit']">{currentQuestion.title}</h2>
        <p className="mt-2 text-gray-400 text-sm md:text-base">Your answers will help me provide hyper-personalized strategies for you.</p>

        <div className="mt-6 w-full flex-1 flex flex-col">
            <textarea
                name={currentQuestion.key}
                value={answers[currentQuestion.key] || ''}
                onChange={handleAnswerChange}
                placeholder={currentQuestion.placeholder}
                className="w-full p-3 bg-[#09090b] border border-white/10 rounded-md focus:ring-1 focus:ring-[#4FFFB0] focus:border-[#4FFFB0] min-h-[120px] text-center resize-y text-white placeholder-gray-600 outline-none"
                rows={4}
            />
            <button type="button" onClick={handleIdkClick} className="mt-4 text-sm text-[#4FFFB0] hover:text-[#3ddda0] hover:underline focus:outline-none self-center transition-colors">
                I'm not sure, can you help with this?
            </button>
        </div>

        <div className="mt-6 md:mt-8 grid grid-cols-2 gap-4 flex-shrink-0">
            <button
                onClick={handleBack}
                disabled={currentStep === 0}
                className="px-6 py-3 font-medium rounded-md transition-colors disabled:opacity-30 disabled:cursor-not-allowed bg-white/5 text-gray-300 hover:bg-white/10"
            >
                Back
            </button>
            <button
                onClick={handleNext}
                className="px-6 py-3 font-bold text-black bg-[#4FFFB0] rounded-md hover:bg-[#3ddda0] transition-colors shadow-lg hover:shadow-[#4FFFB0]/20"
            >
                {currentStep === questions.length - 1 ? 'Finish' : 'Next'}
            </button>
        </div>
      </div>
    </div>
  );
};

export default OnboardingQuestionnaire;
