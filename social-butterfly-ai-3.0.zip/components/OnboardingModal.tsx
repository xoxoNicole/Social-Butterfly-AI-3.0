
import React, { useState } from 'react';
import { UserProfile } from '../services/firebase';

interface OnboardingModalProps {
  onFinish: (data: Partial<UserProfile>) => void;
  initialName?: string;
}

const OnboardingModal: React.FC<OnboardingModalProps> = ({ onFinish, initialName }) => {
  const [step, setStep] = useState(1);
  const [preferredName, setPreferredName] = useState(initialName || '');
  const [ideaSummary, setIdeaSummary] = useState('');
  
  // Step 1: Name
  const handleNameSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!preferredName.trim()) return;
      setStep(2);
  };

  // Step 2: Idea
  const handleIdeaSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      setStep(3); // Go to Summary/Confirm
  };

  // Step 3 is just visual confirmation/transition
  const handleFinish = () => {
      onFinish({
          preferredName,
          ideaSummary: ideaSummary || "Exploration Phase",
          stage: 1 // Always start at Thought Bubble
      });
  };

  return (
    <div className="fixed inset-0 bg-[#050505] z-[200] flex items-center justify-center p-6 animate-fadeIn">
      <div className="w-full max-w-lg">
        
        {/* PROGRESS DOTS */}
        <div className="flex justify-center space-x-2 mb-10">
            {[1, 2, 3].map(i => (
                <div key={i} className={`w-2 h-2 rounded-full transition-colors ${step >= i ? 'bg-[#4FFFB0]' : 'bg-white/10'}`} />
            ))}
        </div>

        {/* STEP 1: NAME */}
        {step === 1 && (
            <div className="animate-slideInUp">
                <h1 className="text-4xl font-bold text-white mb-4 font-['Outfit']">Before we begin...</h1>
                <p className="text-xl text-gray-400 mb-8 font-['Plus_Jakarta_Sans']">What should I call you?</p>
                <form onSubmit={handleNameSubmit}>
                    <input 
                        type="text" 
                        value={preferredName}
                        onChange={(e) => setPreferredName(e.target.value)}
                        placeholder="Your Name"
                        className="w-full bg-transparent border-b-2 border-white/20 text-3xl text-white py-2 focus:border-[#4FFFB0] outline-none placeholder-gray-600 font-['Outfit']"
                        autoFocus
                    />
                    <div className="mt-8 flex justify-end">
                        <button 
                            type="submit" 
                            disabled={!preferredName.trim()}
                            className="bg-[#4FFFB0] text-black font-bold px-8 py-3 rounded-full hover:bg-white transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            Next
                        </button>
                    </div>
                </form>
                <button onClick={() => { setPreferredName(initialName || 'Founder'); setStep(2); }} className="mt-4 text-sm text-gray-500 hover:text-white">Skip</button>
            </div>
        )}

        {/* STEP 2: IDEA */}
        {step === 2 && (
            <div className="animate-slideInUp">
                <h1 className="text-4xl font-bold text-white mb-4 font-['Outfit']">What are you building?</h1>
                <p className="text-xl text-gray-400 mb-8 font-['Plus_Jakarta_Sans']">You can type it, or just say "I'm exploring."</p>
                <form onSubmit={handleIdeaSubmit}>
                    <textarea 
                        value={ideaSummary}
                        onChange={(e) => setIdeaSummary(e.target.value)}
                        placeholder="e.g. A marketplace for vintage cameras..."
                        className="w-full bg-[#121215] border border-white/10 rounded-xl p-4 text-lg text-white focus:border-[#4FFFB0] outline-none placeholder-gray-600 resize-none h-32"
                        autoFocus
                    />
                    <div className="mt-8 flex justify-between items-center">
                        <button type="button" onClick={() => setStep(1)} className="text-gray-400 hover:text-white">Back</button>
                        <button 
                            type="submit" 
                            className="bg-[#4FFFB0] text-black font-bold px-8 py-3 rounded-full hover:bg-white transition-all"
                        >
                            Continue
                        </button>
                    </div>
                </form>
                <button onClick={() => { setIdeaSummary("Exploration Phase"); setStep(3); }} className="mt-4 text-sm text-gray-500 hover:text-white">Skip for now</button>
            </div>
        )}

        {/* STEP 3: CONFIRM & ENTER */}
        {step === 3 && (
            <div className="animate-slideInUp text-center">
                <div className="w-20 h-20 bg-[#4FFFB0]/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-[#4FFFB0]/20">
                    <span className="material-icons text-[#4FFFB0] text-4xl">check</span>
                </div>
                <h1 className="text-3xl font-bold text-white mb-2 font-['Outfit']">Got it, {preferredName}.</h1>
                <p className="text-gray-400 mb-8 max-w-xs mx-auto">
                    "{ideaSummary || "Exploration"}" <br/>
                    <span className="text-[#4FFFB0] mt-2 block font-bold">Ready to validate it?</span>
                </p>
                
                <button 
                    onClick={handleFinish}
                    className="bg-[#4FFFB0] text-black font-bold px-10 py-4 rounded-full hover:bg-white transition-all shadow-[0_0_30px_rgba(79,255,176,0.3)] transform hover:scale-105"
                >
                    Enter Dashboard
                </button>
            </div>
        )}

      </div>
    </div>
  );
};

export default OnboardingModal;
