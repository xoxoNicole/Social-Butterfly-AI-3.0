
import React from 'react';
import { testimonials } from '../testimonials';

const QuoteIcon = () => (
    <svg className="w-10 h-10 text-[#4FFFB0]" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 18 14">
        <path d="M6 0H2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4v1a3 3 0 0 1-3 3H2a1 1 0 0 0 0 2h1a5.006 5.006 0 0 0 5-5V2a2 2 0 0 0-2-2Zm10 0h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4v1a3 3 0 0 1-3 3h-1a1 1 0 0 0 0 2h1a5.006 5.006 0 0 0 5-5V2a2 2 0 0 0-2-2Z"/>
    </svg>
);


const LandingTestimonials: React.FC = () => {
  return (
    <section id="testimonials" className="py-20 bg-white scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl font-['Outfit']">
            Trusted by Visionary Entrepreneurs
          </h2>
          <p className="mt-4 text-lg text-gray-600">
            Hear how Social Butterfly-AI has helped others build with clarity and confidence.
          </p>
        </div>
        <div className="mt-16 flex flex-wrap justify-center gap-12">
          {testimonials.map((testimonial) => (
            <div key={testimonial.name} className="flex flex-col text-center max-w-2xl group">
              <div className="relative">
                <div className="opacity-80">
                    <QuoteIcon />
                </div>
                <blockquote className="mt-4">
                  <p className="text-lg font-medium text-gray-700 italic leading-relaxed whitespace-pre-line">
                    "{testimonial.quote}"
                  </p>
                </blockquote>
              </div>
              <footer className="mt-8">
                <div className="flex flex-col items-center">
                  {/* Replaced Robot Image with Branded Icon */}
                  <div className="h-16 w-16 rounded-full bg-[#09090b] flex items-center justify-center border-2 border-[#4FFFB0] shadow-lg shadow-[#4FFFB0]/20 transform group-hover:scale-110 transition-transform duration-300">
                      <span className="material-icons text-[#4FFFB0] text-3xl">person</span>
                  </div>
                  <div className="mt-3 text-center">
                    <p className="text-base font-bold text-gray-900 font-['Outfit']">{testimonial.name}</p>
                    <p className="text-sm font-medium text-[#E0B069] uppercase tracking-wide">{testimonial.title}</p>
                  </div>
                </div>
              </footer>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LandingTestimonials;
