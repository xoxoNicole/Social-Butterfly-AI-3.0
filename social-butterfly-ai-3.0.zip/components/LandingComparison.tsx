
import React from 'react';

const LandingComparison: React.FC = () => {
  return (
    <section className="py-24 bg-[#09090b] text-white relative overflow-hidden font-sans">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-[#4FFFB0]/10 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-[#4FFFB0] uppercase tracking-widest mb-3 font-['Outfit']">The Moat</h2>
          <h3 className="text-4xl md:text-5xl font-extrabold font-['Outfit'] text-white mb-6">Code is Cheap. Clarity is Priceless.</h3>
          <p className="text-xl text-gray-400 font-normal leading-relaxed max-w-3xl mx-auto font-['Plus_Jakarta_Sans']">
            Raw AI builders like Bolt and Lovable are powerful engines. But an engine without a steering wheel crashes. Social Butterfly AI is the only platform that gives you both. Before the Vibe Architect writes a single line of code, Social Butterfly validates the market, defines your features, and architects the product for success.
          </p>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mt-12 text-left">
            {/* The Others */}
            <div className="p-8 rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm relative overflow-hidden group">
                <div className="absolute top-0 left-0 w-1 h-full bg-gray-600"></div>
                <h4 className="text-xl font-bold text-gray-300 mb-2 flex items-center font-['Outfit']">
                    <span className="material-icons mr-2 text-gray-500">code_off</span>
                    The Others (Code Generators)
                </h4>
                <p className="text-gray-400 leading-relaxed italic font-serif">
                    "They give you a code editor. If you build the wrong product, that's your fault."
                </p>
            </div>

            {/* Social Butterfly */}
            <div className="p-8 rounded-2xl border border-[#4FFFB0]/30 bg-[#4FFFB0]/5 backdrop-blur-sm relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-[#4FFFB0]"></div>
                <h4 className="text-xl font-bold text-white mb-2 flex items-center font-['Outfit']">
                    <span className="material-icons mr-2 text-[#4FFFB0]">psychology</span>
                    Social Butterfly (The Founder Incubator)
                </h4>
                <p className="text-[#e0ffef] leading-relaxed italic font-serif">
                    "We give you a Co-Founder. We validate the market before you build, define the features that actually sell, and then generate the code to launch it."
                </p>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto mt-16 rounded-2xl border border-white/10">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-white/5">
                <th className="py-5 px-6 text-sm font-bold text-gray-400 uppercase tracking-wider w-1/4 font-['Outfit'] border-b border-white/10">Core Difference</th>
                <th className="py-5 px-6 text-sm font-bold text-gray-400 uppercase tracking-wider w-1/3 font-['Outfit'] border-b border-white/10">Raw Code Generators (Bolt, Lovable)</th>
                <th className="py-5 px-6 text-sm font-bold text-[#4FFFB0] uppercase tracking-wider w-1/3 font-['Outfit'] border-b border-white/10 bg-[#4FFFB0]/10">Social Butterfly AI (The Incubator)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-['Plus_Jakarta_Sans']">
              <tr>
                <td className="py-6 px-6 font-bold text-white">The Philosophy</td>
                <td className="py-6 px-6 text-gray-400 italic">"Here is a code editor. Good luck."</td>
                <td className="py-6 px-6 text-white font-medium bg-[#4FFFB0]/5 border-l border-[#4FFFB0]/10 italic">"Here is a Co-Founder. Let's build."</td>
              </tr>
              <tr>
                <td className="py-6 px-6 font-bold text-white">The Starting Point</td>
                <td className="py-6 px-6 text-gray-400">You need a detailed technical spec.</td>
                <td className="py-6 px-6 text-white font-medium bg-[#4FFFB0]/5 border-l border-[#4FFFB0]/10">You just need a rough idea.</td>
              </tr>
              <tr>
                <td className="py-6 px-6 font-bold text-white">The "Silent Killer"</td>
                <td className="py-6 px-6 text-gray-400">They will build a bad idea perfectly.</td>
                <td className="py-6 px-6 text-white font-bold bg-[#4FFFB0]/5 border-l border-[#4FFFB0]/10">We validate the idea <strong>before</strong> you build it.</td>
              </tr>
              <tr>
                <td className="py-6 px-6 font-bold text-white">The Intelligence</td>
                <td className="py-6 px-6 text-gray-400">Understands Syntax & React.</td>
                <td className="py-6 px-6 text-white font-medium bg-[#4FFFB0]/5 border-l border-[#4FFFB0]/10">Understands Business Logic & Profit.</td>
              </tr>
              <tr>
                <td className="py-6 px-6 font-bold text-white">The Deliverable</td>
                <td className="py-6 px-6 text-gray-400">A GitHub Repository you have to manage.</td>
                <td className="py-6 px-6 text-white font-bold bg-[#4FFFB0]/5 border-l border-[#4FFFB0]/10">A Deployed <strong>Business</strong> ready for customers.</td>
              </tr>
              <tr>
                <td className="py-6 px-6 font-bold text-white">Who wins here?</td>
                <td className="py-6 px-6 text-gray-400">Developers who want speed.</td>
                <td className="py-6 px-6 text-[#4FFFB0] font-bold bg-[#4FFFB0]/5 border-l border-[#4FFFB0]/10 text-lg">Founders who want revenue.</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default LandingComparison;
