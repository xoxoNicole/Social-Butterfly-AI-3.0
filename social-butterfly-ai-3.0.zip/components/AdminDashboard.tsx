
import React, { useState, useEffect } from 'react';
import { subscribeToSupportTickets, updateTicketStatus, SupportTicket, subscribeToAllUsers, updateUserProfile, UserProfile, provisionUserProfile, subscribeToGlobalSettings, updateGlobalSettings, GlobalSettings, uploadImageToStorage, StoredAsset } from '../services/firebase';
import { getPlanDetails, individualPlans, teamPlans, PlanID, freePlan } from '../plans';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  currentUserProfile?: UserProfile;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ isOpen, onClose, currentUserProfile }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'emailer' | 'inbox' | 'users' | 'cms'>('overview');
  
  // Email State
  const [emailTo, setEmailTo] = useState('');
  const [emailSubject, setEmailSubject] = useState('');
  const [emailBody, setEmailBody] = useState('');
  
  // Support Inbox State
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  
  // User Manager State
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [userPermissionError, setUserPermissionError] = useState<boolean>(false);
  
  // CMS / Branding State
  const [settings, setSettings] = useState<GlobalSettings | null>(null);
  const [brandMsg, setBrandMsg] = useState<{type: 'success'|'error', text: string}|null>(null);
  const [uploadingImage, setUploadingImage] = useState<boolean>(false);
  const [newAssetName, setNewAssetName] = useState('');
  
  // Editing States
  const [editCreditId, setEditCreditId] = useState<string | null>(null);
  const [tempCredits, setTempCredits] = useState<number>(0);
  
  const [editPlanId, setEditPlanId] = useState<string | null>(null);
  const [tempPlanId, setTempPlanId] = useState<PlanID>('plus');

  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Provisioning (Add User) State
  const [isProvisioning, setIsProvisioning] = useState(false);
  const [newUserUid, setNewUserUid] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserName, setNewUserName] = useState('');
  const [newUserCredits, setNewUserCredits] = useState(100);
  const [newUserRole, setNewUserRole] = useState<'user' | 'admin'>('user');
  const [provisionMsg, setProvisionMsg] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
      if (isOpen) {
          const unsubscribeTickets = subscribeToSupportTickets((data) => {
              setTickets(data);
          });
          const unsubscribeSettings = subscribeToGlobalSettings((data) => {
              setSettings(data);
          });
          return () => {
              unsubscribeTickets();
              unsubscribeSettings();
          };
      }
  }, [isOpen]);

  // Real-time User Subscription
  useEffect(() => {
      if (activeTab === 'users') {
          setLoadingUsers(true);
          setUserPermissionError(false);
          
          const unsubscribe = subscribeToAllUsers((data) => {
              // Client-side sort by email for better readability
              const sortedData = [...data].sort((a, b) => (a.email || '').localeCompare(b.email || ''));
              setUsers(sortedData);
              setLoadingUsers(false);
              setUserPermissionError(false);
          }, (error) => {
              setLoadingUsers(false);
              console.error("Admin User List Error:", error);
              // Determine if it's a permission error
              const msg = error.message || error.toString();
              if (msg.includes("permission-denied") || msg.includes("Missing or insufficient permissions")) {
                  setUserPermissionError(true);
              }
          });
          return () => unsubscribe();
      }
  }, [activeTab, refreshTrigger]); 

  if (!isOpen) return null;

  const handleOpenMailClient = (e: React.FormEvent) => {
      e.preventDefault();
      const body = emailBody.replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, ''); 
      const mailtoLink = `mailto:${emailTo}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(body)}`;
      window.open(mailtoLink, '_blank');
  };

  const handleOpenGmail = () => {
      const body = emailBody.replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, ''); 
      const gmailLink = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(emailTo)}&su=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(body)}`;
      window.open(gmailLink, '_blank');
  };

  const handleReplyToTicket = (ticket: SupportTicket) => {
      setEmailTo(ticket.userEmail);
      setEmailSubject(`Re: ${ticket.subject}`);
      setEmailBody(`Hi there,\n\nRegarding your message:\n"${ticket.message}"\n\n`);
      setActiveTab('emailer');
  };

  const handleResolveTicket = async (id: string) => {
      await updateTicketStatus(id, 'resolved');
      if (selectedTicket?.id === id) {
          setSelectedTicket(prev => prev ? { ...prev, status: 'resolved' } : null);
      }
  };

  // --- Credit Editing ---
  const startEditingCredits = (user: UserProfile) => {
      setEditCreditId(user.uid);
      setTempCredits(user.credits);
      setEditPlanId(null); // Close other edits
  };

  const saveCredits = async (uid: string) => {
      await updateUserProfile(uid, { credits: tempCredits });
      setEditCreditId(null);
      setRefreshTrigger(prev => prev + 1);
  };

  // --- Plan Editing ---
  const startEditingPlan = (user: UserProfile) => {
      setEditPlanId(user.uid);
      setTempPlanId(user.plan?.id || 'plus');
      setEditCreditId(null); // Close other edits
  };

  const savePlan = async (uid: string) => {
      const planDetails = getPlanDetails(tempPlanId);
      if (planDetails) {
          if (window.confirm(`Switching to ${planDetails.name} will reset credits to ${planDetails.credits}. Proceed?`)) {
              await updateUserProfile(uid, { 
                  plan: { id: tempPlanId, billing: 'monthly' }, // Defaulting to monthly for admin overrides
                  credits: planDetails.credits 
              });
              setEditPlanId(null);
              setRefreshTrigger(prev => prev + 1);
          }
      }
  };

  const handleProvisionUser = async (e: React.FormEvent) => {
      e.preventDefault();
      setProvisionMsg(null);

      if(!newUserUid || !newUserEmail) {
          setProvisionMsg({ type: 'error', text: "UID and Email are required." });
          return;
      }
      
      const uid = newUserUid.trim();
      const email = newUserEmail.trim();

      try {
          await provisionUserProfile(uid, {
              email: email,
              name: newUserName || email.split('@')[0],
              credits: newUserCredits,
              role: newUserRole,
              business: '',
              photo: '',
              plan: { id: 'free', billing: 'monthly' }
          });
          setProvisionMsg({ type: 'success', text: "Success! User profile updated." });
          setRefreshTrigger(prev => prev + 1);
          
          setTimeout(() => {
             setIsProvisioning(false);
             setProvisionMsg(null);
             setNewUserUid('');
             setNewUserEmail('');
             setNewUserCredits(100);
             setNewUserRole('user');
             setNewUserName('');
          }, 1500);
      } catch (e: any) {
          console.error(e);
          let errorMsg = e.message || "Error creating user profile.";
          if (errorMsg.toLowerCase().includes("permission")) {
              errorMsg += " (Check Firestore Rules or your Admin role)";
          }
          setProvisionMsg({ type: 'error', text: errorMsg });
      }
  };

  // --- CMS Asset Handling ---
  
  // Specific handler for Hero/Logo inputs
  const handleSpecificUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'logo' | 'hero' | 'hero_video') => {
      const file = e.target.files?.[0];
      if (!file || !settings) return;

      setUploadingImage(true);
      try {
          const url = await uploadImageToStorage(file, 'branding');
          const key = type === 'logo' ? 'logoUrl' : type === 'hero_video' ? 'heroVideoUrl' : 'heroImageUrl';
          const newSettings = { 
              ...settings, 
              [key]: url 
          };
          setSettings(newSettings);
          await updateGlobalSettings(newSettings);
          setBrandMsg({ type: 'success', text: 'Asset uploaded and saved!' });
      } catch (error) {
          console.error("Upload failed", error);
          setBrandMsg({ type: 'error', text: 'Failed to upload asset.' });
      } finally {
          setUploadingImage(false);
      }
  };

  // Generic handler for Media Vault
  const handleVaultUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file || !settings) return;
      
      setUploadingImage(true);
      try {
          const url = await uploadImageToStorage(file, 'vault');
          const newAsset: StoredAsset = {
              id: Date.now().toString(),
              name: newAssetName || file.name,
              type: (file.type.startsWith('video') ? 'video' : 'image'),
              url,
              uploadedAt: new Date().toISOString()
          };
          
          const currentLibrary = settings.mediaLibrary || [];
          const newSettings = { 
              ...settings, 
              mediaLibrary: [newAsset, ...currentLibrary]
          };
          
          setSettings(newSettings);
          await updateGlobalSettings(newSettings);
          
          setNewAssetName(''); // Reset input
          setBrandMsg({ type: 'success', text: 'Asset added to Vault!' });
      } catch (error) {
          console.error("Vault upload failed", error);
          setBrandMsg({ type: 'error', text: 'Failed to upload asset.' });
      } finally {
          setUploadingImage(false);
      }
  };

  const handleDeleteAsset = async (assetId: string) => {
      if (!settings) return;
      if (!window.confirm("Remove this asset from the library?")) return;
      
      const newLibrary = (settings.mediaLibrary || []).filter(a => a.id !== assetId);
      const newSettings = { ...settings, mediaLibrary: newLibrary };
      setSettings(newSettings);
      await updateGlobalSettings(newSettings);
  };

  const handleSaveBranding = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!settings) return;
      try {
          await updateGlobalSettings(settings);
          setBrandMsg({ type: 'success', text: 'Content updated successfully.' });
          setTimeout(() => setBrandMsg(null), 3000);
      } catch (e) {
          setBrandMsg({ type: 'error', text: 'Failed to update settings.' });
      }
  };

  const isActuallyAdmin = currentUserProfile?.role === 'admin';

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center z-50 p-4 modal-backdrop" onClick={onClose}>
      <div className="bg-[#09090b] rounded-2xl shadow-2xl w-full max-w-6xl p-0 modal-content flex flex-col overflow-hidden max-h-[90vh] border border-white/10" onClick={e => e.stopPropagation()}>
        
        {/* Diagnostics Header */}
        <div className={`text-xs px-6 py-1 flex justify-between items-center ${isActuallyAdmin ? 'bg-green-900 text-green-200' : 'bg-red-900 text-red-200'}`}>
             <div className="flex items-center space-x-4">
                 <span className="font-mono">Diagnostics:</span>
                 <span>UID: {currentUserProfile?.uid || 'Unknown'}</span>
                 <span>Current Role: <strong className="uppercase">{currentUserProfile?.role || 'None'}</strong></span>
             </div>
             {!isActuallyAdmin && (
                 <span className="font-bold animate-pulse">WARNING: You are not detected as Admin. Reads/Writes will fail.</span>
             )}
        </div>

        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-white/10 bg-[#18181b]">
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center font-['Outfit']">
                <span className="material-icons text-[#4FFFB0] mr-2">admin_panel_settings</span>
                Admin Console
            </h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white" aria-label="Close dashboard">
            <span className="material-icons">close</span>
          </button>
        </div>

        {/* Sidebar + Content Layout */}
        <div className="flex flex-1 overflow-hidden">
            
            {/* Sidebar */}
            <div className="w-64 bg-[#121215] border-r border-white/10 p-4 space-y-2 flex-shrink-0">
                <button 
                    onClick={() => setActiveTab('overview')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'overview' ? 'bg-[#4FFFB0]/10 text-[#4FFFB0] border border-[#4FFFB0]/30' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
                >
                    <span className="material-icons">dashboard</span>
                    <span>Overview</span>
                </button>
                <button 
                    onClick={() => setActiveTab('users')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'users' ? 'bg-[#4FFFB0]/10 text-[#4FFFB0] border border-[#4FFFB0]/30' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
                >
                    <span className="material-icons">people</span>
                    <span>User Manager</span>
                </button>
                <button 
                    onClick={() => setActiveTab('cms')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'cms' ? 'bg-[#4FFFB0]/10 text-[#4FFFB0] border border-[#4FFFB0]/30' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
                >
                    <span className="material-icons">edit_note</span>
                    <span>CMS / Content</span>
                </button>
                <button 
                    onClick={() => setActiveTab('inbox')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'inbox' ? 'bg-[#4FFFB0]/10 text-[#4FFFB0] border border-[#4FFFB0]/30' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
                >
                    <span className="material-icons">inbox</span>
                    <span>Support Inbox</span>
                    {tickets.filter(t => t.status === 'open').length > 0 && (
                        <span className="ml-auto bg-red-500/80 text-white text-xs px-2 py-0.5 rounded-full">
                            {tickets.filter(t => t.status === 'open').length}
                        </span>
                    )}
                </button>
                <button 
                    onClick={() => setActiveTab('emailer')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'emailer' ? 'bg-[#4FFFB0]/10 text-[#4FFFB0] border border-[#4FFFB0]/30' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
                >
                    <span className="material-icons">send</span>
                    <span>System Emailer</span>
                </button>
            </div>

            {/* Main Content */}
            <div className="flex-1 overflow-y-auto p-8 bg-[#09090b] relative custom-scrollbar">
                
                {/* OVERVIEW TAB */}
                {activeTab === 'overview' && (
                    <div className="text-center py-4">
                        <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-6 mb-6 text-left">
                            <div className="flex items-start space-x-4">
                                <span className="material-icons text-4xl text-green-500">cloud_done</span>
                                <div>
                                    <h3 className="text-lg font-bold text-white mb-1">Live Firebase Mode</h3>
                                    <p className="text-gray-400 text-sm">
                                        You are connected to Google Cloud Firestore. Data is securely synced across all devices in real-time.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                            <div className="p-4 border border-white/10 rounded-lg hover:border-[#4FFFB0]/50 transition-colors bg-[#18181b]">
                                <h4 className="font-bold text-white flex items-center mb-2 font-['Outfit']">
                                    <span className="material-icons text-sm mr-2 text-[#4FFFB0]">people</span>
                                    User Management
                                </h4>
                                <p className="text-sm text-gray-400">View Plans, Edit Credits, and track user activity.</p>
                            </div>
                            <div className="p-4 border border-white/10 rounded-lg hover:border-[#4FFFB0]/50 transition-colors bg-[#18181b]">
                                <h4 className="font-bold text-white flex items-center mb-2 font-['Outfit']">
                                    <span className="material-icons text-sm mr-2 text-[#4FFFB0]">edit_note</span>
                                    Site CMS
                                </h4>
                                <p className="text-sm text-gray-400">Update the Landing Page Copy, Images, and Branding instantly.</p>
                            </div>
                        </div>
                    </div>
                )}
                
                {/* USERS TAB */}
                {activeTab === 'users' && (
                    <div>
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-xl font-bold text-white font-['Outfit']">User Management</h3>
                            <div className="flex items-center space-x-3">
                                <button 
                                    onClick={() => setIsProvisioning(true)}
                                    className="px-3 py-1 bg-[#4FFFB0] text-black rounded-full text-sm font-medium hover:bg-[#3ddda0] flex items-center shadow-sm"
                                >
                                    <span className="material-icons text-sm mr-1">add</span>
                                    Provision User
                                </button>
                                <button 
                                    onClick={() => setRefreshTrigger(t => t + 1)}
                                    className="p-2 text-gray-400 hover:text-[#4FFFB0] transition-colors rounded-full hover:bg-white/5"
                                    title="Force Refresh"
                                >
                                    <span className="material-icons">refresh</span>
                                </button>
                            </div>
                        </div>
                        {loadingUsers && users.length === 0 ? (
                            <div className="text-center p-8 text-gray-500">
                                <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-[#4FFFB0] border-t-transparent mb-2"></div>
                                <p>Loading users...</p>
                            </div>
                        ) : (
                            <div className="bg-[#18181b] border border-white/10 rounded-lg overflow-hidden">
                                <table className="min-w-full divide-y divide-white/10">
                                    <thead className="bg-[#121215]">
                                        <tr>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">User</th>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Plan</th>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Credits</th>
                                            <th className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody className="bg-[#18181b] divide-y divide-white/5">
                                        {users.map(user => {
                                            const planDetails = user.plan?.id ? getPlanDetails(user.plan.id) : null;
                                            return (
                                            <tr key={user.uid}>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="flex items-center">
                                                        {user.photo ? <img className="h-8 w-8 rounded-full mr-2" src={user.photo} alt="" /> : <div className="h-8 w-8 rounded-full bg-white/10 mr-2 flex items-center justify-center"><span className="material-icons text-gray-400 text-sm">person</span></div>}
                                                        <div>
                                                            <div className="text-sm font-medium text-white">{user.name || 'No Name'}</div>
                                                            <div className="text-xs text-gray-500">{user.email}</div>
                                                        </div>
                                                    </div>
                                                </td>
                                                
                                                {/* PLAN COLUMN */}
                                                <td className="px-6 py-4 whitespace-nowrap text-sm">
                                                    {editPlanId === user.uid ? (
                                                        <div className="flex items-center space-x-2">
                                                            <select 
                                                                value={tempPlanId}
                                                                onChange={(e) => setTempPlanId(e.target.value as PlanID)}
                                                                className="text-sm border border-white/20 bg-[#09090b] text-white rounded p-1"
                                                            >
                                                                {individualPlans.concat(teamPlans).map(p => (
                                                                    <option key={p.id} value={p.id}>{p.name}</option>
                                                                ))}
                                                                <option value="free">Free</option>
                                                            </select>
                                                            <button onClick={() => savePlan(user.uid)} className="text-green-500 hover:text-green-400"><span className="material-icons text-sm">check</span></button>
                                                            <button onClick={() => setEditPlanId(null)} className="text-gray-500 hover:text-gray-300"><span className="material-icons text-sm">close</span></button>
                                                        </div>
                                                    ) : (
                                                        <div className="flex items-center space-x-2 group cursor-pointer" onClick={() => startEditingPlan(user)}>
                                                            <div className="flex flex-col">
                                                                <span className={`px-2 py-1 text-xs font-bold rounded-full uppercase w-fit ${
                                                                    user.plan?.id === 'business' ? 'bg-amber-900/30 text-amber-400 border border-amber-800' :
                                                                    user.plan?.id === 'ultra' ? 'bg-pink-900/30 text-pink-400 border border-pink-800' :
                                                                    user.plan?.id === 'pro' ? 'bg-purple-900/30 text-purple-400 border border-purple-800' :
                                                                    user.plan?.id === 'plus' ? 'bg-blue-900/30 text-blue-400 border border-blue-800' :
                                                                    'bg-white/10 text-gray-400 border border-white/10'
                                                                }`}>
                                                                    {planDetails ? planDetails.name : (user.plan?.id || 'Free')}
                                                                </span>
                                                            </div>
                                                            <span className="material-icons text-xs text-gray-600 group-hover:text-[#4FFFB0] opacity-0 group-hover:opacity-100 transition-all">edit</span>
                                                        </div>
                                                    )}
                                                </td>

                                                {/* CREDITS COLUMN */}
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                                                    {editCreditId === user.uid ? (
                                                        <div className="flex items-center space-x-2">
                                                            <input 
                                                                type="number" 
                                                                value={tempCredits} 
                                                                onChange={(e) => setTempCredits(parseInt(e.target.value) || 0)}
                                                                className="w-24 p-1 border border-white/20 rounded bg-[#09090b] text-white"
                                                            />
                                                            <button onClick={() => saveCredits(user.uid)} className="text-green-500 hover:text-green-400"><span className="material-icons text-sm">check</span></button>
                                                            <button onClick={() => setEditCreditId(null)} className="text-gray-500 hover:text-gray-300"><span className="material-icons text-sm">close</span></button>
                                                        </div>
                                                    ) : (
                                                        <span className="cursor-pointer group flex items-center space-x-1" onClick={() => startEditingCredits(user)}>
                                                            <span>{user.credits?.toLocaleString()}</span>
                                                            <span className="material-icons text-xs text-gray-600 group-hover:text-[#4FFFB0] opacity-0 group-hover:opacity-100 transition-all">edit</span>
                                                        </span>
                                                    )}
                                                </td>

                                                {/* ROLE / ACTIONS */}
                                                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                                    <span className={`text-xs px-2 py-1 rounded border ${user.role === 'admin' ? 'bg-red-900/20 text-red-400 border-red-800' : 'bg-white/5 text-gray-500 border-white/10'}`}>
                                                        {user.role}
                                                    </span>
                                                </td>
                                            </tr>
                                        )})}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                )}

                {/* CMS / BRANDING TAB */}
                {activeTab === 'cms' && settings && (
                    <div className="max-w-5xl mx-auto pb-10">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="text-xl font-bold text-white font-['Outfit']">Site CMS & Assets</h3>
                            <button onClick={handleSaveBranding} className="px-6 py-2 bg-[#4FFFB0] text-black font-medium rounded-md hover:bg-[#3ddda0] shadow-sm transition-transform hover:-translate-y-0.5">
                                Save Changes
                            </button>
                        </div>
                        
                        {brandMsg && (
                            <div className={`p-4 rounded-lg text-sm mb-6 ${brandMsg.type === 'success' ? 'bg-green-900/20 text-green-400 border border-green-800' : 'bg-red-900/20 text-red-400 border border-red-800'}`}>
                                {brandMsg.text}
                            </div>
                        )}

                        <form onSubmit={handleSaveBranding} className="space-y-8">
                            
                            {/* BRAND ASSET VAULT */}
                            <div className="bg-[#18181b] border border-white/10 rounded-xl p-6 shadow-sm">
                                <div className="flex justify-between items-end mb-6 border-b border-white/10 pb-4">
                                    <div>
                                        <h4 className="font-bold text-gray-200 text-lg">Brand Asset Vault</h4>
                                        <p className="text-sm text-gray-500 mt-1">Upload images, icons, or videos to use across the site. Copy the link to insert them into fields below.</p>
                                    </div>
                                </div>

                                {/* Upload Area */}
                                <div className="flex flex-col gap-4 mb-8 bg-[#09090b] p-4 rounded-lg border border-white/10">
                                    <div className="flex items-end gap-4">
                                        <div className="flex-1">
                                            <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Asset Name (Semantic Key)</label>
                                            <input 
                                                type="text" 
                                                value={newAssetName}
                                                onChange={(e) => setNewAssetName(e.target.value)}
                                                placeholder="e.g. hero_tinker_landscape"
                                                className="w-full p-2 border border-white/10 rounded text-sm bg-[#18181b] text-white font-mono placeholder-gray-600 focus:ring-1 focus:ring-[#4FFFB0]"
                                            />
                                        </div>
                                        <div className="flex-shrink-0">
                                            <label className="inline-flex items-center px-4 py-2 bg-[#4FFFB0]/10 border border-[#4FFFB0]/30 rounded-lg shadow-sm text-sm font-medium text-[#4FFFB0] hover:bg-[#4FFFB0]/20 cursor-pointer transition-colors">
                                                <span className="material-icons mr-2 text-[#4FFFB0]">cloud_upload</span>
                                                {uploadingImage ? 'Uploading...' : 'Upload File'}
                                                <input type="file" className="hidden" onChange={handleVaultUpload} disabled={uploadingImage} />
                                            </label>
                                        </div>
                                    </div>
                                    
                                    {/* Naming Convention Guide */}
                                    <div className="text-xs text-gray-500 bg-[#121215] p-3 rounded border border-white/5">
                                        <p className="font-bold text-gray-400 mb-2">Naming Convention Guide (Category_Subject_Ratio):</p>
                                        <div className="flex flex-wrap gap-2">
                                            <span className="px-2 py-1 bg-blue-900/20 text-blue-400 rounded border border-blue-800 cursor-pointer hover:bg-blue-900/40" onClick={() => setNewAssetName('hero_tinker_landscape')}>hero_tinker_landscape</span>
                                            <span className="px-2 py-1 bg-purple-900/20 text-purple-400 rounded border border-purple-800 cursor-pointer hover:bg-purple-900/40" onClick={() => setNewAssetName('bg_cosmic_portrait')}>bg_cosmic_portrait</span>
                                            <span className="px-2 py-1 bg-pink-900/20 text-pink-400 rounded border border-pink-800 cursor-pointer hover:bg-pink-900/40" onClick={() => setNewAssetName('social_reel_portrait')}>social_reel_portrait</span>
                                            <span className="px-2 py-1 bg-gray-800 text-gray-300 rounded border border-gray-700 cursor-pointer hover:bg-gray-700" onClick={() => setNewAssetName('logo_primary_landscape')}>logo_primary_landscape</span>
                                        </div>
                                    </div>
                                </div>

                                {/* Asset Grid */}
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                    {(settings.mediaLibrary || []).map((asset) => (
                                        <div key={asset.id} className="group relative bg-[#09090b] border border-white/10 rounded-lg overflow-hidden hover:border-[#4FFFB0]/50 transition-all">
                                            <div className="aspect-square bg-black/50 relative">
                                                {asset.type === 'video' ? (
                                                    <video src={asset.url} className="w-full h-full object-cover" />
                                                ) : (
                                                    <img src={asset.url} alt={asset.name} className="w-full h-full object-cover" />
                                                )}
                                                <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center space-x-2">
                                                    <button 
                                                        type="button"
                                                        onClick={() => { navigator.clipboard.writeText(asset.url); alert("URL Copied!"); }}
                                                        className="p-2 bg-white/10 rounded-full text-white hover:bg-[#4FFFB0] hover:text-black transition-colors"
                                                        title="Copy URL"
                                                    >
                                                        <span className="material-icons text-sm">content_copy</span>
                                                    </button>
                                                    <button 
                                                        type="button"
                                                        onClick={() => handleDeleteAsset(asset.id)}
                                                        className="p-2 bg-white/10 rounded-full text-red-400 hover:bg-red-500 hover:text-white transition-colors"
                                                        title="Delete"
                                                    >
                                                        <span className="material-icons text-sm">delete</span>
                                                    </button>
                                                </div>
                                            </div>
                                            <div className="p-2">
                                                <p className="text-xs font-bold text-gray-300 truncate" title={asset.name}>{asset.name}</p>
                                                <p className="text-[10px] text-gray-500 truncate">{new Date(asset.uploadedAt).toLocaleDateString()}</p>
                                            </div>
                                        </div>
                                    ))}
                                    {(!settings.mediaLibrary || settings.mediaLibrary.length === 0) && (
                                        <div className="col-span-full py-8 text-center text-gray-600 text-sm italic">
                                            No assets uploaded yet.
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* CORE BRANDING (Logo & Hero) */}
                            <div className="bg-[#18181b] border border-white/10 rounded-xl p-6 shadow-sm">
                                <h4 className="font-bold text-gray-200 text-sm uppercase tracking-wide mb-4 border-b border-white/10 pb-2">Core Identity</h4>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                                    {/* Hero Image Upload */}
                                    <div>
                                        <label className="block text-sm font-medium text-gray-400 mb-2">Hero Character (Mobile)</label>
                                        <div className="relative group border-2 border-dashed border-white/10 rounded-lg p-4 text-center hover:bg-white/5 transition-colors">
                                            {settings.heroImageUrl ? (
                                                <div className="relative">
                                                    <img src={settings.heroImageUrl} alt="Hero" className="h-40 w-auto mx-auto object-contain mb-2" />
                                                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded">
                                                        <span className="text-white text-xs font-bold">Click to Replace</span>
                                                    </div>
                                                </div>
                                            ) : (
                                                <div className="py-8 text-gray-500">
                                                    <span className="material-icons text-4xl">add_photo_alternate</span>
                                                    <p className="text-xs mt-1">Upload PNG</p>
                                                </div>
                                            )}
                                            <input 
                                                type="file" 
                                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                                accept="image/png,image/jpeg"
                                                onChange={(e) => handleSpecificUpload(e, 'hero')}
                                            />
                                        </div>
                                    </div>

                                    {/* Hero Video Upload */}
                                    <div>
                                        <label className="block text-sm font-medium text-gray-400 mb-2">Hero Video (Desktop)</label>
                                        <div className="relative group border-2 border-dashed border-white/10 rounded-lg p-4 text-center hover:bg-white/5 transition-colors">
                                            {settings.heroVideoUrl ? (
                                                <div className="relative">
                                                    <video src={settings.heroVideoUrl} className="h-40 w-full mx-auto object-cover mb-2 rounded" muted autoPlay loop />
                                                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded">
                                                        <span className="text-white text-xs font-bold">Click to Replace</span>
                                                    </div>
                                                </div>
                                            ) : (
                                                <div className="py-8 text-gray-500">
                                                    <span className="material-icons text-4xl">videocam</span>
                                                    <p className="text-xs mt-1">Upload MP4</p>
                                                </div>
                                            )}
                                            <input 
                                                type="file" 
                                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                                accept="video/mp4,video/webm"
                                                onChange={(e) => handleSpecificUpload(e, 'hero_video')}
                                            />
                                        </div>
                                        <p className="text-xs text-gray-500 mt-2">Looping background video.</p>
                                    </div>

                                    {/* Logo Upload */}
                                    <div>
                                        <label className="block text-sm font-medium text-gray-400 mb-2">Site Logo</label>
                                        <div className="relative group border-2 border-dashed border-white/10 rounded-lg p-4 text-center hover:bg-white/5 transition-colors">
                                            {settings.logoUrl ? (
                                                <img src={settings.logoUrl} alt="Logo" className="h-16 w-auto mx-auto object-contain mb-2" />
                                            ) : (
                                                <div className="py-8 text-gray-500">
                                                    <span className="material-icons text-4xl">diamond</span>
                                                    <p className="text-xs mt-1">Default Icon Active</p>
                                                </div>
                                            )}
                                            <input 
                                                type="file" 
                                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                                accept="image/png,image/svg+xml"
                                                onChange={(e) => handleSpecificUpload(e, 'logo')}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Text Content Section */}
                            <div className="bg-[#18181b] border border-white/10 rounded-xl p-6 shadow-sm">
                                <h4 className="font-bold text-gray-200 text-sm uppercase tracking-wide mb-4 border-b border-white/10 pb-2">Landing Page Copy</h4>
                                <div className="space-y-4">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-400 mb-1">Site Name</label>
                                        <input 
                                            type="text" 
                                            value={settings.siteName}
                                            onChange={(e) => setSettings({...settings, siteName: e.target.value})}
                                            className="w-full p-2 bg-[#09090b] border border-white/10 rounded-md focus:ring-1 focus:ring-[#4FFFB0] text-white"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-400 mb-1">Hero Headline</label>
                                        <input 
                                            type="text" 
                                            value={settings.heroHeadline}
                                            onChange={(e) => setSettings({...settings, heroHeadline: e.target.value})}
                                            className="w-full p-2 bg-[#09090b] border border-white/10 rounded-md font-serif text-lg focus:ring-1 focus:ring-[#4FFFB0] text-white"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-400 mb-1">Hero Subheadline</label>
                                        <textarea 
                                            value={settings.heroSubheadline}
                                            onChange={(e) => setSettings({...settings, heroSubheadline: e.target.value})}
                                            className="w-full p-2 bg-[#09090b] border border-white/10 rounded-md focus:ring-1 focus:ring-[#4FFFB0] text-white"
                                            rows={2}
                                        />
                                    </div>
                                </div>
                            </div>

                            {/* Colors Section */}
                            <div className="bg-[#18181b] border border-white/10 rounded-xl p-6 shadow-sm">
                                <h4 className="font-bold text-gray-200 text-sm uppercase tracking-wide mb-4 border-b border-white/10 pb-2">Theme</h4>
                                <div className="grid grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-400 mb-1">Primary Color</label>
                                        <div className="flex items-center space-x-2">
                                            <input 
                                                type="color" 
                                                value={settings.primaryColor}
                                                onChange={(e) => setSettings({...settings, primaryColor: e.target.value})}
                                                className="h-10 w-10 border border-white/10 p-1 rounded cursor-pointer bg-[#09090b]"
                                            />
                                            <input 
                                                type="text" 
                                                value={settings.primaryColor}
                                                onChange={(e) => setSettings({...settings, primaryColor: e.target.value})}
                                                className="flex-1 p-2 bg-[#09090b] border border-white/10 rounded-md font-mono text-sm text-white"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
