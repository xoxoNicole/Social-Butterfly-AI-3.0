
import React from 'react';

const LandingFeatures: React.FC = () => {
  const steps = [
    {
        number: "01",
        title: "The AI Stress Test",
        subtitle: "Market Logic",
        description: "Stop guessing. Tell us your idea, and our Market Validation Engine analyzes real-world trends, competitor gaps, and search volume. We refine your pitch before we write a single line of code.",
        result: "A Product-Market Fit Report",
        icon: "crisis_alert"
    },
    {
        number: "02",
        title: "The Strategic Blueprint",
        subtitle: "Launch Architecture",
        description: "A code editor can't plan your pricing. We can. We generate your Monetization Strategy, User Journey Maps, and Brand Identity System automatically. You get a business plan that actually executes.",
        result: "A Full Strategic Roadmap & Brand Kit",
        icon: "architecture"
    },
    {
        number: "03",
        title: "Vibe Coding & Build",
        subtitle: "The Tech Stack",
        description: "Now we build. Our Multi-Agent Coding Engine writes production-ready React, Node.js, and Database code. It speaks your language—no technical jargon required. Just describe the app, and watch it appear.",
        result: "A Full-Stack, Bug-Free Application",
        icon: "terminal"
    },
    {
        number: "04",
        title: "One-Click Launch",
        subtitle: "Deployment",
        description: "Don't get stuck in 'localhost hell.' With one click, we help you deploy your app to a live, secure server with a custom URL. We even generate the Landing Page and Content Pillars to start driving traffic immediately.",
        result: "A Live Business accepting users",
        icon: "rocket_launch"
    }
  ];

  return (
    <section id="features" className="py-24 bg-[#050505] text-white overflow-hidden font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-4xl mx-auto mb-20">
            <h2 className="text-sm font-bold text-[#4FFFB0] uppercase tracking-widest mb-3 font-['Outfit']">The Hybrid Flow</h2>
            <h3 className="text-4xl md:text-5xl font-extrabold text-white mb-6 font-['Outfit']">From idea to income. From Vision to Deployment.</h3>
            <p className="text-xl text-gray-400 font-medium leading-relaxed font-['Plus_Jakarta_Sans']">
                Most AI tools skip the hard part. We don't. Here is the Social Butterfly Incubation Flow.
            </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {steps.map((step, index) => (
                <div key={index} className="relative group bg-white/5 rounded-2xl p-8 border border-white/10 hover:border-[#4FFFB0]/50 transition-all duration-300 hover:shadow-2xl hover:shadow-[#4FFFB0]/10 hover:-translate-y-1 overflow-hidden backdrop-blur-sm">
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                        <span className="material-icons text-9xl text-[#4FFFB0] transform rotate-12">{step.icon}</span>
                    </div>
                    
                    <div className="relative z-10">
                        <div className="flex items-baseline space-x-3 mb-4">
                            <span className="text-5xl font-bold text-white/20 group-hover:text-[#4FFFB0]/50 transition-colors font-['Outfit']">{step.number}</span>
                            <div className="h-px bg-white/10 w-12 self-center"></div>
                        </div>
                        
                        <h4 className="text-2xl font-bold text-white mb-1 font-['Outfit']">{step.title}</h4>
                        <p className="text-xs font-bold text-[#4FFFB0] uppercase tracking-wider mb-4 font-['JetBrains_Mono']">{step.subtitle}</p>
                        
                        <p className="text-gray-400 leading-relaxed mb-6 font-['Plus_Jakarta_Sans']">
                            {step.description}
                        </p>
                        
                        <div className="inline-flex items-center px-4 py-2 bg-white/10 rounded-lg border border-white/10 shadow-sm text-sm font-bold text-white font-['Plus_Jakarta_Sans']">
                            <span className="material-icons text-[#4FFFB0] text-sm mr-2">check_circle</span>
                            Result: {step.result}
                        </div>
                    </div>
                </div>
            ))}
        </div>

      </div>
    </section>
  );
};

export default LandingFeatures;
