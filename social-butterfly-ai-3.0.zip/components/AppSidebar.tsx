
import React from 'react';
import { UserProfile } from '../services/firebase';

interface AppSidebarProps {
  isOpen: boolean;
  activeView: string;
  onNavigate: (view: string) => void;
  onLogout?: () => void;
}

const AppSidebar: React.FC<AppSidebarProps> = ({ isOpen, activeView, onNavigate, onLogout }) => {
  
  const NavItem = ({ id, label, icon, activeIcon }: { id: string, label: string, icon: string, activeIcon?: string }) => {
      const isActive = activeView === id;
      return (
          <button 
            onClick={() => onNavigate(id)}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group ${isActive ? 'bg-[#4FFFB0] text-black font-bold shadow-[0_0_15px_rgba(79,255,176,0.2)]' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
          >
              <span className={`material-icons ${isActive ? 'text-black' : 'text-gray-500 group-hover:text-white'}`}>
                  {isActive && activeIcon ? activeIcon : icon}
              </span>
              <span className="font-['Plus_Jakarta_Sans'] text-sm tracking-wide">{label}</span>
          </button>
      );
  };

  return (
    <div className={`fixed inset-y-0 left-0 z-40 w-64 bg-[#09090b] border-r border-white/5 flex flex-col transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0`}>
        
        {/* Brand */}
        <div className="h-20 flex items-center px-6 border-b border-white/5">
            <span className="material-icons text-[#4FFFB0] mr-2 text-2xl">auto_awesome</span>
            <span className="font-['Outfit'] font-bold text-lg text-white tracking-tight">Social Butterfly</span>
        </div>

        {/* Navigation */}
        <div className="flex-1 overflow-y-auto py-6 px-3 space-y-1 custom-scrollbar">
            <NavItem id="dashboard" label="Dashboard" icon="dashboard" />
            <NavItem id="vibe_coding" label="Vibe Coding" icon="construction" />
            <NavItem id="creative_studio" label="Creative Studio" icon="palette" />
            <NavItem id="clarity_hub" label="Clarity Hub" icon="self_improvement" />
            <NavItem id="academy" label="Academy" icon="school" />
            
            <div className="my-4 border-t border-white/5 mx-2"></div>
            
            <NavItem id="profile" label="Profile" icon="person" />
            <NavItem id="settings" label="Settings" icon="settings" />
            <NavItem id="admin" label="Admin" icon="admin_panel_settings" />
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/5">
            <button 
                onClick={onLogout}
                className="w-full flex items-center space-x-3 px-4 py-2 text-red-400 hover:text-red-300 hover:bg-red-900/10 rounded-lg transition-colors text-sm"
            >
                <span className="material-icons text-sm">logout</span>
                <span>Sign Out</span>
            </button>
        </div>
    </div>
  );
};

export default AppSidebar;
