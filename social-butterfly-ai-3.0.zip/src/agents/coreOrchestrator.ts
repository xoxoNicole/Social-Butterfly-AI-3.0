
import { GoogleGenAI } from "@google/genai";
import { agentRegistry, AgentId } from "./registry";
import { MODEL_SMART } from "../components/aiConfig";

export type PhaseId = 'PHASE_1_PRD' | 'PHASE_2_BUILD' | 'PHASE_3_DEPLOY';

export interface OrchestratorArtifacts {
  prd?: string;
  buildBlueprint?: string;
  uiMetadata?: string;
  deployConfig?: string;
}

export interface OrchestratorState {
  phase: PhaseId;
  artifacts: OrchestratorArtifacts;
}

export interface OrchestratorInput {
  userMessage: string;
  state: OrchestratorState;
  apiKey: string;
}

export interface OrchestratorDecision {
  nextAgent: AgentId | 'PRD_AGENT'; 
  updatedState: OrchestratorState;
  normalizedUserMessage: string;
}

export async function routeThroughOrchestrator(
  input: OrchestratorInput
): Promise<OrchestratorDecision> {
  const ai = new GoogleGenAI({ apiKey: input.apiKey });
  const systemPrompt = agentRegistry.coreOrchestrator.systemPrompt;

  // Simplify the artifact filtering to avoid complex TS casting inside template literals
  const availableArtifacts = Object.keys(input.state.artifacts)
    .filter((k) => (input.state.artifacts as any)[k])
    .join(', ');

  const prompt = `
    CURRENT STATE:
    Phase: ${input.state.phase}
    Artifacts Available: ${availableArtifacts}

    USER MESSAGE:
    ${input.userMessage}

    INSTRUCTIONS:
    Analyze the user message and current state. 
    Return a valid JSON object matching this structure:
    {
      "nextAgent": "PRD_AGENT" | "VIBE_ARCHITECT" | "ENGINEERING_AGENT",
      "phase": "PHASE_1_PRD" | "PHASE_2_BUILD" | "PHASE_3_DEPLOY",
      "artifacts": { "prd": "...", "buildBlueprint": "..." }, 
      "normalizedUserMessage": "string"
    }
    
    IMPORTANT:
    - Return ONLY valid JSON.
    - No markdown formatting.
    - Map "VIBE_ARCHITECT" to ui/coding tasks.
    - Map "ENGINEERING_AGENT" to firebase/deployment/config tasks.
    - Map "PRD_AGENT" to strategy/idea refinement tasks.
  `;

  try {
      const response = await ai.models.generateContent({
        model: MODEL_SMART,
        contents: [{ parts: [{ text: prompt }] }],
        config: {
            systemInstruction: systemPrompt,
            responseMimeType: "application/json"
        }
      });

      const text = response.text || "{}";
      const json = JSON.parse(text);

      // Validate/Map IDs
      let nextAgent = json.nextAgent;
      
      // Normalize Agent ID to match Registry where possible
      if (nextAgent === 'VIBE_ARCHITECT') nextAgent = 'vibeArchitect';
      if (nextAgent === 'ENGINEERING_AGENT') nextAgent = 'engineering';
      if (nextAgent === 'PRD_AGENT') nextAgent = 'PRD_AGENT'; // Special case handled in UI

      // Safety fallback
      if (!['vibeArchitect', 'engineering', 'PRD_AGENT'].includes(nextAgent)) {
          if (json.phase === 'PHASE_3_DEPLOY') nextAgent = 'engineering';
          else if (json.phase === 'PHASE_2_BUILD') nextAgent = 'vibeArchitect';
          else nextAgent = 'PRD_AGENT';
      }

      return {
          nextAgent: nextAgent,
          updatedState: {
              phase: json.phase || input.state.phase,
              artifacts: { ...input.state.artifacts, ...json.artifacts }
          },
          normalizedUserMessage: json.normalizedUserMessage || input.userMessage
      };

  } catch (e) {
      console.error("Orchestration failed", e);
      // Fail safely: stay in current phase, assume generic agent for that phase
      let fallbackAgent: AgentId | 'PRD_AGENT' = 'PRD_AGENT';
      if (input.state.phase === 'PHASE_2_BUILD') fallbackAgent = 'vibeArchitect';
      if (input.state.phase === 'PHASE_3_DEPLOY') fallbackAgent = 'engineering';

      return {
          nextAgent: fallbackAgent,
          updatedState: input.state,
          normalizedUserMessage: input.userMessage
      };
  }
}
