
import { engineeringAgentSystemPrompt } from './engineeringAgentPrompt';
import { vibeArchitectSystemPrompt } from './vibeArchitectPrompt';
import { coreOrchestratorSystemPrompt } from './coreOrchestratorPrompt';

export type AgentId = 'vibeArchitect' | 'engineering' | 'coreOrchestrator';

export interface AgentDefinition {
  id: AgentId;
  label: string;
  systemPrompt: string;
  phase: 'PHASE_1_PRD' | 'PHASE_2_BUILD' | 'PHASE_3_DEPLOY' | 'GLOBAL';
}

export const agentRegistry: Record<AgentId, AgentDefinition> = {
  engineering: {
    id: 'engineering',
    label: 'Engineering & Deployment Agent',
    systemPrompt: engineeringAgentSystemPrompt,
    phase: 'PHASE_3_DEPLOY',
  },
  vibeArchitect: {
    id: 'vibeArchitect',
    label: 'Vibe Architect',
    systemPrompt: vibeArchitectSystemPrompt,
    phase: 'PHASE_2_BUILD',
  },
  coreOrchestrator: {
    id: 'coreOrchestrator',
    label: 'Core Orchestrator',
    systemPrompt: coreOrchestratorSystemPrompt,
    phase: 'GLOBAL',
  },
};
